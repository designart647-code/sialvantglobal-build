# SIALVANTGLOBAL INDUSTRIES — Luxury Leathercraft E-Commerce & B2B Platform

A luxury e-commerce and wholesale inquiry web application for **SIALVANTGLOBAL INDUSTRIES**, handcrafted in Sialkot, Punjab, Pakistan.

---

## 🌟 Key Features

1. **Official Brand Identity**
   - Brand: **SIALVANTGLOBAL INDUSTRIES**
   - Theme: Deep Obsidian Black, Warm Ivory, Cognac Brown, and Artisanal Gold
   - Full responsive layout for mobile, tablet, and ultra-wide displays

2. **Dual Checkout System**
   - **Retail Shopping Cart**:
     - Real-time cart calculations
     - Free worldwide shipping threshold ($150)
     - Direct checkout with Credit Card, SWIFT Wire, and WhatsApp Order
   - **Inquiry Basket (B2B / Export RFQ)**:
     - Company & Buyer details
     - Order Tier selection (Sample Run 10-24 pcs to Full Container 500+ pcs)
     - Branding customization options (Blind Heat Debossing, Gold/Silver Foil, Engraved Hardware, Private Label)
     - Target delivery destination / port
     - Instant **Submit on WhatsApp** formatted RFQ, **Copy B2B RFQ Sheet**, and **Email RFQ**

3. **Master Leather Jacket Showcase**
   - Single unified product card for the signature jacket
   - 14 authentic color selectors (Blue, Red, Green, White, Purple, Orange, Pink, Brown, Grey, Maroon, Turquoise, Magenta, Camel, Black)
   - Dynamic high-resolution photography switching without page reloads

4. **Dedicated Luxury Pages & Modals**
   - Dedicated **Contact Us** page with interactive inquiry form and direct workshop address
   - **Our Workshop & Tannery Heritage** interactive tour
   - **Bespoke Made-to-Measure** tailoring consultation modal
   - Multi-currency live conversion (USD, EUR, GBP, AED, SAR, CAD, AUD, PKR)
   - Multi-language support (English, Arabic, German, French, Spanish)

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ or 20+
- npm, yarn, or pnpm

### Installation
```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

### Production Build
```bash
# Build optimized production bundle
npm run build

# Preview production build locally
npm run preview
```

---

## 📁 Project Structure

```
├── public/                 # Static public assets
├── src/
│   ├── assets/images/      # Optimized local workshop & craftsmanship photography
│   ├── components/         # Modular React components
│   │   ├── Header.tsx      # Black top navbar, luxury wordmark, multi-currency/lang
│   │   ├── Hero.tsx        # Hero banner with luxury call-to-actions
│   │   ├── CartDrawer.tsx  # Retail Cart & B2B Inquiry Basket switcher
│   │   ├── ContactPage.tsx # Luxury Contact Us page with direct cards & form
│   │   ├── ProductCard.tsx # Product card with red & black button styling
│   │   ├── ProductDetailPage.tsx # Deep product detail view
│   │   ├── OwnWorkshopSection.tsx # Authentic Sialkot artisan workshop section
│   │   ├── CraftHeritage.tsx # Heritage and tanning process
│   │   ├── LeatherGuide.tsx# Full-grain vs top-grain buyer education
│   │   └── ...
│   ├── data/               # Product catalog & multilingual translations
│   ├── utils/              # WhatsApp utility and message formatters
│   ├── types.ts            # TypeScript interfaces & types
│   ├── App.tsx             # Main application orchestrator
│   └── main.tsx            # Application entry point
├── package.json            # Project manifest & dependencies
├── tsconfig.json           # TypeScript configuration
└── vite.config.ts          # Vite build configuration
```

---

## 📞 Workshop Contact Information
- **Brand**: SIALVANTGLOBAL INDUSTRIES
- **WhatsApp**: +92 329 7134614 (wa.me/923297134614)
- **Email**: info@sialvantglobalindustries.com
- **Workshop**: Dak Khana Khas Badiana, Tehsil Pasrur, District Sialkot 51410, Punjab, Pakistan
