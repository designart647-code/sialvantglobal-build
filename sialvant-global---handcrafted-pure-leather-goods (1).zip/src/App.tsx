import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  Filter,
  SlidersHorizontal,
  MessageCircle,
  Sparkles,
  ShoppingBag,
  ArrowUp,
  Check,
  LayoutGrid,
  Grid3X3,
} from 'lucide-react';
import { CartItem, CurrencyCode, Product, ProductCategory, LanguageCode, CountryConfig } from './types';
import { INITIAL_PRODUCTS } from './data/products';
import { TRANSLATIONS } from './data/translations';
import { WORLD_COUNTRIES, detectVisitorCountry } from './data/countries';
import { Header } from './components/Header';
import { CountryCurrencyModal } from './components/CountryCurrencyModal';
import { NewArrivalsSection } from './components/NewArrivalsSection';
import { ProductCard } from './components/ProductCard';
import { ProductModal } from './components/ProductModal';
import { ProductDetailPage } from './components/ProductDetailPage';
import { ContactPage } from './components/ContactPage';
import { CartDrawer } from './components/CartDrawer';
import { BespokeModal } from './components/BespokeModal';
import { BestsellersSection } from './components/BestsellersSection';
import { CollectionsGrid } from './components/CollectionsGrid';
import { OwnWorkshopSection } from './components/OwnWorkshopSection';
import { CraftHeritage } from './components/CraftHeritage';
import { FactoryView } from './components/FactoryView';
import { LeatherGuide } from './components/LeatherGuide';
import { ReviewsSection } from './components/ReviewsSection';
import { ShippingSection } from './components/ShippingSection';
import { FAQSection } from './components/FAQSection';
import { WhatsAppConfigModal } from './components/WhatsAppConfigModal';
import { Footer } from './components/Footer';
import { LiveChatWidget } from './components/LiveChatWidget';
import { getStoredWhatsAppNumber } from './utils/whatsapp';

export default function App() {
  const [currentLanguage, setCurrentLanguage] = useState<LanguageCode>('en');
  const [selectedCountry, setSelectedCountry] = useState<CountryConfig>(() => {
    try {
      const savedCode = localStorage.getItem('sialvant_country');
      if (savedCode) {
        const found = WORLD_COUNTRIES.find((c) => c.code === savedCode);
        if (found) return found;
      }
    } catch {}
    return detectVisitorCountry();
  });
  const [currentCurrency, setCurrentCurrency] = useState<CurrencyCode>(() => {
    try {
      const saved = localStorage.getItem('sialvant_currency');
      if (saved) return saved as CurrencyCode;
    } catch {}
    return 'USD';
  });
  const [isCountryModalOpen, setIsCountryModalOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('sialvant_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [activeCategory, setActiveCategory] = useState<ProductCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [gridCols, setGridCols] = useState<4 | 6 | 8>(4);

  // Dedicated single product page view state
  const [selectedProductForDetail, setSelectedProductForDetail] = useState<Product | null>(null);
  const [inspectProduct, setInspectProduct] = useState<Product | null>(null);
  const [isContactPage, setIsContactPage] = useState(false);

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isBespokeOpen, setIsBespokeOpen] = useState(false);
  const [isWhatsAppConfigOpen, setIsWhatsAppConfigOpen] = useState(false);
  const [waNumber, setWaNumber] = useState<string>(() => getStoredWhatsAppNumber());
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [cartToastMessage, setCartToastMessage] = useState<string | null>(null);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  // Set HTML direction and lang attribute for RTL languages (Arabic, Hebrew)
  useEffect(() => {
    const isRtl = ['ar', 'he'].includes(currentLanguage);
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = currentLanguage;
  }, [currentLanguage]);

  // Sync cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('sialvant_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.error('Failed to save cart to localStorage', e);
    }
  }, [cartItems]);

  // Back to top scroll listener
  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Listen to hash changes (e.g. #product-id or #contact)
  useEffect(() => {
    const checkHash = () => {
      const hash = window.location.hash;
      if (hash === '#contact') {
        setIsContactPage(true);
        setSelectedProductForDetail(null);
      } else if (hash && hash.startsWith('#product-')) {
        const pId = hash.replace('#product-', '');
        const found = INITIAL_PRODUCTS.find((p) => p.id === pId);
        if (found) {
          setSelectedProductForDetail(found);
          setIsContactPage(false);
        }
      }
    };
    checkHash();
    window.addEventListener('hashchange', checkHash);
    return () => window.removeEventListener('hashchange', checkHash);
  }, []);

  // Filter & Sort Products
  const filteredProducts = useMemo(() => {
    return INITIAL_PRODUCTS.filter((product) => {
      const matchesCategory =
        activeCategory === 'all' || product.category === activeCategory;
      const matchesSearch =
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.leatherType.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.priceUSD - b.priceUSD;
      if (sortBy === 'price-desc') return b.priceUSD - a.priceUSD;
      if (sortBy === 'rating') return (b.rating || 0) - (a.rating || 0);
      return 0; // featured default order
    });
  }, [activeCategory, searchQuery, sortBy]);

  // Cart operations
  const handleAddToCart = (
    product: Product,
    selectedColor: string,
    monogram?: string,
    size?: string
  ) => {
    setCartItems((prev) => {
      const existingIndex = prev.findIndex(
        (item) =>
          item.product.id === product.id &&
          item.selectedColor === selectedColor &&
          item.selectedSize === size &&
          item.monogramInitials === (monogram || undefined)
      );

      if (existingIndex > -1) {
        const copy = [...prev];
        copy[existingIndex].quantity += 1;
        return copy;
      }
      return [
        ...prev,
        {
          product,
          quantity: 1,
          selectedColor,
          selectedSize: size,
          monogramInitials: monogram,
        },
      ];
    });

    setCartToastMessage(`Added "${product.name}" (${selectedColor}) to your bag`);
    setTimeout(() => setCartToastMessage(null), 2500);
  };

  // BUY IT NOW: Directly adds to cart and opens checkout
  const handleBuyItNow = (
    product: Product,
    selectedColor: string,
    monogram?: string,
    size?: string,
    qty = 1
  ) => {
    setCartItems((prev) => {
      const existingIndex = prev.findIndex(
        (item) =>
          item.product.id === product.id &&
          item.selectedColor === selectedColor &&
          item.selectedSize === size &&
          item.monogramInitials === (monogram || undefined)
      );

      if (existingIndex > -1) {
        const copy = [...prev];
        copy[existingIndex].quantity += qty;
        return copy;
      }
      return [
        ...prev,
        {
          product,
          quantity: qty,
          selectedColor,
          selectedSize: size,
          monogramInitials: monogram,
        },
      ];
    });

    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (index: number, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(index);
      return;
    }
    setCartItems((prev) => {
      const copy = [...prev];
      copy[index].quantity = newQty;
      return copy;
    });
  };

  const handleRemoveItem = (index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const scrollToProducts = () => {
    setSelectedProductForDetail(null);
    setTimeout(() => {
      document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
    }, 50);
  };

  const scrollToStory = () => {
    setSelectedProductForDetail(null);
    setTimeout(() => {
      document.getElementById('story')?.scrollIntoView({ behavior: 'smooth' });
    }, 50);
  };

  const scrollToFactory = () => {
    setSelectedProductForDetail(null);
    setTimeout(() => {
      document.getElementById('factory-view')?.scrollIntoView({ behavior: 'smooth' });
    }, 50);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenDetail = (product: Product) => {
    setSelectedProductForDetail(product);
    if (typeof window !== 'undefined') {
      window.location.hash = `product-${product.id}`;
    }
  };

  const handleOpenContact = () => {
    setIsContactPage(true);
    setSelectedProductForDetail(null);
    if (typeof window !== 'undefined') {
      window.location.hash = 'contact';
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleBackToCatalog = () => {
    setSelectedProductForDetail(null);
    setIsContactPage(false);
    if (
      typeof window !== 'undefined' &&
      (window.location.hash.startsWith('#product-') || window.location.hash === '#contact')
    ) {
      window.history.pushState(null, '', ' ');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div
      className="min-h-screen bg-[#F9F6F0] text-[#222222] flex flex-col font-poppins relative selection:bg-[#8E5431] selection:text-white"
      dir={['ar', 'he'].includes(currentLanguage) ? 'rtl' : 'ltr'}
    >
      {/* Toast notification */}
      {cartToastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-[#1F1511] text-white px-5 py-2.5 rounded-full shadow-2xl flex items-center gap-2.5 text-xs font-medium border border-[#D4AF37]/50 animate-in slide-in-from-bottom duration-300">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{cartToastMessage}</span>
          <button
            onClick={() => setIsCartOpen(true)}
            className="text-[#D4AF37] font-semibold underline ml-2 cursor-pointer"
          >
            View Bag
          </button>
        </div>
      )}

      {/* Header with Dedicated Black Horizontal Navigation Bar & DECRUM-style Country/Currency Selector */}
      <Header
        currentLanguage={currentLanguage}
        onLanguageChange={setCurrentLanguage}
        currentCurrency={currentCurrency}
        onCurrencyChange={setCurrentCurrency}
        selectedCountry={selectedCountry}
        onOpenCountryModal={() => setIsCountryModalOpen(true)}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenBespoke={() => setIsBespokeOpen(true)}
        onSelectCategory={(cat) => {
          setSelectedProductForDetail(null);
          setActiveCategory(cat);
          setTimeout(() => {
            document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
          }, 60);
        }}
        onSearch={(query) => {
          setSelectedProductForDetail(null);
          if (query.trim()) {
            setActiveCategory('all'); // Search across all products and categories
          }
          setSearchQuery(query);
          setTimeout(() => {
            document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
          }, 60);
        }}
        onNavigateHome={handleBackToCatalog}
        onNavigateContact={handleOpenContact}
      />

      <main className="grow">
        {isContactPage ? (
          /* DEDICATED LUXURY CONTACT US PAGE */
          <ContactPage
            onBack={handleBackToCatalog}
            onOpenBespoke={() => setIsBespokeOpen(true)}
          />
        ) : selectedProductForDetail ? (
          /* DEDICATED INDIVIDUAL PRODUCT DETAIL PAGE (Etsy-Inspired Luxury SIALVANTGLOBAL INDUSTRIES Experience) */
          <ProductDetailPage
            product={selectedProductForDetail}
            allProducts={INITIAL_PRODUCTS}
            currentCurrency={currentCurrency}
            currentLanguage={currentLanguage}
            onBack={handleBackToCatalog}
            onSelectProduct={(p) => handleOpenDetail(p)}
            onAddToCart={(p, color, monogram, size) => handleAddToCart(p, color, monogram, size)}
            onBuyItNow={(p, color, monogram, size, qty) => handleBuyItNow(p, color, monogram, size, qty)}
          />
        ) : (
          /* MAIN LUXURY HOMEPAGE VIEW */
          <>
            {/* 1. FEATURED PRODUCTS (IMMEDIATELY BELOW MAIN NAVIGATION) */}
            <section className="max-w-[1720px] mx-auto px-3 sm:px-6 lg:px-8 pt-6 sm:pt-8 pb-14" id="products">
              {/* Section Header */}
              <div className="text-center mb-6">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8E5431]/10 text-[#8E5431] text-[10px] sm:text-[11px] font-bold tracking-[0.25em] uppercase mb-1.5">
                  <Sparkles className="w-3 h-3 text-[#D4AF37]" />
                  <span>HANDCRAFTED FULL-GRAIN LEATHER</span>
                </div>
                <h1 className="font-cinzel text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#1F1511] tracking-tight">
                  OUR FEATURED COLLECTION
                </h1>
                <div className="w-16 h-0.5 bg-[#D4AF37] mx-auto mt-2 mb-2" />
                <p className="text-xs text-[#6B6865] max-w-xl mx-auto">
                  {t.collectionSectionSubtitle}
                </p>
              </div>

              {/* Filtering, Search and Layout Toolbar */}
              <div className="bg-white rounded-lg p-3.5 sm:p-4 border border-[#ECE3D7] shadow-xs mb-8 flex flex-col lg:flex-row items-center justify-between gap-4">
                {/* Category Pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto w-full lg:w-auto pb-2 lg:pb-0 scrollbar-none">
                  {(
                    [
                      { id: 'all', label: t.filterAll },
                      { id: 'wallets', label: t.filterWallets },
                      { id: 'bags', label: t.filterBags },
                      { id: 'belts', label: t.filterBelts },
                      { id: 'jackets', label: t.filterJackets },
                      { id: 'accessories', label: t.filterAccessories },
                    ] as const
                  ).map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setActiveCategory(cat.id)}
                      className={`px-3 py-1.5 rounded-xs text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                        activeCategory === cat.id
                          ? 'bg-[#1F1511] text-white shadow-xs'
                          : 'bg-[#F9F6F0] text-[#6B6865] hover:text-[#1F1511] hover:bg-[#ECE3D7]'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {/* Layout Switcher and Sort (No Duplicate Search Bar) */}
                <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 w-full lg:w-auto justify-end">
                  {/* Exactly 3 Product Display Options: 4 Per Row, 6 Per Row, 8 Per Row */}
                  <div className="flex items-center bg-[#F9F6F0] p-1 rounded-xs border border-[#ECE3D7] shadow-2xs">
                    <button
                      type="button"
                      onClick={() => setGridCols(4)}
                      className={`px-2.5 sm:px-3 py-1.5 text-[11px] font-bold rounded-xs transition cursor-pointer flex items-center gap-1.5 ${
                        gridCols === 4
                          ? 'bg-[#1F1511] text-[#D4AF37] shadow-xs'
                          : 'text-[#6B6865] hover:text-[#1F1511] hover:bg-[#ECE3D7]/60'
                      }`}
                      title="4 Per Row: Display 4 products per row on desktop"
                      aria-label="4 Per Row"
                    >
                      <Grid3X3 className="w-3.5 h-3.5" />
                      <span>4 Per Row</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setGridCols(6)}
                      className={`px-2.5 sm:px-3 py-1.5 text-[11px] font-bold rounded-xs transition cursor-pointer flex items-center gap-1.5 ${
                        gridCols === 6
                          ? 'bg-[#1F1511] text-[#D4AF37] shadow-xs'
                          : 'text-[#6B6865] hover:text-[#1F1511] hover:bg-[#ECE3D7]/60'
                      }`}
                      title="6 Per Row: Display 6 products per row on desktop"
                      aria-label="6 Per Row"
                    >
                      <LayoutGrid className="w-3.5 h-3.5" />
                      <span>6 Per Row</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setGridCols(8)}
                      className={`px-2.5 sm:px-3 py-1.5 text-[11px] font-bold rounded-xs transition cursor-pointer flex items-center gap-1.5 ${
                        gridCols === 8
                          ? 'bg-[#1F1511] text-[#D4AF37] shadow-xs'
                          : 'text-[#6B6865] hover:text-[#1F1511] hover:bg-[#ECE3D7]/60'
                      }`}
                      title="8 Per Row: Display 8 products per row on desktop"
                      aria-label="8 Per Row"
                    >
                      <LayoutGrid className="w-3.5 h-3.5" />
                      <span>8 Per Row</span>
                    </button>
                  </div>

                  {/* Sort Selector */}
                  <div className="relative flex items-center bg-[#F9F6F0] border border-[#ECE3D7] rounded-xs px-2.5 py-1.5 text-xs text-[#1F1511]">
                    <SlidersHorizontal className="w-3 h-3 text-[#8E5431] mr-1.5 hidden sm:inline" />
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                      className="bg-transparent text-xs font-semibold focus:outline-none cursor-pointer"
                      aria-label="Sort products"
                    >
                      <option value="featured">{t.sortFeatured}</option>
                      <option value="price-asc">{t.sortPriceAsc}</option>
                      <option value="price-desc">{t.sortPriceDesc}</option>
                      <option value="rating">{t.sortRating}</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Active Search Result Indicator (If Search Query from Header is Present) */}
              {searchQuery.trim() && (
                <div className="mb-6 flex items-center justify-between bg-[#FFFDF9] border border-[#D4AF37]/40 rounded-lg p-3 sm:px-4 text-xs shadow-xs animate-in fade-in duration-200">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-[#8E5431]">Header Search:</span>
                    <span className="text-[#1F1511] font-semibold">&ldquo;{searchQuery}&rdquo;</span>
                    <span className="text-[#6B6865]">
                      ({filteredProducts.length} {filteredProducts.length === 1 ? 'item' : 'items'} found across all categories)
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setActiveCategory('all');
                    }}
                    className="text-xs font-bold text-[#8E5431] hover:text-[#1F1511] underline cursor-pointer"
                  >
                    Clear Search
                  </button>
                </div>
              )}

              {/* Product Grid: 4, 6, or 8 per row based on selection */}
              {filteredProducts.length === 0 ? (
                <div className="py-20 text-center bg-white rounded-lg border border-[#ECE3D7] p-8 space-y-3">
                  <p className="font-cinzel text-lg font-bold text-[#1F1511]">
                    No leather goods found matching &ldquo;{searchQuery}&rdquo;
                  </p>
                  <p className="text-xs text-[#6B6865]">
                    Try searching with another keyword or select a category above.
                  </p>
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setActiveCategory('all');
                    }}
                    className="mt-2 text-xs font-semibold text-[#8E5431] underline cursor-pointer"
                  >
                    Reset Filters
                  </button>
                </div>
              ) : (
                <div
                  className={
                    gridCols === 8
                      ? 'grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 xl:grid-cols-8 gap-2.5 sm:gap-3 lg:gap-3.5'
                      : gridCols === 6
                      ? 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4 lg:gap-5'
                      : 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8'
                  }
                >
                  {filteredProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      currentCurrency={currentCurrency}
                      currentLanguage={currentLanguage}
                      onQuickView={(p) => handleOpenDetail(p)}
                      onAddToCart={(p, color) => handleAddToCart(p, color)}
                      onBuyItNow={(p, color) => handleBuyItNow(p, color)}
                      gridCols={gridCols}
                    />
                  ))}
                </div>
              )}
            </section>

            {/* 2. BEST SELLERS */}
            <BestsellersSection
              products={INITIAL_PRODUCTS}
              currentCurrency={currentCurrency}
              currentLanguage={currentLanguage}
              onQuickView={(p) => handleOpenDetail(p)}
              onAddToCart={(p, color) => handleAddToCart(p, color)}
              onBuyItNow={(p, color) => handleBuyItNow(p, color)}
              onViewAll={scrollToProducts}
            />

            {/* 3. SHOP BY CATEGORY */}
            <CollectionsGrid
              currentLanguage={currentLanguage}
              onSelectCategory={(cat) => {
                setActiveCategory(cat);
                scrollToProducts();
              }}
            />

            {/* 4. NEW ARRIVALS */}
            <NewArrivalsSection
              products={INITIAL_PRODUCTS}
              currentCurrency={currentCurrency}
              currentLanguage={currentLanguage}
              onQuickView={(p) => handleOpenDetail(p)}
              onAddToCart={(p, color) => handleAddToCart(p, color)}
              onBuyItNow={(p, color) => handleBuyItNow(p, color)}
              onViewAll={scrollToProducts}
            />

            {/* 5. CUSTOM ORDERS AND WHOLESALE INQUIRY SECTION */}
            <section className="py-14 bg-gradient-to-br from-[#FFFDF9] via-[#F8F3EA] to-[#F2ECE1] border-y border-[#ECE3D7]" id="custom-wholesale">
              <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
                <div className="bg-white/90 backdrop-blur-xs text-[#1F1511] p-7 sm:p-10 rounded-xl shadow-lg border-2 border-[#8E5431]/25 flex flex-col md:flex-row items-center justify-between gap-8">
                  <div className="space-y-3 text-center md:text-left max-w-3xl">
                    <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-[#8E5431] uppercase tracking-[0.2em]">
                      <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                      <span>Custom Craftsmanship & Wholesale Consignments</span>
                    </div>

                    <h3 className="font-cinzel text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#120B08] tracking-tight leading-snug">
                      Need a Custom Size, Corporate Logo, or Wholesale Batch?
                    </h3>

                    <p className="text-sm sm:text-[15px] font-medium text-[#2E2018] leading-relaxed">
                      Our Sialkot workshops produce custom jackets tailored to your exact measurements, bespoke monogrammed executive luggage, and bulk corporate gift consignments with direct worldwide express delivery.
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
                    <button
                      type="button"
                      onClick={() => setIsBespokeOpen(true)}
                      className="w-full sm:w-auto bg-[#1F1511] hover:bg-[#8E5431] text-white border-2 border-[#D4AF37] px-8 py-4 rounded-xs font-bold text-xs uppercase tracking-widest shadow-xl transition-all duration-300 transform hover:scale-[1.02] cursor-pointer"
                    >
                      Request Custom Quote
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsCartOpen(true)}
                      className="w-full sm:w-auto bg-[#8E5431] hover:bg-[#6e4125] text-white px-7 py-4 rounded-xs font-bold text-xs uppercase tracking-widest shadow-md transition cursor-pointer flex items-center justify-center gap-2"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>Inquiry Basket</span>
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* 6. OUR WORKSHOP / ABOUT OUR CRAFT */}
            <div id="own-workshop">
              <OwnWorkshopSection
                currentLanguage={currentLanguage}
                onExploreFactory={scrollToFactory}
                onOpenBespoke={() => setIsBespokeOpen(true)}
              />
              <CraftHeritage currentLanguage={currentLanguage} />
              <FactoryView
                currentLanguage={currentLanguage}
                onOpenBespoke={() => setIsBespokeOpen(true)}
              />
              <LeatherGuide />
            </div>

            {/* 7. CUSTOMER REVIEWS (ONLY GENUINE REVIEWS) */}
            <ReviewsSection />

            {/* Worldwide Shipping Section */}
            <ShippingSection currentLanguage={currentLanguage} />

            {/* Frequently Asked Questions Section */}
            <FAQSection currentLanguage={currentLanguage} />
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        currentLanguage={currentLanguage}
        onOpenBespoke={() => setIsBespokeOpen(true)}
        onNavigateContact={handleOpenContact}
      />

      {/* Floating Live Chat & WhatsApp Widget */}
      <LiveChatWidget
        currentLanguage={currentLanguage}
        onOpenBespoke={() => setIsBespokeOpen(true)}
      />

      {/* Back to Top Button */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-24 right-6 sm:bottom-24 sm:right-6 z-30 bg-white hover:bg-[#F9F6F0] text-[#1F1511] p-2.5 rounded-full shadow-lg border border-[#ECE3D7] transition duration-300 cursor-pointer"
          aria-label="Scroll back to top"
          title="Back to top"
        >
          <ArrowUp className="w-4 h-4" />
        </button>
      )}

      {/* Modals & Drawers */}
      <ProductModal
        product={inspectProduct}
        currentCurrency={currentCurrency}
        currentLanguage={currentLanguage}
        onClose={() => setInspectProduct(null)}
        onAddToCart={(product, color, monogram, size) =>
          handleAddToCart(product, color, monogram, size)
        }
        onBuyItNow={(product, color, monogram, size) =>
          handleBuyItNow(product, color, monogram, size)
        }
        onOpenDetailPage={(product) => handleOpenDetail(product)}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        currentCurrency={currentCurrency}
        currentLanguage={currentLanguage}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      <BespokeModal
        isOpen={isBespokeOpen}
        onClose={() => setIsBespokeOpen(false)}
      />

      <WhatsAppConfigModal
        isOpen={isWhatsAppConfigOpen}
        onClose={() => setIsWhatsAppConfigOpen(false)}
        onNumberChanged={(newNum) => setWaNumber(newNum)}
      />

      {/* DECRUM-Style Country and Currency Selection Modal */}
      <CountryCurrencyModal
        isOpen={isCountryModalOpen}
        onClose={() => setIsCountryModalOpen(false)}
        currentCurrency={currentCurrency}
        selectedCountryCode={selectedCountry?.code}
        onSelectCountryAndCurrency={(country, currency) => {
          setSelectedCountry(country);
          setCurrentCurrency(currency);
          try {
            localStorage.setItem('sialvant_country', country.code);
            localStorage.setItem('sialvant_currency', currency);
          } catch {}
        }}
      />
    </div>
  );
}
