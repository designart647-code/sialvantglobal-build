import React, { useState } from 'react';
import { X, Sparkles, MessageCircle, ShieldCheck } from 'lucide-react';
import { createBespokeWhatsAppUrl } from '../utils/whatsapp';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const BespokeModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    productType: 'Custom Made-to-Measure Leather Jacket',
    leatherPreference: 'Full-Grain Drum-Dyed Cowhide (1.2mm)',
    color: 'Vintage Cognac Brown',
    quantity: 'Single Bespoke Piece (1)',
    monogramText: '',
    notes: '',
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const url = createBespokeWhatsAppUrl(formData);
    window.open(url, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-white rounded-lg shadow-2xl border border-[#ECE3D7] overflow-hidden">
        {/* Header */}
        <div className="bg-[#1F1511] text-white p-5 flex items-center justify-between border-b border-[#D4AF37]/30">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-cinzel text-lg font-bold tracking-wide">
                Bespoke Leather Craft & Bulk Export
              </h3>
              <p className="text-xs text-[#DFD5C8]">
                Custom made-to-measure pieces & wholesale inquiries
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-full transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto text-xs">
          <div>
            <label className="block font-semibold text-[#1F1511] uppercase tracking-wider mb-1">
              What would you like us to craft? *
            </label>
            <select
              value={formData.productType}
              onChange={(e) => setFormData({ ...formData, productType: e.target.value })}
              className="w-full px-3 py-2 bg-white border border-[#ECE3D7] rounded-xs focus:ring-1 focus:ring-[#8E5431] focus:outline-none"
            >
              <option value="Custom Made-to-Measure Leather Jacket">Custom Made-to-Measure Leather Jacket</option>
              <option value="Bespoke Travel Bag / Briefcase with Custom Dimensions">Bespoke Travel Bag / Briefcase with Custom Dimensions</option>
              <option value="Corporate Monogrammed Wallets (Gift Sets)">Corporate Monogrammed Wallets (Gift Sets)</option>
              <option value="Custom Heavy Duty Single-Piece Belt">Custom Heavy Duty Single-Piece Belt</option>
              <option value="Restaurant / Hospitality Leather Menu Covers">Restaurant / Hospitality Leather Menu Covers</option>
              <option value="International Wholesale & OEM Export Inquiry">International Wholesale & OEM Export Inquiry</option>
              <option value="Special Custom Pattern / Prototype">Special Custom Pattern / Prototype</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-[#1F1511] uppercase tracking-wider mb-1">
                Preferred Leather Grade *
              </label>
              <select
                value={formData.leatherPreference}
                onChange={(e) => setFormData({ ...formData, leatherPreference: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-[#ECE3D7] rounded-xs focus:ring-1 focus:ring-[#8E5431] focus:outline-none"
              >
                <option value="Full-Grain Drum-Dyed Cowhide (1.2mm)">Full-Grain Cowhide (1.2mm - Supple)</option>
                <option value="English Bridle Harness Leather (4.0mm)">Heavy Bridle Harness Leather (4.0mm)</option>
                <option value="Vegetable-Tanned Pull-Up Buffalo (2.2mm)">Veg-Tan Pull-Up Buffalo (2.2mm)</option>
                <option value="Italian-Style Tuscan Pueblo Leather">Tuscan Pueblo Veg-Tan (Textured)</option>
                <option value="Suede / Nubuck Soft Finish">Suede / Velour Nubuck</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-[#1F1511] uppercase tracking-wider mb-1">
                Leather Tone / Color *
              </label>
              <select
                value={formData.color}
                onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-[#ECE3D7] rounded-xs focus:ring-1 focus:ring-[#8E5431] focus:outline-none"
              >
                <option value="Vintage Cognac Brown">Vintage Cognac Brown</option>
                <option value="Dark Espresso Walnut">Dark Espresso Walnut</option>
                <option value="Pitch Midnight Black">Pitch Midnight Black</option>
                <option value="Raw Natural Veg-Tan (Untreated)">Raw Natural Veg-Tan (Grows Patina)</option>
                <option value="Forest Olive Green">Forest Olive Green</option>
                <option value="Navy Artisan Blue">Navy Artisan Blue</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-[#1F1511] uppercase tracking-wider mb-1">
                Quantity *
              </label>
              <select
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-[#ECE3D7] rounded-xs focus:ring-1 focus:ring-[#8E5431] focus:outline-none"
              >
                <option value="Single Bespoke Piece (1)">Single Bespoke Piece (1)</option>
                <option value="Small Batch (2 - 10 pieces)">Small Batch (2 - 10 pieces)</option>
                <option value="Corporate Order (25 - 100 pieces)">Corporate Order (25 - 100 pieces)</option>
                <option value="Wholesale Export Container (100+ pieces)">Wholesale Export (100+ pieces)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-[#1F1511] uppercase tracking-wider mb-1">
                Custom Stamping / Logo (Optional)
              </label>
              <input
                type="text"
                value={formData.monogramText}
                onChange={(e) => setFormData({ ...formData, monogramText: e.target.value })}
                placeholder="e.g. Initials 'R.K.' or Brand Logo"
                className="w-full px-3 py-2 bg-white border border-[#ECE3D7] rounded-xs focus:ring-1 focus:ring-[#8E5431] focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-[#1F1511] uppercase tracking-wider mb-1">
              Specific Dimensions, Sizing, or Reference Details
            </label>
            <textarea
              rows={3}
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="e.g. Chest 42 inches, sleeve 26 inches, antique brass zippers, or share photo reference via WhatsApp."
              className="w-full px-3 py-2 bg-white border border-[#ECE3D7] rounded-xs focus:ring-1 focus:ring-[#8E5431] focus:outline-none"
            />
          </div>

          <div className="bg-[#F9F6F0] p-3 rounded-md border border-[#ECE3D7] flex items-start gap-2.5 text-[#6B6865]">
            <ShieldCheck className="w-4 h-4 text-[#8E5431] shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              Our lead craftsman will calculate hide footage, hardware sourcing, and estimated crafting days, replying directly to you on WhatsApp with an exact quote.
            </p>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#ECE3D7]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-200 text-gray-700 hover:bg-gray-100 rounded-xs transition font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-[#25D366] hover:bg-[#1eb857] text-white rounded-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-md transition cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>Submit Inquiry on WhatsApp</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
