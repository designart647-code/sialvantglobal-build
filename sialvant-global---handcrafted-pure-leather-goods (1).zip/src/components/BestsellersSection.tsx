import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';
import { CurrencyCode, LanguageCode, Product } from '../types';
import { TRANSLATIONS } from '../data/translations';
import { ProductCard } from './ProductCard';

interface Props {
  products: Product[];
  currentCurrency: CurrencyCode;
  currentLanguage?: LanguageCode;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, selectedColor: string) => void;
  onBuyItNow?: (product: Product, selectedColor: string) => void;
  onViewAll: () => void;
}

export const BestsellersSection: React.FC<Props> = ({
  products,
  currentCurrency,
  currentLanguage = 'en',
  onQuickView,
  onAddToCart,
  onBuyItNow,
  onViewAll,
}) => {
  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;
  // Select the top 4 flagship bestsellers
  const bestsellers = products.slice(0, 4);

  return (
    <section className="py-20 sm:py-24 bg-[#FFFDF9] border-t border-[#ECE3D7] relative" id="bestsellers">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#ECE3D7]">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#8E5431] uppercase tracking-[0.25em] mb-2">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{t.bestsellersTag}</span>
            </div>
            <h2 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold text-[#120B08] tracking-tight">
              {t.bestsellersTitle}
            </h2>
            <p className="text-xs sm:text-sm text-[#6B6865] mt-2 max-w-xl">
              {t.bestsellersSubtitle}
            </p>
          </div>

          <button
            onClick={onViewAll}
            className="mt-4 md:mt-0 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.15em] text-[#8E5431] hover:text-[#120B08] group transition cursor-pointer"
          >
            <span>{t.btnViewAllProducts}</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* 4 Bestsellers Grid: 4 per row on desktop, 2 on mobile */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-6 lg:gap-8">
          {bestsellers.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              currentCurrency={currentCurrency}
              currentLanguage={currentLanguage}
              onQuickView={onQuickView}
              onAddToCart={onAddToCart}
              onBuyItNow={onBuyItNow}
              isCompact={false}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
