import React, { useState, useEffect } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, MessageCircle, Copy, Check, Truck, ShieldCheck, Building2, FileText, Mail } from 'lucide-react';
import { CartItem, CurrencyCode, CustomerOrderDetails, LanguageCode } from '../types';
import { CURRENCY_CONFIGS } from '../data/products';
import { TRANSLATIONS } from '../data/translations';
import { createCartWhatsAppUrl, BUSINESS_PHONE_RAW, BUSINESS_EMAIL } from '../utils/whatsapp';

interface QuantityInputProps {
  quantity: number;
  onUpdate: (qty: number) => void;
  onRemove: () => void;
}

/**
 * Dedicated quantity input allowing keyboard typing (whole positive numbers only)
 * alongside +/- buttons. Automatically sanitizes letters, negatives, decimals, and zeros.
 */
const CartItemQuantityInput: React.FC<QuantityInputProps> = ({
  quantity,
  onUpdate,
  onRemove,
}) => {
  const [localVal, setLocalVal] = useState(quantity.toString());

  useEffect(() => {
    setLocalVal(quantity.toString());
  }, [quantity]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    const digitsOnly = raw.replace(/\D/g, '');
    setLocalVal(digitsOnly);

    if (digitsOnly !== '') {
      const parsed = parseInt(digitsOnly, 10);
      if (parsed > 0) {
        onUpdate(parsed);
      }
    }
  };

  const handleBlur = () => {
    if (!localVal || localVal === '0') {
      setLocalVal('1');
      onUpdate(1);
    } else {
      const parsed = parseInt(localVal, 10);
      if (parsed > 0) {
        setLocalVal(parsed.toString());
        onUpdate(parsed);
      } else {
        setLocalVal('1');
        onUpdate(1);
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (['e', 'E', '+', '-', '.', ','].includes(e.key)) {
      e.preventDefault();
    }
    if (e.key === 'Enter') {
      (e.target as HTMLInputElement).blur();
    }
  };

  return (
    <div className="flex items-center border border-[#ECE3D7] rounded-xs bg-[#F9F6F0] overflow-hidden">
      <button
        type="button"
        onClick={() => {
          if (quantity > 1) {
            onUpdate(quantity - 1);
          } else {
            onRemove();
          }
        }}
        className="px-2.5 py-1 text-xs text-gray-700 hover:bg-[#ECE3D7] hover:text-black transition cursor-pointer"
        aria-label="Decrease quantity"
        title="Decrease quantity"
      >
        <Minus className="w-3 h-3" />
      </button>
      <input
        type="text"
        inputMode="numeric"
        pattern="[0-9]*"
        value={localVal}
        onChange={handleChange}
        onBlur={handleBlur}
        onKeyDown={handleKeyDown}
        className="w-12 text-center text-xs font-bold text-[#1F1511] bg-white border-x border-[#ECE3D7] py-1 focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
        aria-label="Quantity"
        title="Type quantity"
      />
      <button
        type="button"
        onClick={() => onUpdate(quantity + 1)}
        className="px-2.5 py-1 text-xs text-gray-700 hover:bg-[#ECE3D7] hover:text-black transition cursor-pointer"
        aria-label="Increase quantity"
        title="Increase quantity"
      >
        <Plus className="w-3 h-3" />
      </button>
    </div>
  );
};

interface Props {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  currentCurrency: CurrencyCode;
  currentLanguage?: LanguageCode;
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<Props> = ({
  isOpen,
  onClose,
  cartItems,
  currentCurrency,
  currentLanguage = 'en',
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [details, setDetails] = useState<CustomerOrderDetails>({
    name: '',
    phone: '',
    city: '',
    address: '',
    country: 'United States',
    notes: '',
    paymentPreference: 'card',
  });

  const [drawerMode, setDrawerMode] = useState<'checkout' | 'inquiry'>('checkout');
  const [inquiryDetails, setInquiryDetails] = useState({
    companyName: '',
    contactPerson: '',
    email: '',
    country: 'United States',
    batchSize: '25 – 49 units (Commercial Tier)',
    brandingType: 'Heat Blind Debossed Logo',
    notes: '',
  });

  const [copiedInvoice, setCopiedInvoice] = useState(false);
  const [copiedInquiry, setCopiedInquiry] = useState(false);

  if (!isOpen) return null;

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;
  const currencyConfig = CURRENCY_CONFIGS[currentCurrency] || CURRENCY_CONFIGS.USD;

  // Calculate in USD
  const subtotalUSD = cartItems.reduce(
    (sum, item) => sum + item.product.priceUSD * item.quantity,
    0
  );

  // Complimentary global express shipping over $150 USD, otherwise standard flat $25 USD
  const shippingUSD = subtotalUSD === 0 ? 0 : subtotalUSD >= 150 ? 0 : 25;
  const totalUSD = subtotalUSD + shippingUSD;

  const formattedSubtotal = currencyConfig.format(subtotalUSD);
  const formattedShipping =
    subtotalUSD === 0
      ? '—'
      : shippingUSD === 0
      ? t.cartFreeShipping
      : currencyConfig.format(shippingUSD);
  const formattedTotal = currencyConfig.format(totalUSD);

  const handleCheckoutWhatsApp = () => {
    const url = createCartWhatsAppUrl(
      cartItems,
      details,
      formattedTotal,
      shippingUSD === 0 ? t.cartFreeShipping : formattedShipping,
      currentCurrency
    );
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleCopyInvoice = () => {
    let text = `SIALVANTGLOBAL INDUSTRIES - OFFICIAL ORDER INVOICE\n\n`;
    cartItems.forEach((item, idx) => {
      const itemSubtotal = currencyConfig.format(item.product.priceUSD * item.quantity);
      text += `${idx + 1}. ${item.product.name} (x${item.quantity}) - Color: ${item.selectedColor}${
        item.monogramInitials ? ` [Monogram: ${item.monogramInitials.toUpperCase()}]` : ''
      }\n   ${itemSubtotal}\n`;
    });
    text += `\nSubtotal: ${formattedSubtotal}\nExpress Delivery: ${formattedShipping}\nGrand Total: ${formattedTotal} (${currentCurrency})\n`;
    text += `\nRecipient: ${details.name || 'Valued Client'}\nPhone/WA: ${details.phone || 'Provided via WhatsApp'}\nDestination: ${details.city}, ${details.country}\nAddress: ${details.address || 'Standard Delivery'}\nPayment Preference: ${details.paymentPreference.toUpperCase()}`;

    navigator.clipboard.writeText(text);
    setCopiedInvoice(true);
    setTimeout(() => setCopiedInvoice(false), 2000);
  };

  const handleInquiryBasketWhatsApp = () => {
    let itemsText = '';
    cartItems.forEach((item, idx) => {
      itemsText += `${idx + 1}. *${item.product.name}*\n   - Selected Color: ${item.selectedColor}\n   - Leather: ${item.product.leatherType}\n   - Sample Qty: ${item.quantity}\n`;
    });

    const message = `📋 *WHOLESALE & EXPORT INQUIRY BASKET - SIALVANTGLOBAL INDUSTRIES* 📋\n\n` +
      `Hello SIALVANTGLOBAL INDUSTRIES Export Desk!\n` +
      `We would like to request an official wholesale quotation & manufacturing timeline for the following items in our Inquiry Basket:\n\n` +
      `📦 *INQUIRY BASKET ITEMS:*\n${itemsText}\n` +
      `🏢 *B2B & CLIENT SPECIFICATIONS:*\n` +
      `• Company / Store: ${inquiryDetails.companyName || 'Wholesale Buyer'}\n` +
      `• Contact Person: ${inquiryDetails.contactPerson || details.name || 'Valued Client'}\n` +
      `• Destination: ${inquiryDetails.country}\n` +
      `• Estimated Target Batch: ${inquiryDetails.batchSize}\n` +
      `• Custom Logo / Debossing: ${inquiryDetails.brandingType}\n` +
      (inquiryDetails.notes ? `• Custom Requirements: ${inquiryDetails.notes}\n` : '') +
      `\nPlease share FOB Sialkot export volume pricing, production lead time, and sample confirmation details. Thank you!`;

    const url = `https://wa.me/${BUSINESS_PHONE_RAW}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleCopyInquiry = () => {
    let itemsText = '';
    cartItems.forEach((item, idx) => {
      itemsText += `${idx + 1}. ${item.product.name} (Color: ${item.selectedColor}, Leather: ${item.product.leatherType}, Quantity: ${item.quantity})\n`;
    });

    const text = `SIALVANTGLOBAL INDUSTRIES — OFFICIAL WHOLESALE INQUIRY SPECIFICATION SHEET\n` +
      `Date: ${new Date().toLocaleDateString()}\n\n` +
      `SELECTED INQUIRY BASKET ITEMS:\n${itemsText}\n` +
      `B2B SPECIFICATIONS:\n` +
      `Company / Store: ${inquiryDetails.companyName || 'Not specified'}\n` +
      `Contact Person: ${inquiryDetails.contactPerson || details.name || 'Not specified'}\n` +
      `Target Batch Volume: ${inquiryDetails.batchSize}\n` +
      `Custom Logo / Branding: ${inquiryDetails.brandingType}\n` +
      `Destination: ${inquiryDetails.country}\n` +
      (inquiryDetails.notes ? `Special Instructions: ${inquiryDetails.notes}\n` : '') +
      `\nOfficial Manufacturer: SIALVANTGLOBAL INDUSTRIES, Sialkot 51410, Pakistan\nEmail: ${BUSINESS_EMAIL}\nWhatsApp: +${BUSINESS_PHONE_RAW}`;

    navigator.clipboard.writeText(text);
    setCopiedInquiry(true);
    setTimeout(() => setCopiedInquiry(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-white h-full shadow-2xl flex flex-col justify-between border-l border-[#ECE3D7] animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#ECE3D7] flex items-center justify-between bg-[#F9F6F0]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#8E5431]/10 text-[#8E5431] flex items-center justify-center">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-cinzel text-lg font-bold text-[#1F1511]">
                {drawerMode === 'checkout' ? t.cartTitle : 'Wholesale Inquiry Basket'}
              </h2>
              <p className="text-xs text-[#6B6865]">
                {cartItems.length} {cartItems.length === 1 ? 'item selected' : 'items selected'} &bull; {drawerMode === 'checkout' ? 'Retail Checkout' : 'B2B Quotation'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {cartItems.length > 0 && (
              <button
                onClick={onClearCart}
                className="text-xs text-gray-500 hover:text-red-700 transition px-2 py-1 cursor-pointer"
              >
                Clear
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-gray-500 hover:text-black rounded-full hover:bg-gray-200 transition cursor-pointer"
              aria-label="Close bag"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Dual Mode Switcher: Retail Checkout vs Wholesale Inquiry Basket */}
        <div className="grid grid-cols-2 p-1.5 bg-[#EDE4D8] border-b border-[#ECE3D7] text-xs font-semibold gap-1">
          <button
            type="button"
            onClick={() => setDrawerMode('checkout')}
            className={`py-2 px-3 rounded-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              drawerMode === 'checkout'
                ? 'bg-[#120B08] text-white shadow-xs font-bold'
                : 'text-[#6B6865] hover:text-[#120B08] hover:bg-white/40'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Retail Checkout</span>
          </button>
          <button
            type="button"
            onClick={() => setDrawerMode('inquiry')}
            className={`py-2 px-3 rounded-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              drawerMode === 'inquiry'
                ? 'bg-[#8E5431] text-white shadow-xs font-bold'
                : 'text-[#6B6865] hover:text-[#8E5431] hover:bg-white/40'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Inquiry Basket (B2B)</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {cartItems.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-16 h-16 mx-auto rounded-full bg-[#F1ECE3] text-[#8E5431] flex items-center justify-center">
                <ShoppingBag className="w-8 h-8 opacity-60" />
              </div>
              <h3 className="font-cinzel text-lg font-bold text-[#1F1511]">
                {t.cartEmpty}
              </h3>
              <p className="text-xs text-[#6B6865] max-w-xs mx-auto">
                {t.cartEmptySub}
              </p>
              <button
                onClick={onClose}
                className="mt-3 inline-block bg-[#1F1511] hover:bg-[#8E5431] text-white text-xs font-semibold uppercase tracking-wider px-6 py-2.5 rounded-xs transition cursor-pointer"
              >
                {t.btnExploreCollection}
              </button>
            </div>
          ) : (
            <>
              {/* Items List */}
              <div className="space-y-4">
                {cartItems.map((item, index) => {
                  const itemPrice = currencyConfig.format(
                    item.product.priceUSD * item.quantity
                  );
                  return (
                    <div
                      key={`${item.product.id}-${item.selectedColor}-${index}`}
                      className="flex gap-3.5 p-3 rounded-md border border-[#ECE3D7] bg-white relative group"
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-20 h-20 object-cover rounded-xs border border-[#ECE3D7] shrink-0"
                      />
                      <div className="flex-1 min-w-0 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start">
                            <h4 className="font-cinzel text-sm font-bold text-[#1F1511] truncate pr-4">
                              {item.product.name}
                            </h4>
                            <button
                              onClick={() => onRemoveItem(index)}
                              className="text-gray-400 hover:text-red-600 transition p-1 cursor-pointer"
                              title="Remove item"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                          <div className="text-[11px] text-[#6B6865] space-y-0.5 mt-0.5">
                            <p>Color: <span className="font-medium text-[#1F1511]">{item.selectedColor}</span></p>
                            {item.monogramInitials && (
                              <p className="text-[#8E5431] font-semibold">
                                Monogram: [{item.monogramInitials}]
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-100">
                          <CartItemQuantityInput
                            quantity={item.quantity}
                            onUpdate={(newQty) => onUpdateQuantity(index, newQty)}
                            onRemove={() => onRemoveItem(index)}
                          />

                          <span className="text-sm font-bold text-[#8E5431]">
                            {itemPrice}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {drawerMode === 'checkout' ? (
                /* Delivery Details Form (Retail Checkout) */
                <div className="bg-[#F9F6F0] p-4 rounded-md border border-[#ECE3D7] space-y-3">
                  <div className="flex items-center justify-between pb-1 border-b border-[#ECE3D7]">
                    <h4 className="font-cinzel text-xs font-bold text-[#1F1511] uppercase tracking-wider">
                      Delivery & Contact Details
                    </h4>
                    <span className="text-[10px] text-[#8E5431] font-medium">
                      Worldwide Express Dispatch
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                    <div>
                      <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        value={details.name}
                        onChange={(e) => setDetails({ ...details, name: e.target.value })}
                        placeholder="e.g. Marcus Vance"
                        className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                        Phone / WhatsApp *
                      </label>
                      <input
                        type="tel"
                        value={details.phone}
                        onChange={(e) => setDetails({ ...details, phone: e.target.value })}
                        placeholder="+1 (555) 019-2834"
                        className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                    <div>
                      <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                        Destination Country
                      </label>
                      <select
                        value={details.country}
                        onChange={(e) => setDetails({ ...details, country: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                      >
                        <option value="United States">United States</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="Germany">Germany (Deutschland)</option>
                        <option value="France">France</option>
                        <option value="Spain">Spain (España)</option>
                        <option value="Canada">Canada</option>
                        <option value="Australia">Australia</option>
                        <option value="United Arab Emirates">United Arab Emirates</option>
                        <option value="Saudi Arabia">Saudi Arabia</option>
                        <option value="Other International">Other Worldwide Destination</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                        City
                      </label>
                      <input
                        type="text"
                        value={details.city}
                        onChange={(e) => setDetails({ ...details, city: e.target.value })}
                        placeholder="e.g. New York, London, Berlin"
                        className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                      />
                    </div>
                  </div>

                  <div className="text-xs">
                    <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                      Street Address / House No.
                    </label>
                    <input
                      type="text"
                      value={details.address}
                      onChange={(e) => setDetails({ ...details, address: e.target.value })}
                      placeholder="Street, Building, Apartment, Postal Code"
                      className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                    />
                  </div>

                  <div className="text-xs">
                    <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                      Payment Preference
                    </label>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        type="button"
                        onClick={() => setDetails({ ...details, paymentPreference: 'card' })}
                        className={`p-1.5 text-[11px] text-center rounded-xs border cursor-pointer ${
                          details.paymentPreference === 'card'
                            ? 'border-[#8E5431] bg-[#1F1511] text-white font-semibold'
                            : 'border-gray-300 bg-white text-gray-700'
                        }`}
                      >
                        Credit / Debit Card
                      </button>
                      <button
                        type="button"
                        onClick={() => setDetails({ ...details, paymentPreference: 'bank_transfer' })}
                        className={`p-1.5 text-[11px] text-center rounded-xs border cursor-pointer ${
                          details.paymentPreference === 'bank_transfer'
                            ? 'border-[#8E5431] bg-[#1F1511] text-white font-semibold'
                            : 'border-gray-300 bg-white text-gray-700'
                        }`}
                      >
                        Bank Wire (SWIFT)
                      </button>
                      <button
                        type="button"
                        onClick={() => setDetails({ ...details, paymentPreference: 'whatsapp' })}
                        className={`p-1.5 text-[11px] text-center rounded-xs border cursor-pointer ${
                          details.paymentPreference === 'whatsapp'
                            ? 'border-[#8E5431] bg-[#1F1511] text-white font-semibold'
                            : 'border-gray-300 bg-white text-gray-700'
                        }`}
                      >
                        WhatsApp Direct
                      </button>
                    </div>
                  </div>

                  <div className="text-xs">
                    <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                      Special Instructions (Optional)
                    </label>
                    <input
                      type="text"
                      value={details.notes}
                      onChange={(e) => setDetails({ ...details, notes: e.target.value })}
                      placeholder="e.g. Gift packaging, urgent express request, custom sizing"
                      className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                    />
                  </div>
                </div>
              ) : (
                /* Wholesale & Export Inquiry Basket Specifications (B2B) */
                <div className="bg-[#FAF4EB] p-4 rounded-md border border-[#8E5431]/30 space-y-3.5">
                  <div className="flex items-center justify-between pb-1.5 border-b border-[#ECE3D7]">
                    <div className="flex items-center gap-1.5">
                      <Building2 className="w-4 h-4 text-[#8E5431]" />
                      <h4 className="font-cinzel text-xs font-bold text-[#1F1511] uppercase tracking-wider">
                        B2B Inquiry Specifications
                      </h4>
                    </div>
                    <span className="text-[10px] text-[#8E5431] font-bold bg-white px-2 py-0.5 rounded-xs border border-[#ECE3D7]">
                      Direct Workshop RFQ
                    </span>
                  </div>

                  <p className="text-[11px] text-[#6B6865] leading-relaxed">
                    Submit your selected basket for tiered volume discounts, custom private-label branding, and international freight container quotes.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                    <div>
                      <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                        Company / Store / Boutique Name *
                      </label>
                      <input
                        type="text"
                        value={inquiryDetails.companyName}
                        onChange={(e) => setInquiryDetails({ ...inquiryDetails, companyName: e.target.value })}
                        placeholder="e.g. Harrington Goods Co."
                        className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                        Contact Person / Buyer *
                      </label>
                      <input
                        type="text"
                        value={inquiryDetails.contactPerson}
                        onChange={(e) => setInquiryDetails({ ...inquiryDetails, contactPerson: e.target.value })}
                        placeholder="e.g. Edward Sterling"
                        className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                    <div>
                      <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                        Target Order Volume / Tier
                      </label>
                      <select
                        value={inquiryDetails.batchSize}
                        onChange={(e) => setInquiryDetails({ ...inquiryDetails, batchSize: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                      >
                        <option value="10 – 24 units (Sample Run)">10 – 24 units (Sample Run)</option>
                        <option value="25 – 49 units (Commercial Tier)">25 – 49 units (Commercial Tier)</option>
                        <option value="50 – 149 units (Volume Tier)">50 – 149 units (Volume Tier)</option>
                        <option value="150 – 499 units (Master Batch)">150 – 499 units (Master Batch)</option>
                        <option value="500+ units (Full Container / OEM)">500+ units (Full Container / OEM)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                        Logo & Custom Branding
                      </label>
                      <select
                        value={inquiryDetails.brandingType}
                        onChange={(e) => setInquiryDetails({ ...inquiryDetails, brandingType: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                      >
                        <option value="Heat Blind Debossed Logo">Heat Blind Debossed Logo</option>
                        <option value="Metallic Gold Foil Stamping">Metallic Gold Foil Stamping</option>
                        <option value="Metallic Silver Foil Stamping">Metallic Silver Foil Stamping</option>
                        <option value="Custom Engraved Hardware">Custom Engraved Hardware</option>
                        <option value="Plain / Unbranded (Private Label)">Plain / Unbranded (Private Label)</option>
                      </select>
                    </div>
                  </div>

                  <div className="text-xs">
                    <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                      Destination Country / Delivery Port
                    </label>
                    <input
                      type="text"
                      value={inquiryDetails.country}
                      onChange={(e) => setInquiryDetails({ ...inquiryDetails, country: e.target.value })}
                      placeholder="e.g. United States / Port of New York"
                      className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                    />
                  </div>

                  <div className="text-xs">
                    <label className="block text-[11px] font-medium text-[#1F1511] mb-1">
                      Specific Inquiries / Custom Specifications
                    </label>
                    <textarea
                      rows={2}
                      value={inquiryDetails.notes}
                      onChange={(e) => setInquiryDetails({ ...inquiryDetails, notes: e.target.value })}
                      placeholder="Specify custom leather tannage, bespoke dimensions, gift packaging, or target lead time requirements..."
                      className="w-full px-2.5 py-1.5 bg-white border border-[#ECE3D7] rounded-xs focus:outline-none focus:ring-1 focus:ring-[#8E5431] resize-none"
                    />
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer Summary & Checkout / Inquiry Actions */}
        {cartItems.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-[#ECE3D7] bg-[#F9F6F0] space-y-3">
            {drawerMode === 'checkout' ? (
              /* Retail Checkout Summary */
              <>
                <div className="space-y-1.5 text-xs text-[#6B6865]">
                  <div className="flex justify-between">
                    <span>{t.cartSubtotal}</span>
                    <span className="font-semibold text-[#1F1511]">{formattedSubtotal}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5 text-[#8E5431]" />
                      {t.cartShipping} {subtotalUSD >= 150 ? `(${t.cartFreeShipping})` : ''}
                    </span>
                    <span className="font-semibold text-[#1F1511]">{formattedShipping}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-[#1F1511] pt-2 border-t border-[#ECE3D7]">
                    <span className="font-cinzel text-base">{t.cartTotal}</span>
                    <span className="text-base text-[#8E5431]">{formattedTotal}</span>
                  </div>
                </div>

                {/* WhatsApp Checkout Button */}
                <div className="space-y-2 pt-1">
                  <button
                    onClick={handleCheckoutWhatsApp}
                    className="w-full py-3 bg-[#25D366] hover:bg-[#1eb857] text-white rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition transform hover:scale-[1.01] cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 fill-white" />
                    <span>{t.cartCheckoutWA}</span>
                  </button>

                  <button
                    onClick={handleCopyInvoice}
                    className="w-full py-2 bg-white hover:bg-gray-50 text-[#1F1511] border border-[#ECE3D7] rounded-xs font-medium text-xs flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    {copiedInvoice ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Order Invoice Copied to Clipboard</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-gray-500" />
                        <span>{t.cartCopyInvoice}</span>
                      </>
                    )}
                  </button>
                </div>
              </>
            ) : (
              /* Wholesale Inquiry Basket Action */
              <>
                <div className="p-3 bg-[#FAF4EB] border border-[#8E5431]/20 rounded-xs space-y-1 text-xs">
                  <div className="flex items-center justify-between font-bold text-[#1F1511]">
                    <span>Inquiry Basket: {cartItems.length} Products</span>
                    <span className="text-[#8E5431] font-mono">{inquiryDetails.batchSize}</span>
                  </div>
                  <p className="text-[11px] text-[#6B6865]">
                    FOB Sialkot volume wholesale pricing with bespoke logo embossing quotation.
                  </p>
                </div>

                <div className="space-y-2 pt-1">
                  <button
                    onClick={handleInquiryBasketWhatsApp}
                    className="w-full py-3 bg-[#15803D] hover:bg-[#166534] text-white rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition transform hover:scale-[1.01] cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 fill-white" />
                    <span>Submit Inquiry Basket on WhatsApp</span>
                  </button>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={handleCopyInquiry}
                      className="py-2 bg-white hover:bg-gray-50 text-[#1F1511] border border-[#ECE3D7] rounded-xs font-medium text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                    >
                      {copiedInquiry ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-gray-500" />
                          <span>Copy B2B Sheet</span>
                        </>
                      )}
                    </button>

                    <a
                      href={`mailto:${BUSINESS_EMAIL}?subject=${encodeURIComponent(
                        `[Wholesale Inquiry Basket] ${inquiryDetails.companyName || 'B2B Client'} - SIALVANTGLOBAL INDUSTRIES`
                      )}&body=${encodeURIComponent(
                        `Wholesale / Export Inquiry Basket\nCompany: ${inquiryDetails.companyName}\nBuyer: ${inquiryDetails.contactPerson}\nBatch Size: ${inquiryDetails.batchSize}\nBranding: ${inquiryDetails.brandingType}\nDestination: ${inquiryDetails.country}\n\nSelected Products:\n` +
                          cartItems.map((i, idx) => `${idx + 1}. ${i.product.name} (Qty: ${i.quantity}, Color: ${i.selectedColor})`).join('\n')
                      )}`}
                      className="py-2 bg-[#120B08] hover:bg-[#8E5431] text-white rounded-xs font-medium text-xs flex items-center justify-center gap-1.5 transition text-center"
                    >
                      <Mail className="w-3.5 h-3.5" />
                      <span>Email RFQ</span>
                    </a>
                  </div>
                </div>
              </>
            )}

            <div className="flex items-center justify-center gap-2 text-[10px] text-[#6B6865] pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Official SIALVANTGLOBAL INDUSTRIES Artisan Direct Guarantee</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
