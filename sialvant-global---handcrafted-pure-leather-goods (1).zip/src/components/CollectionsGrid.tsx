import React from 'react';
import { ArrowRight } from 'lucide-react';
import { LanguageCode, ProductCategory } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface Props {
  currentLanguage?: LanguageCode;
  onSelectCategory: (category: ProductCategory) => void;
}

const CATEGORY_DATA = [
  {
    id: 'wallets' as ProductCategory,
    titleKey: 'filterWallets' as const,
    subtitles: {
      en: 'Slim Bifolds & Cardholders',
      ar: 'المحافظ وحوامل البطاقات',
      de: 'Geldbörsen & Kartenetuis',
      fr: 'Petite Maroquinerie & Portefeuilles',
      es: 'Carteras y Tarjeteros Finos',
    },
    count: '3 Masterpieces',
    image: 'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=800&q=80',
    desc: {
      en: 'Slim bifolds, RFID passport organizers, and minimalist pueblo cardholders.',
      ar: 'محافظ ثنائية الطي، منظمات جوازات السفر مع حماية RFID، وحوامل بطاقات بويبلو.',
      de: 'Schlanke Bifolds, RFID-Reisepasshüllen und minimalistische Pueblo-Kartenetuis.',
      fr: 'Portefeuilles deux volets, étuis passeport RFID et porte-cartes minimalistes.',
      es: 'Billeteras finas, organizadores de pasaporte RFID y tarjeteros minimalistas.',
    },
  },
  {
    id: 'bags' as ProductCategory,
    titleKey: 'filterBags' as const,
    subtitles: {
      en: 'Messenger Satchels & Briefcases',
      ar: 'حقائب الكتف وحقائب العمل',
      de: 'Kuriertaschen & Aktentaschen',
      fr: 'Sacs Besace & Maletines',
      es: 'Bolsos de Mensajero y Maletines',
    },
    count: '3 Masterpieces',
    image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80',
    desc: {
      en: 'Vintage messenger satchels, 45L weekender duffles, and executive lockable attachés.',
      ar: 'حقائب رسول كلاسيكية، حقائب سفر سعة 45 لتراً، وحقائب عمل دبلوماسية بقفل.',
      de: 'Klassische Kuriertaschen, 45L Weekender-Reisetaschen und abschließbare Attachés.',
      fr: 'Besaces vintage, sacs week-end 45L et porte-documents verrouillables.',
      es: 'Bolsos vintage de mensajero, petates de fin de semana de 45L y maletines con cerradura.',
    },
  },
  {
    id: 'belts' as ProductCategory,
    titleKey: 'filterBelts' as const,
    subtitles: {
      en: 'Single-Piece Bridle Belts',
      ar: 'أحزمة جلدية متينة من قطعة واحدة',
      de: 'Massive Zaumledergürtel',
      fr: 'Ceintures en Cuir de Bride d’un Seul Tenant',
      es: 'Cinturones de Cuero Macizo de una Pieza',
    },
    count: '1 Masterpiece',
    image: 'https://images.unsplash.com/photo-1624222247344-550fb60583dc?auto=format&fit=crop&w=800&q=80',
    desc: {
      en: 'Single-ply 4mm English bridle harness leather with solid brass roller buckles.',
      ar: 'جلد لجام إنجليزي سماكة 4 مم مع مشابك أسطوانية من النحاس الأصفر المصبوب.',
      de: '4 mm dickes englisches Sattlerleder aus einem Stück mit massiven Messingschnallen.',
      fr: 'Cuir harnais de bride anglaise 4 mm d’un seul tenant avec boucle en laiton massif.',
      es: 'Cuero de arnés inglés de 4 mm de una sola pieza con hebillas de rodillo de latón.',
    },
  },
  {
    id: 'jackets' as ProductCategory,
    titleKey: 'filterJackets' as const,
    subtitles: {
      en: 'Hand-Tailored Rider Silhouettes',
      ar: 'سترات راكبي الدراجات مفصلة يدوياً',
      de: 'Maßgeschneiderte Bikerjacken',
      fr: 'Blousons Biker & Motard Sur-Mesure',
      es: 'Chaquetas Biker Hechas a Mano',
    },
    count: '2 Masterpieces',
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=800&q=80',
    desc: {
      en: 'Drum-milled cowhide rider & cafe racer silhouettes with custom sizing available.',
      ar: 'قصات راكبي الدراجات وكافيه ريسر من جلد البقر المعتق مع إمكانية التفصيل على مقاسك.',
      de: 'Gewalktes Rindleder im Rider- und Cafe-Racer-Schnitt mit individueller Maßanpassung.',
      fr: 'Cuir de vachette foulé en coupes Rider et Cafe Racer avec ajustement sur-mesure.',
      es: 'Siluetas rider y cafe racer en cuero vacuno tratado con confección personalizada.',
    },
  },
  {
    id: 'accessories' as ProductCategory,
    titleKey: 'filterAccessories' as const,
    subtitles: {
      en: 'Atelier & Travel Goods',
      ar: 'إكسسوارات السفر والورشة الفاخرة',
      de: 'Atelier- & Reisezubehör',
      fr: 'Accessoires de Voyage & d’Atelier',
      es: 'Artículos de Taller y Viaje',
    },
    count: '3 Masterpieces',
    image: '/src/assets/images/leather_watch_roll_1793899641382.jpg',
    desc: {
      en: '3-slot mechanical watch rolls, master artisan aprons, and brass EDC key pouches.',
      ar: 'لفائف ساعات ميكانيكية لـ 3 ساعات، مآزر الحرفيين الجلدية، ومحافظ مفاتيح نحاسية.',
      de: 'Uhrenrollen für 3 mechanische Uhren, Handwerkerschürzen und Messing-Schlüsseletuis.',
      fr: 'Étuis 3 montres rigides, tabliers d’artisan et pochettes porte-clés en laiton.',
      es: 'Estuches cilíndricos para 3 relojes, delantales de artesano y bolsitas para llaves.',
    },
  },
];

export const CollectionsGrid: React.FC<Props> = ({ currentLanguage = 'en', onSelectCategory }) => {
  const t = TRANSLATIONS[currentLanguage];

  return (
    <section className="py-20 sm:py-24 bg-[#F7F4EE] border-t border-[#ECE3D7]" id="explore-collections">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-[0.25em] font-bold text-[#8E5431]">
            {t.collectionsTag}
          </span>
          <h2 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold text-[#120B08] mt-1 tracking-tight">
            {t.collectionsTitle}
          </h2>
          <div className="w-16 h-0.5 bg-[#D4AF37] mx-auto mt-3" />
          <p className="text-xs sm:text-sm text-[#6B6865] mt-3">
            {t.collectionsSubtitle}
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5 sm:gap-6">
          {CATEGORY_DATA.map((cat) => (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className="group relative bg-[#120B08] rounded-lg overflow-hidden border border-[#ECE3D7]/80 shadow-md hover:shadow-2xl transition-all duration-300 cursor-pointer flex flex-col justify-between"
            >
              <div className="relative aspect-4/5 w-full overflow-hidden bg-black/60">
                <img
                  src={cat.image}
                  alt={t[cat.titleKey]}
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700 opacity-90 group-hover:opacity-100"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#120B08] via-black/40 to-transparent" />

                <div className="absolute top-3 left-3 bg-[#120B08]/80 backdrop-blur-xs text-[#D4AF37] border border-[#D4AF37]/30 text-[9px] font-bold uppercase tracking-widest px-2.5 py-0.5 rounded-xs">
                  {cat.count}
                </div>

                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <p className="text-[11px] text-[#D4AF37] font-serif italic mb-0.5">
                    {(cat.subtitles as Record<string, string>)[currentLanguage] || cat.subtitles.en}
                  </p>
                  <h3 className="font-cinzel text-lg font-bold leading-tight group-hover:text-[#D4AF37] transition-colors">
                    {t[cat.titleKey]}
                  </h3>
                  <p className="text-[11px] text-[#CBC2B7] mt-1.5 line-clamp-2 leading-relaxed font-light">
                    {(cat.desc as Record<string, string>)[currentLanguage] || cat.desc.en}
                  </p>

                  <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[#D4AF37] mt-3 pt-2 border-t border-white/10 group-hover:translate-x-1 transition-transform">
                    <span>{t.btnExploreLine}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
