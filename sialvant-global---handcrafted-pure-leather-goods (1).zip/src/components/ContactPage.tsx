import React, { useState } from 'react';
import {
  Phone,
  Mail,
  MapPin,
  MessageCircle,
  PhoneCall,
  Send,
  CheckCircle2,
  ExternalLink,
  Clock,
  ShieldCheck,
  ArrowLeft,
  ChevronRight,
  AlertCircle,
  HelpCircle,
  Copy,
  Check,
} from 'lucide-react';
import { BUSINESS_PHONE_RAW, BUSINESS_PHONE_DISPLAY, GENERAL_WHATSAPP_MESSAGE } from '../utils/whatsapp';

interface Props {
  onBack: () => void;
  onOpenBespoke?: () => void;
}

interface FormState {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  subject?: string;
  message?: string;
}

export const ContactPage: React.FC<Props> = ({ onBack, onOpenBespoke }) => {
  const [formData, setFormData] = useState<FormState>({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState<{
    inquiryId: string;
    submittedAt: string;
    details: FormState;
  } | null>(null);
  const [copiedEmail, setCopiedEmail] = useState(false);

  const businessEmail = 'info@sialvantglobalindustries.com';
  const businessAddress =
    'Dak Khana Khas Badiana, Tehsil Pasrur, District Sialkot 51410, Punjab, Pakistan.';
  const googleMapsUrl =
    'https://maps.google.com/?q=Dak+Khana+Khas+Badiana+Tehsil+Pasrur+District+Sialkot+51410+Punjab+Pakistan';
  const googleMapsEmbedUrl =
    'https://maps.google.com/maps?q=Badiana%2C%20Tehsil%20Pasrur%2C%20District%20Sialkot%2051410%2C%20Punjab%2C%20Pakistan&t=&z=13&ie=UTF8&iwloc=&output=embed';
  const whatsappUrl = `https://wa.me/${BUSINESS_PHONE_RAW}?text=${encodeURIComponent(
    GENERAL_WHATSAPP_MESSAGE
  )}`;

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Please provide your full name.';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Please provide your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email address (e.g. name@domain.com).';
    }

    if (!formData.subject.trim()) {
      newErrors.subject = 'Please specify the subject of your inquiry.';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Please write your message.';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Please provide a message with at least 10 characters.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    const inquiryId = `SGI-INQ-${Math.floor(100000 + Math.random() * 900000)}`;
    const submittedAt = new Date().toLocaleString('en-US', {
      dateStyle: 'medium',
      timeStyle: 'short',
    });

    const inquiryRecord = {
      inquiryId,
      submittedAt,
      timestamp: Date.now(),
      name: formData.name.trim(),
      email: formData.email.trim(),
      phone: formData.phone.trim() || 'Not specified',
      subject: formData.subject.trim(),
      message: formData.message.trim(),
    };

    // 1. Persist genuine inquiry record to localStorage
    try {
      const existingInquiries = JSON.parse(
        localStorage.getItem('sialvant_contact_inquiries') || '[]'
      );
      existingInquiries.unshift(inquiryRecord);
      localStorage.setItem(
        'sialvant_contact_inquiries',
        JSON.stringify(existingInquiries.slice(0, 50))
      );
    } catch (err) {
      console.warn('Unable to persist inquiry to localStorage', err);
    }

    // 2. Attempt background transmission to server endpoint if present
    try {
      await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(inquiryRecord),
      }).catch(() => {
        // Fallback gracefully if backend is offline or static SPA
      });
    } catch {
      // Ignored for standalone mode
    }

    // 3. Trigger direct mailto draft addressed to info@sialvantglobalindustries.com
    const emailSubject = encodeURIComponent(
      `[${inquiryId}] ${formData.subject.trim()} - SIALVANTGLOBAL INDUSTRIES Inquiry`
    );
    const emailBody = encodeURIComponent(
      `Official Inquiry to SIALVANTGLOBAL INDUSTRIES\n` +
      `Reference Code: ${inquiryId}\n` +
      `Date: ${submittedAt}\n\n` +
      `Client Name: ${formData.name.trim()}\n` +
      `Client Email: ${formData.email.trim()}\n` +
      `Client Phone: ${formData.phone.trim() || 'Not specified'}\n` +
      `Subject: ${formData.subject.trim()}\n\n` +
      `Message Details:\n${formData.message.trim()}\n\n` +
      `--\nTransmitted via sialvantglobalindustries.com direct inquiry desk.`
    );

    // Give a brief realistic processing feel
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmissionSuccess({
        inquiryId,
        submittedAt,
        details: { ...formData },
      });

      // Launch mailto for direct delivery
      try {
        const mailtoLink = `mailto:${businessEmail}?subject=${emailSubject}&body=${emailBody}`;
        const mailAnchor = document.createElement('a');
        mailAnchor.href = mailtoLink;
        mailAnchor.target = '_blank';
        mailAnchor.click();
      } catch (err) {
        console.warn('Mailto link launch failed', err);
      }
    }, 700);
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(businessEmail);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const handleResetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      subject: '',
      message: '',
    });
    setErrors({});
    setSubmissionSuccess(null);
  };

  return (
    <div className="bg-[#FAF4EB] min-h-screen text-[#1F1511] font-sans pb-20">
      {/* Editorial Breadcrumbs & Back Navigation */}
      <div className="border-b border-[#ECE3D7] bg-[#FFFDF9]/80 backdrop-blur-xs sticky top-[108px] z-20">
        <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-[#6B6865]">
            <button
              onClick={onBack}
              className="hover:text-[#8E5431] flex items-center gap-1 font-semibold transition cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Collection</span>
            </button>
            <ChevronRight className="w-3 h-3 text-[#CBC2B7]" />
            <span className="text-[#8E5431] font-bold tracking-wider uppercase">Contact Us</span>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-xs text-[#8E5431] font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Master Artisan & Export Desk Active</span>
          </div>
        </div>
      </div>

      {/* Hero Header Section */}
      <section className="bg-gradient-to-b from-[#1F1511] via-[#120B08] to-[#1F1511] text-white pt-16 pb-20 px-4 sm:px-6 lg:px-8 border-b-2 border-[#D4AF37]/30 relative overflow-hidden">
        {/* Subtle Luxury Pattern Background */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#D4AF37_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

        <div className="max-w-4xl mx-auto text-center relative z-10 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-[#D4AF37]/15 border border-[#D4AF37]/40 rounded-full text-[#D4AF37] text-[10px] sm:text-xs font-bold tracking-[0.25em] uppercase">
            <span>Direct Artisan Inquiry & Global Export Desk</span>
          </div>

          <h1 className="font-cinzel text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-wide text-[#FAF4EB]">
            Connect With SIALVANTGLOBAL INDUSTRIES
          </h1>

          <p className="text-sm sm:text-base text-[#CBC2B7] max-w-2xl mx-auto leading-relaxed">
            Direct communication with our master leathercraft artisans, export department, and bespoke tailoring consultants. We serve individual patrons and international wholesale partners across the USA, UK, Europe, Middle East and worldwide.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-2 text-xs text-[#FAF4EB]/80">
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
              Official Workshop Direct
            </span>
            <span className="text-[#D4AF37]">&bull;</span>
            <span className="inline-flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-[#D4AF37]" />
              Rapid Response (Within 2–4 Hours)
            </span>
            <span className="text-[#D4AF37]">&bull;</span>
            <span className="inline-flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-[#D4AF37]" />
              Sialkot 51410, Pakistan
            </span>
          </div>
        </div>
      </section>

      {/* Main Content Area */}
      <div className="max-w-[1520px] mx-auto px-4 sm:px-6 lg:px-8 -mt-10 relative z-10 space-y-12">
        {/* 3 Top Contact Information Cards (Requirement 3) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Phone / WhatsApp */}
          <div className="bg-[#FFFDF9] rounded-lg p-6 sm:p-7 border border-[#ECE3D7] shadow-md hover:shadow-xl hover:border-[#8E5431]/40 transition-all duration-300 flex flex-col justify-between group">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-full bg-[#120B08] text-[#D4AF37] flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                  <PhoneCall className="w-6 h-6" />
                </div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#8E5431] bg-[#FAF4EB] px-2.5 py-1 rounded-full border border-[#ECE3D7]">
                  Calls & Chat
                </span>
              </div>
              <h3 className="font-cinzel text-lg font-bold text-[#1F1511] mb-1">
                Phone / WhatsApp
              </h3>
              <p className="text-xs text-[#6B6865] mb-4">
                Direct phone inquiries and live customer support.
              </p>
              <div className="space-y-1">
                <a
                  href={`tel:+${BUSINESS_PHONE_RAW}`}
                  className="block font-mono text-lg sm:text-xl font-bold text-[#120B08] hover:text-[#8E5431] transition-colors"
                  title="Call our workshop"
                >
                  {BUSINESS_PHONE_DISPLAY}
                </a>
                <p className="text-[11px] text-[#6B6865] flex items-center gap-1">
                  <Clock className="w-3 h-3 text-[#8E5431]" />
                  <span>Mon – Sat: 9:00 AM – 6:00 PM PKT (UTC+5)</span>
                </p>
              </div>
            </div>

            <div className="pt-5 mt-5 border-t border-[#ECE3D7] flex items-center gap-3">
              <a
                href={`tel:+${BUSINESS_PHONE_RAW}`}
                className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold uppercase tracking-wider bg-[#120B08] text-white hover:bg-[#8E5431] rounded-xs transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Now</span>
              </a>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold uppercase tracking-wider bg-[#15803D] hover:bg-[#166534] text-white rounded-xs transition-colors shadow-xs"
                title="WhatsApp Us"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-white text-white" />
                <span>WhatsApp Us</span>
              </a>
            </div>
          </div>

          {/* Card 2: Email */}
          <div className="bg-[#FFFDF9] rounded-lg p-6 sm:p-7 border border-[#ECE3D7] shadow-md hover:shadow-xl hover:border-[#8E5431]/40 transition-all duration-300 flex flex-col justify-between group">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-full bg-[#120B08] text-[#D4AF37] flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                  <Mail className="w-6 h-6" />
                </div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#8E5431] bg-[#FAF4EB] px-2.5 py-1 rounded-full border border-[#ECE3D7]">
                  Official Inbox
                </span>
              </div>
              <h3 className="font-cinzel text-lg font-bold text-[#1F1511] mb-1">
                Email
              </h3>
              <p className="text-xs text-[#6B6865] mb-4">
                Send formal proposals, custom specs, or questions.
              </p>
              <div className="space-y-1">
                <a
                  href={`mailto:${businessEmail}`}
                  className="block font-sans text-base sm:text-lg font-bold text-[#120B08] hover:text-[#8E5431] transition-colors break-all"
                  title="Send email"
                >
                  {businessEmail}
                </a>
                <p className="text-[11px] text-[#6B6865] flex items-center gap-1">
                  <Clock className="w-3 h-3 text-[#8E5431]" />
                  <span>Typically replies within 2–4 business hours</span>
                </p>
              </div>
            </div>

            <div className="pt-5 mt-5 border-t border-[#ECE3D7] flex items-center gap-3">
              <a
                href={`mailto:${businessEmail}`}
                className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold uppercase tracking-wider bg-[#120B08] text-white hover:bg-[#8E5431] rounded-xs transition-colors"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Send Email</span>
              </a>
              <button
                type="button"
                onClick={handleCopyEmail}
                className="inline-flex items-center justify-center gap-1 py-2 px-3 text-xs font-semibold text-[#1F1511] bg-white border border-[#ECE3D7] hover:border-[#1F1511] rounded-xs transition cursor-pointer"
                title="Copy email address"
              >
                {copiedEmail ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-gray-500" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Card 3: Our Location */}
          <div className="bg-[#FFFDF9] rounded-lg p-6 sm:p-7 border border-[#ECE3D7] shadow-md hover:shadow-xl hover:border-[#8E5431]/40 transition-all duration-300 flex flex-col justify-between group">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-full bg-[#120B08] text-[#D4AF37] flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                  <MapPin className="w-6 h-6" />
                </div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#8E5431] bg-[#FAF4EB] px-2.5 py-1 rounded-full border border-[#ECE3D7]">
                  Workshop & Export Hub
                </span>
              </div>
              <h3 className="font-cinzel text-lg font-bold text-[#1F1511] mb-1">
                Our Location
              </h3>
              <p className="text-xs text-[#6B6865] mb-2">
                Authentic workshop & international dispatch center.
              </p>
              <address className="not-italic text-xs sm:text-[13px] text-[#1F1511] font-medium leading-relaxed">
                {businessAddress}
              </address>
            </div>

            <div className="pt-5 mt-5 border-t border-[#ECE3D7]">
              <a
                href={googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold uppercase tracking-wider bg-white border border-[#120B08] text-[#120B08] hover:bg-[#120B08] hover:text-white rounded-xs transition-colors"
                title="View on Google Maps"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Open in Google Maps</span>
              </a>
            </div>
          </div>
        </div>

        {/* Section 4 & 5: Premium Contact Form & Interactive Google Map Side-by-Side */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column (7 cols): Contact Form */}
          <div className="lg:col-span-7 bg-[#FFFDF9] rounded-lg p-6 sm:p-8 md:p-10 border border-[#ECE3D7] shadow-lg">
            <div className="border-b border-[#ECE3D7] pb-5 mb-6">
              <span className="text-[10px] sm:text-xs font-bold tracking-[0.2em] uppercase text-[#8E5431] block mb-1">
                Direct Communication Channel
              </span>
              <h2 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#1F1511]">
                Send Us a Message
              </h2>
              <p className="text-xs sm:text-sm text-[#6B6865] mt-1 leading-relaxed">
                Please complete the form below. Every inquiry is reviewed directly by our master craftsman or international export team.
              </p>
            </div>

            {submissionSuccess ? (
              /* Verified Success State */
              <div className="space-y-6 animate-in fade-in duration-300">
                <div className="bg-[#FAF4EB] border-2 border-emerald-600/40 rounded-lg p-6 sm:p-8 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>

                  <div className="space-y-1">
                    <span className="text-xs font-bold uppercase tracking-widest text-emerald-800">
                      Inquiry Successfully Received & Registered
                    </span>
                    <h3 className="font-cinzel text-xl sm:text-2xl font-bold text-[#1F1511]">
                      Thank You, {submissionSuccess.details.name}
                    </h3>
                  </div>

                  <p className="text-xs sm:text-sm text-[#555] max-w-lg mx-auto leading-relaxed">
                    Your inquiry has been cataloged under Reference ID{' '}
                    <strong className="font-mono text-[#120B08]">{submissionSuccess.inquiryId}</strong>{' '}
                    and addressed directly to{' '}
                    <strong className="text-[#8E5431]">{businessEmail}</strong>. Our workshop team will review your specifications and contact you shortly.
                  </p>

                  {/* Summary Box */}
                  <div className="bg-white rounded-md p-4 border border-[#ECE3D7] text-left text-xs space-y-2 max-w-md mx-auto">
                    <div className="flex justify-between border-b border-[#ECE3D7] pb-1.5">
                      <span className="text-[#6B6865]">Inquiry ID:</span>
                      <span className="font-mono font-bold text-[#120B08]">
                        {submissionSuccess.inquiryId}
                      </span>
                    </div>
                    <div className="flex justify-between border-b border-[#ECE3D7] pb-1.5">
                      <span className="text-[#6B6865]">Email Recipient:</span>
                      <span className="font-medium text-[#120B08]">{businessEmail}</span>
                    </div>
                    <div className="flex justify-between border-b border-[#ECE3D7] pb-1.5">
                      <span className="text-[#6B6865]">Subject:</span>
                      <span className="font-medium text-[#120B08] line-clamp-1">
                        {submissionSuccess.details.subject}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#6B6865]">Timestamp:</span>
                      <span className="text-[#6B6865]">{submissionSuccess.submittedAt}</span>
                    </div>
                  </div>

                  {/* Immediate Action Buttons */}
                  <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <a
                      href={`https://wa.me/${BUSINESS_PHONE_RAW}?text=${encodeURIComponent(
                        `Hello SIALVANTGLOBAL INDUSTRIES, I have submitted an inquiry on your website.\n\nReference ID: ${submissionSuccess.inquiryId}\nName: ${submissionSuccess.details.name}\nSubject: ${submissionSuccess.details.subject}\n\nPlease review my request. Thank you!`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 py-2.5 px-5 bg-[#15803D] hover:bg-[#166534] text-white text-xs font-bold uppercase tracking-wider rounded-xs transition shadow-xs"
                      title="Follow up on WhatsApp"
                    >
                      <MessageCircle className="w-4 h-4 fill-white text-white" />
                      <span>Follow Up on WhatsApp</span>
                    </a>

                    <button
                      type="button"
                      onClick={handleResetForm}
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 py-2.5 px-5 bg-white border border-[#120B08] text-[#120B08] hover:bg-[#120B08] hover:text-white text-xs font-bold uppercase tracking-wider rounded-xs transition cursor-pointer"
                    >
                      <span>Send Another Inquiry</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              /* Contact Form Input Fields */
              <form onSubmit={handleSubmit} className="space-y-5" noValidate>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Your Name */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="contact-name"
                      className="block text-xs font-bold uppercase tracking-wider text-[#1F1511]"
                    >
                      Your Name <span className="text-red-600">*</span>
                    </label>
                    <input
                      id="contact-name"
                      name="name"
                      type="text"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="e.g. William Harrington"
                      className={`w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border rounded-xs transition focus:outline-hidden focus:ring-1 ${
                        errors.name
                          ? 'border-red-500 focus:border-red-600 focus:ring-red-500 bg-red-50/20'
                          : 'border-[#ECE3D7] focus:border-[#8E5431] focus:ring-[#8E5431]'
                      }`}
                      required
                    />
                    {errors.name && (
                      <p className="text-[11px] text-red-600 flex items-center gap-1 mt-1 font-medium">
                        <AlertCircle className="w-3 h-3 shrink-0" />
                        <span>{errors.name}</span>
                      </p>
                    )}
                  </div>

                  {/* Your Email */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="contact-email"
                      className="block text-xs font-bold uppercase tracking-wider text-[#1F1511]"
                    >
                      Your Email <span className="text-red-600">*</span>
                    </label>
                    <input
                      id="contact-email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="e.g. william@harrington.com"
                      className={`w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border rounded-xs transition focus:outline-hidden focus:ring-1 ${
                        errors.email
                          ? 'border-red-500 focus:border-red-600 focus:ring-red-500 bg-red-50/20'
                          : 'border-[#ECE3D7] focus:border-[#8E5431] focus:ring-[#8E5431]'
                      }`}
                      required
                    />
                    {errors.email && (
                      <p className="text-[11px] text-red-600 flex items-center gap-1 mt-1 font-medium">
                        <AlertCircle className="w-3 h-3 shrink-0" />
                        <span>{errors.email}</span>
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Phone Number (Optional) */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="contact-phone"
                      className="block text-xs font-bold uppercase tracking-wider text-[#1F1511]"
                    >
                      Phone Number <span className="text-gray-400 font-normal lowercase">(optional)</span>
                    </label>
                    <input
                      id="contact-phone"
                      name="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="e.g. +1 (555) 234-5678"
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border border-[#ECE3D7] rounded-xs transition focus:outline-hidden focus:border-[#8E5431] focus:ring-1 focus:ring-[#8E5431]"
                    />
                  </div>

                  {/* Subject */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="contact-subject"
                      className="block text-xs font-bold uppercase tracking-wider text-[#1F1511]"
                    >
                      Subject <span className="text-red-600">*</span>
                    </label>
                    <input
                      id="contact-subject"
                      name="subject"
                      type="text"
                      value={formData.subject}
                      onChange={handleChange}
                      placeholder="e.g. Bespoke Duffle Bag Inquiry"
                      list="subject-suggestions"
                      className={`w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border rounded-xs transition focus:outline-hidden focus:ring-1 ${
                        errors.subject
                          ? 'border-red-500 focus:border-red-600 focus:ring-red-500 bg-red-50/20'
                          : 'border-[#ECE3D7] focus:border-[#8E5431] focus:ring-[#8E5431]'
                      }`}
                      required
                    />
                    <datalist id="subject-suggestions">
                      <option value="Custom Bespoke Order" />
                      <option value="Wholesale & Bulk Export Inquiry" />
                      <option value="Leather Jacket Custom Sizing" />
                      <option value="Corporate Gifting & Monogramming" />
                      <option value="International Shipping & Delivery" />
                      <option value="General Product Question" />
                    </datalist>
                    {errors.subject && (
                      <p className="text-[11px] text-red-600 flex items-center gap-1 mt-1 font-medium">
                        <AlertCircle className="w-3 h-3 shrink-0" />
                        <span>{errors.subject}</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* Your Message */}
                <div className="space-y-1.5">
                  <label
                    htmlFor="contact-message"
                    className="block text-xs font-bold uppercase tracking-wider text-[#1F1511]"
                  >
                    Your Message <span className="text-red-600">*</span>
                  </label>
                  <textarea
                    id="contact-message"
                    name="message"
                    rows={5}
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Describe your inquiry, custom dimensions, leather preferences, quantity requirements, or specific requests..."
                    className={`w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border rounded-xs transition focus:outline-hidden focus:ring-1 resize-y ${
                      errors.message
                        ? 'border-red-500 focus:border-red-600 focus:ring-red-500 bg-red-50/20'
                        : 'border-[#ECE3D7] focus:border-[#8E5431] focus:ring-[#8E5431]'
                    }`}
                    required
                  />
                  {errors.message && (
                    <p className="text-[11px] text-red-600 flex items-center gap-1 mt-1 font-medium">
                      <AlertCircle className="w-3 h-3 shrink-0" />
                      <span>{errors.message}</span>
                    </p>
                  )}
                </div>

                {/* Privacy & Direct Dispatch Note */}
                <div className="text-[11px] text-[#6B6865] flex items-start gap-2 bg-[#FAF4EB] p-3 rounded-xs border border-[#ECE3D7]">
                  <ShieldCheck className="w-4 h-4 text-[#8E5431] shrink-0 mt-0.5" />
                  <span>
                    Your details are held strictly confidential. Submissions are dispatched directly to our official corporate mailbox{' '}
                    <strong className="text-[#120B08]">{businessEmail}</strong> with guaranteed response within 2–4 business hours.
                  </span>
                </div>

                {/* Send Message Button (Gold or Black - Requirement 4) */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 py-3.5 px-8 bg-[#120B08] hover:bg-[#8E5431] active:bg-[#6D3F23] text-white font-cinzel text-xs sm:text-sm font-bold uppercase tracking-[0.2em] rounded-xs shadow-md hover:shadow-lg transition-all duration-200 cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed border border-[#D4AF37]/30"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Transmitting Message...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 text-[#D4AF37]" />
                      <span>SEND MESSAGE</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>

          {/* Right Column (5 cols): Google Map & Workshop Facility Details (Requirement 5) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-[#FFFDF9] rounded-lg p-5 sm:p-6 border border-[#ECE3D7] shadow-lg space-y-4">
              <div className="flex items-center justify-between border-b border-[#ECE3D7] pb-3">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#8E5431] block">
                    Workshop & Export Hub
                  </span>
                  <h3 className="font-cinzel text-lg font-bold text-[#1F1511]">
                    Our Sialkot Facility
                  </h3>
                </div>
                <div className="w-9 h-9 rounded-full bg-[#FAF4EB] text-[#8E5431] flex items-center justify-center border border-[#ECE3D7]">
                  <MapPin className="w-4 h-4" />
                </div>
              </div>

              {/* Exact Address Display */}
              <div className="bg-[#FAF4EB] p-3.5 rounded-xs border border-[#ECE3D7] space-y-1.5">
                <p className="text-[10px] font-bold uppercase tracking-wider text-[#8E5431]">
                  Official Postal & Manufacturing Address:
                </p>
                <p className="text-xs sm:text-sm font-semibold text-[#1F1511] leading-relaxed">
                  {businessAddress}
                </p>
                <div className="flex flex-wrap gap-2 pt-1 text-[11px] text-[#6B6865]">
                  <span>Postal Code: <strong>51410</strong></span>
                  <span>&bull;</span>
                  <span>Tehsil: <strong>Pasrur</strong></span>
                  <span>&bull;</span>
                  <span>District: <strong>Sialkot</strong></span>
                </div>
              </div>

              {/* Google Map Embed */}
              <div className="relative rounded-md overflow-hidden border border-[#ECE3D7] aspect-4/3 sm:aspect-16/10 bg-[#ECE3D7]">
                <iframe
                  title="SIALVANTGLOBAL INDUSTRIES Workshop Location"
                  src={googleMapsEmbedUrl}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full"
                />
              </div>

              {/* Open in Google Maps Link Button (Requirement 5) */}
              <a
                href={googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 bg-[#120B08] hover:bg-[#8E5431] text-white text-xs font-bold uppercase tracking-wider rounded-xs transition-colors shadow-xs"
                title="Open location in Google Maps"
              >
                <ExternalLink className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Open in Google Maps</span>
              </a>

              {/* Visiting & Logistics Note */}
              <div className="border-t border-[#ECE3D7] pt-3 text-[11px] text-[#6B6865] space-y-1">
                <p className="font-semibold text-[#1F1511]">
                  International Buyers & Visits:
                </p>
                <p className="leading-relaxed">
                  We welcome international buyers, private label clients, and equestrian sourcing agents by prior appointment. Contact us via WhatsApp or email to schedule your workshop tour.
                </p>
              </div>
            </div>

            {/* Quick Fact Card */}
            <div className="bg-[#120B08] text-[#FAF4EB] rounded-lg p-5 border border-[#2E1D13] space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#D4AF37]">
                <ShieldCheck className="w-4 h-4" />
                <span>Authentic Full-Grain Guarantee</span>
              </div>
              <p className="text-xs text-[#CBC2B7] leading-relaxed">
                Every piece leaving our Badiana, Sialkot workshop is crafted from certified Grade A+ vegetable-tanned hides with hand-burnished edges, saddle-stitching, and solid antique brass hardware.
              </p>
            </div>
          </div>
        </div>

        {/* Section 6: Additional Contact Options (Requirement 6) */}
        <section className="bg-gradient-to-r from-[#1F1511] via-[#2A1810] to-[#1F1511] rounded-lg p-8 sm:p-10 md:p-12 text-white border-2 border-[#D4AF37]/30 shadow-xl relative overflow-hidden">
          {/* Subtle Golden Glow Accent */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-4xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#D4AF37]/15 border border-[#D4AF37]/40 rounded-full text-[#D4AF37] text-[10px] sm:text-xs font-bold tracking-[0.2em] uppercase">
              <span>Bespoke & Commercial Inquiries</span>
            </div>

            <h2 className="font-cinzel text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#FAF4EB]">
              Need Help With a Custom Leather Order?
            </h2>

            <p className="text-xs sm:text-sm md:text-base text-[#CBC2B7] max-w-2xl mx-auto leading-relaxed">
              Our team is ready to assist you with product inquiries, custom designs, leather selection, bulk orders and wholesale inquiries.
            </p>

            {/* Two Action Buttons: WhatsApp Us & Call Our Team (Requirement 6 & 7) */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
              {/* Button 1: WhatsApp Us (Green, WhatsApp icon + text only, NO phone number) */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 py-3.5 px-8 bg-[#15803D] hover:bg-[#166534] active:bg-[#14532D] text-white font-cinzel text-xs sm:text-sm font-bold uppercase tracking-wider rounded-xs shadow-md transition-all duration-200 cursor-pointer"
                title="WhatsApp Us"
              >
                <MessageCircle className="w-4 h-4 fill-white text-white shrink-0" />
                <span>WhatsApp Us</span>
              </a>

              {/* Button 2: Call Our Team */}
              <a
                href={`tel:+${BUSINESS_PHONE_RAW}`}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 py-3.5 px-8 bg-white hover:bg-[#FAF4EB] text-[#120B08] font-cinzel text-xs sm:text-sm font-bold uppercase tracking-wider rounded-xs shadow-md transition-all duration-200 cursor-pointer border border-[#D4AF37]/40"
                title="Call Our Team"
              >
                <PhoneCall className="w-4 h-4 text-[#8E5431] shrink-0" />
                <span>Call Our Team</span>
              </a>
            </div>

            {onOpenBespoke && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={onOpenBespoke}
                  className="text-xs text-[#D4AF37] hover:text-white underline underline-offset-4 tracking-wider uppercase font-semibold transition cursor-pointer"
                >
                  Or Request a Bespoke Monogramming Quote &rarr;
                </button>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};
