import React, { useState, useMemo } from 'react';
import { X, Search, Globe, Check, Sparkles } from 'lucide-react';
import { CurrencyCode, CountryConfig } from '../types';
import { WORLD_COUNTRIES, detectVisitorCountry } from '../data/countries';
import { CURRENCY_CONFIGS } from '../data/currencies';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentCurrency: CurrencyCode;
  onSelectCountryAndCurrency: (country: CountryConfig, currency: CurrencyCode) => void;
  selectedCountryCode?: string;
}

export const CountryCurrencyModal: React.FC<Props> = ({
  isOpen,
  onClose,
  currentCurrency,
  onSelectCountryAndCurrency,
  selectedCountryCode = 'US',
}) => {
  const [search, setSearch] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<string>('All');

  // Suggested country based on visitor's timezone
  const suggestedCountry = useMemo(() => detectVisitorCountry(), []);

  const regions = ['All', 'North America', 'Europe', 'Middle East', 'Asia Pacific', 'Latin America', 'Africa', 'Oceania'];

  const filteredCountries = useMemo(() => {
    return WORLD_COUNTRIES.filter((country) => {
      const matchesRegion = selectedRegion === 'All' || country.region === selectedRegion;
      const q = search.toLowerCase().trim();
      const matchesSearch =
        !q ||
        country.name.toLowerCase().includes(q) ||
        country.code.toLowerCase().includes(q) ||
        country.currency.toLowerCase().includes(q);
      return matchesRegion && matchesSearch;
    });
  }, [search, selectedRegion]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-[#FFFDF9] w-full max-w-3xl rounded-xl shadow-2xl border border-[#ECE3D7] overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-5 bg-[#120B08] text-white flex items-center justify-between border-b border-[#2C1D15]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37]">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-cinzel text-lg font-bold text-[#FAF4EB] tracking-wide">
                Select Delivery Country & Currency
              </h3>
              <p className="text-xs text-[#A59585]">
                Prices and shipping calculations update automatically with live exchange rates.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded-full hover:bg-white/10 transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Location Suggestion Banner */}
        {suggestedCountry && (
          <div className="px-6 py-3 bg-[#F4EFE6] border-b border-[#ECE3D7] flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-[#4A3B32]">
              <Sparkles className="w-3.5 h-3.5 text-[#8E5431]" />
              <span>
                Suggested for your location: <strong className="font-bold text-[#1F1511]">{suggestedCountry.flag} {suggestedCountry.name}</strong> ({suggestedCountry.currency} - {CURRENCY_CONFIGS[suggestedCountry.currency]?.symbol})
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                onSelectCountryAndCurrency(suggestedCountry, suggestedCountry.currency);
                onClose();
              }}
              className="px-3 py-1 bg-[#1F1511] hover:bg-[#8E5431] text-white text-[11px] font-bold uppercase tracking-wider rounded-xs transition cursor-pointer"
            >
              Apply Suggestion
            </button>
          </div>
        )}

        {/* Search & Region Filter Bar */}
        <div className="p-4 sm:p-5 border-b border-[#ECE3D7] bg-white space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by country name, code, or currency (e.g. United Kingdom, GBP, AED, Pakistan)..."
              className="w-full pl-10 pr-4 py-2.5 bg-[#FAF7F2] border border-[#ECE3D7] rounded-md text-xs sm:text-sm text-[#1F1511] focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
              autoFocus
            />
          </div>

          {/* Region Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            {regions.map((reg) => (
              <button
                key={reg}
                type="button"
                onClick={() => setSelectedRegion(reg)}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap transition cursor-pointer font-semibold text-[11px] ${
                  selectedRegion === reg
                    ? 'bg-[#120B08] text-white shadow-xs'
                    : 'bg-[#F4EFE6] text-[#6B6865] hover:text-[#1F1511] hover:bg-[#ECE3D7]'
                }`}
              >
                {reg}
              </button>
            ))}
          </div>
        </div>

        {/* Countries Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#FAF7F2]">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
            {filteredCountries.map((country) => {
              const isSelected = selectedCountryCode === country.code && currentCurrency === country.currency;
              const config = CURRENCY_CONFIGS[country.currency];

              return (
                <button
                  key={`${country.code}-${country.currency}`}
                  type="button"
                  onClick={() => {
                    onSelectCountryAndCurrency(country, country.currency);
                    onClose();
                  }}
                  className={`p-3 rounded-md border text-left flex items-center justify-between transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-white border-[#8E5431] ring-2 ring-[#8E5431]/20 shadow-xs'
                      : 'bg-white/80 hover:bg-white border-[#ECE3D7] hover:border-[#8E5431]/40'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="text-xl shrink-0" role="img" aria-label={country.name}>
                      {country.flag}
                    </span>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-[#1F1511] truncate">{country.name}</p>
                      <p className="text-[11px] text-[#6B6865]">
                        {country.currency} ({config?.symbol || country.currency})
                      </p>
                    </div>
                  </div>

                  {isSelected && (
                    <div className="w-5 h-5 rounded-full bg-[#8E5431] text-white flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {filteredCountries.length === 0 && (
            <div className="py-12 text-center text-xs text-[#6B6865] space-y-2">
              <p className="font-semibold text-sm text-[#1F1511]">No matching countries found</p>
              <p>Try searching for a different country name, currency code, or clear your search.</p>
              <button
                type="button"
                onClick={() => {
                  setSearch('');
                  setSelectedRegion('All');
                }}
                className="mt-2 text-[#8E5431] underline font-bold cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-6 py-3.5 bg-white border-t border-[#ECE3D7] flex items-center justify-between text-xs text-[#6B6865]">
          <span>Default currency: <strong>USD ($)</strong></span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-[#120B08] hover:bg-[#8E5431] text-white rounded-xs font-bold uppercase tracking-wider text-[11px] transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
