import React, { useState } from 'react';
import { Sparkles, Layers, Shield, Clock } from 'lucide-react';
import { LanguageCode } from '../types';

interface Props {
  currentLanguage?: LanguageCode;
}

export const CraftHeritage: React.FC<Props> = ({ currentLanguage = 'en' }) => {
  const [patinaStage, setPatinaStage] = useState<number>(2); // 0: Day 1, 1: 6 Months, 2: 2 Years, 3: 5 Years

  const heritageMap: Record<string, any> = {
    en: {
      originTag: 'Our Artisanal Heritage',
      title: 'The SIALVANTGLOBAL INDUSTRIES Heritage',
      p1: 'At SIALVANTGLOBAL INDUSTRIES, we believe genuine leather is not simply a material, but a symbol of enduring dignity, tradition, and personal legacy. Every single creation is shaped by hand with unwavering patience and meticulous attention to detail.',
      p2: 'Unlike factory-made synthetic alternatives that crack and peel within months, our full-grain leather never deteriorates. Instead, it absorbs the elements and daily wear to develop an extraordinary natural amber patina that becomes richer with every passing year.',
      p3: 'Rooted in Sialkot, Pakistan — the global epicentre of master leathercraft, supplying bespoke saddlery, equestrian goods, and high-fashion luxury to discerning patrons across 4 continents.',
      btnCollection: 'Explore Collection',
      btnInquire: 'Inquire With Master Artisan',
      processTag: 'Artisanal Technique',
      processTitle: 'How Each SIALVANTGLOBAL INDUSTRIES Piece Is Built',
      processSubtitle:
        'A traditional four-step process passed down through generations of Sialkot cobbler guilds.',
      patinaTag: 'The Patina Transformation',
      patinaTitle: 'See How Full-Grain Leather Matures',
      patinaDesc:
        'Synthetic and cheap bonded leather peels, cracks, and degrades after a year. True full-grain vegetable-tanned leather absorbs organic oils, sun rays, and daily contact to develop an increasingly rich, glossy patina.',
      steps: [
        {
          step: '01',
          title: 'Selection of Raw Hides',
          desc: 'Only the top 10% of local Punjab cattle and buff hides are selected. We strictly discard low-grade split cuts or corrected skins with synthetic coatings.',
        },
        {
          step: '02',
          title: 'Organic Vegetable Tanning',
          desc: 'Tanned using natural mimosa, chestnut, and tree barks. This time-honored artisanal method takes up to 45 days, giving our leather its distinctive earthy scent and legendary aging properties.',
        },
        {
          step: '03',
          title: 'Hand-Cutting & Two-Needle Saddle Stitch',
          desc: 'Each panel is hand-cut with cobbler blades. Unlike sewing machines that unravel if one loop snaps, traditional hand saddle-stitching locks every thread independently.',
        },
        {
          step: '04',
          title: 'Beeswax Burnishing & Patina Seal',
          desc: 'Edges are hand-beveled and burnished with raw local organic beeswax and bone folders for hours until they gleam with a glass-smooth mirror finish.',
        },
      ],
      stages: [
        {
          title: 'Day 1: Fresh Off The Bench',
          badge: 'Unbroken & Crisp',
          desc: 'Uniform light tan hue, matte surface texture, firm temper. Scented with raw tree-bark vegetable tannins.',
          tint: 'bg-[#D2A078] border-[#B6845E]',
          shadowColor: 'rgba(210, 160, 120, 0.4)',
          leatherGloss: 'opacity-40',
          depth: 'Low contrast grain',
        },
        {
          title: '6 Months: Daily Carry Broken-in',
          badge: 'Softening Temper',
          desc: 'Sunlight and hand oils start oxidizing the hide. Edges darken and flex creases begin to form unique character lines.',
          tint: 'bg-[#B47444] border-[#925528]',
          shadowColor: 'rgba(180, 116, 68, 0.4)',
          leatherGloss: 'opacity-60',
          depth: 'Deepening honey amber',
        },
        {
          title: '2 Years: Vintage Patina Bloom',
          badge: 'Silky Gloss Developed',
          desc: 'Rich amber-brown tones emerge. The natural beeswax seal melts into an alluring satin sheen that cannot be faked.',
          tint: 'bg-[#85451E] border-[#693211]',
          shadowColor: 'rgba(133, 69, 30, 0.45)',
          leatherGloss: 'opacity-85',
          depth: 'Antique burnished luster',
        },
        {
          title: '5+ Years: Heirloom Masterpiece',
          badge: 'Generational Character',
          desc: 'Dense, lustrous deep mahogany patina with glassy burnished corners. Supple as butter and indestructible.',
          tint: 'bg-[#4A200B] border-[#311406]',
          shadowColor: 'rgba(74, 32, 11, 0.5)',
          leatherGloss: 'opacity-100',
          depth: 'Mirror-glass patina patina',
        },
      ],
    },
    de: {
      originTag: 'Unser Handwerkliches Erbe',
      title: 'Die SIALVANTGLOBAL INDUSTRIES Tradition',
      p1: 'Bei SIALVANTGLOBAL INDUSTRIES verstehen wir echtes Leder nicht als Ware, sondern als Zeichen von Beständigkeit, Würde und individuellem Stil. Jedes Stück entsteht in geduldiger Handarbeit mit höchster Präzision.',
      p2: 'Im Gegensatz zu industriellen Kunststoff-Imitaten, die nach kurzer Zeit rissig werden, gewinnt unser pflanzlich gegerbtes Vollnarbenleder mit jedem Nutzungsjahr an Charakter und samtigem Glanz.',
      p3: 'Verwurzelt in Sialkot, Pakistan — dem weltweiten Zentrum meisterhafter Feinsattlerei und exklusiver Lederfertigung.',
      btnCollection: 'Kollektion entdecken',
      btnInquire: 'Werkstattleiter kontaktieren',
      processTag: 'Handwerkliche Meisterschaft',
      processTitle: 'Die Entstehung eines Meisterstücks',
      processSubtitle: 'Ein traditioneller vierstufiger Fertigungsprozess, der über Generationen perfektioniert wurde.',
      patinaTag: 'Die Patina-Transformation',
      patinaTitle: 'Wie Vollnarbenleder im Laufe der Jahre reift',
      patinaDesc:
        'Künstliches Leder blättert nach einem Jahr ab. Echtes pflanzlich gegerbtes Leder nimmt Licht und Berührung auf und verwandelt sich in ein edles Samtleder.',
      steps: [
        {
          step: '01',
          title: 'Selektion der Rohhäute',
          desc: 'Nur die obersten 10% makelloser Rind- und Büffelhaut kommen in unsere engere Auswahl. Spaltleder wird ausnahmslos abgelehnt.',
        },
        {
          step: '02',
          title: 'Rein pflanzliche Gerbung',
          desc: '45-tägige Gerbung mit Mimosen- und Kastanienrinden. Verleiht dem Leder seinen unvergleichlichen, warmen Holzduft.',
        },
        {
          step: '03',
          title: 'Handzuschnitt & Sattlernaht',
          desc: 'Präziser Zuschnitt mit scharfen Halbmondmessern und unlösbare Doppel-Sattlernaht mit gewachstem Garn.',
        },
        {
          step: '04',
          title: 'Kantenpolitur mit Bienenwachs',
          desc: 'Kanten werden mit reinem Bio-Bienenwachs und Knochenfalzern stundenlang auf spiegelglatten Glanz poliert.',
        },
      ],
      stages: [
        {
          title: 'Tag 1: Frisch aus der Werkstatt',
          badge: 'Fest & Unberührt',
          desc: 'Gleichmäßiger heller Farbton, feine matte Textur und aromatischer Duft frischer Baumrinden.',
          tint: 'bg-[#D2A078] border-[#B6845E]',
          shadowColor: 'rgba(210, 160, 120, 0.4)',
          leatherGloss: 'opacity-40',
          depth: 'Natürliche Erstnarbe',
        },
        {
          title: '6 Monate: Geschmeidig eingetragen',
          badge: 'Zunehmende Weichheit',
          desc: 'Tageslicht und Berührung lassen die Kanten dunkler und die Falten charaktervoller werden.',
          tint: 'bg-[#B47444] border-[#925528]',
          shadowColor: 'rgba(180, 116, 68, 0.4)',
          leatherGloss: 'opacity-60',
          depth: 'Warmer Honigton',
        },
        {
          title: '2 Jahre: Goldene Patina',
          badge: 'Seidiger Glanz',
          desc: 'Edle bernsteinfarbene Schattierungen entfalten sich zu einem unverwechselbaren Vintage-Finish.',
          tint: 'bg-[#85451E] border-[#693211]',
          shadowColor: 'rgba(133, 69, 30, 0.45)',
          leatherGloss: 'opacity-85',
          depth: 'Antiker Glanz',
        },
        {
          title: '5+ Jahre: Ein echtes Erbstück',
          badge: 'Unvergänglicher Charakter',
          desc: 'Tiefes Mahagoni, butterweiche Haptik und eine unzerstörbare Struktur für Generationen.',
          tint: 'bg-[#4A200B] border-[#311406]',
          shadowColor: 'rgba(74, 32, 11, 0.5)',
          leatherGloss: 'opacity-100',
          depth: 'Spiegelglatte Patina',
        },
      ],
    },
    fr: {
      originTag: 'Notre Héritage Artisanal',
      title: 'L’Héritage SIALVANTGLOBAL INDUSTRIES',
      p1: 'Chez SIALVANTGLOBAL INDUSTRIES, nous considérons le cuir véritable non pas comme une matière première, mais comme l’emblème d’une élégance intemporelle et d’un savoir-faire vivant.',
      p2: 'Contrairement aux plastiques synthétiques qui se craquellent, notre cuir pleine fleur ne s’altère jamais. Au contact du temps et du quotidien, il développe une patine mordorée inimitable.',
      p3: 'Ancré à Sialkot, Pakistan — berceau mondial réputé pour sa haute maroquinerie, fournissant les amateurs de luxe sur 4 continents.',
      btnCollection: 'Explorer la Collection',
      btnInquire: 'Échanger avec l’Artisan',
      processTag: 'Technique d’Atelier',
      processTitle: 'La Naissance d’une Création SIALVANTGLOBAL INDUSTRIES',
      processSubtitle: 'Un processus traditionnel en quatre étapes transmis de maître en apprenti maroquinier.',
      patinaTag: 'La Métamorphose de la Patine',
      patinaTitle: 'Comment le Cuir Pleine Fleur Évolue',
      patinaDesc:
        'Le cuir synthétique se dégrade après un an. Le véritable cuir au tannage végétal capte la lumière et les huiles naturelles pour devenir un bijou d’aspect soyeux.',
      steps: [
        {
          step: '01',
          title: 'Sélection des Peaux Brutes',
          desc: 'Seules les 10% meilleures peaux de bêtes sont retenues. Rejet systématique des croûtes refendues et des peaux plastifiées.',
        },
        {
          step: '02',
          title: 'Tannage Végétal Naturel',
          desc: 'Tanné 45 jours durant avec des écorces de mimosa et de châtaignier, sans chrome ni produits toxiques.',
        },
        {
          step: '03',
          title: 'Coupe au Tranchet & Point Sellier',
          desc: 'Découpe pièce par pièce et couture sellier manuelle à deux aiguilles garantissant une résistance indéfectible.',
        },
        {
          step: '04',
          title: 'Lissage à la Cire d’Abeille',
          desc: 'Les tranches sont minutieusement polies à la cire d’abeille locale et au plioir d’os jusqu’à obtenir un fini miroir.',
        },
      ],
      stages: [
        {
          title: 'Jour 1 : Sorti de l’Atelier',
          badge: 'Ferme & Authentique',
          desc: 'Teinte fauve claire uniforme, toucher mat et parfum naturel d’écorce boisée.',
          tint: 'bg-[#D2A078] border-[#B6845E]',
          shadowColor: 'rgba(210, 160, 120, 0.4)',
          leatherGloss: 'opacity-40',
          depth: 'Grain originel',
        },
        {
          title: '6 Mois : Port Quotidien Assoupli',
          badge: 'Toucher Soyeux',
          desc: 'La lumière et le contact assouplissent le cuir, les arêtes s’assombrissent délicatement.',
          tint: 'bg-[#B47444] border-[#925528]',
          shadowColor: 'rgba(180, 116, 68, 0.4)',
          leatherGloss: 'opacity-60',
          depth: 'Ambre miellé',
        },
        {
          title: '2 Ans : Épanouissement de la Patine',
          badge: 'Éclat Satiné',
          desc: 'Les nuances cognac et caramel révèlent un lustre chaleureux impossible à reproduire artificiellement.',
          tint: 'bg-[#85451E] border-[#693211]',
          shadowColor: 'rgba(133, 69, 30, 0.45)',
          leatherGloss: 'opacity-85',
          depth: 'Lustre d’époque',
        },
        {
          title: '5+ Ans : Pièce d’Héritage',
          badge: 'Caractère Perpétuel',
          desc: 'Teinte acajou profonde, souplesse veloutée et résistance inaltérable prête pour la génération suivante.',
          tint: 'bg-[#4A200B] border-[#311406]',
          shadowColor: 'rgba(74, 32, 11, 0.5)',
          leatherGloss: 'opacity-100',
          depth: 'Patine lustrée miroir',
        },
      ],
    },
    es: {
      originTag: 'Nuestra Tradición Artesanal',
      title: 'El Legado SIALVANTGLOBAL INDUSTRIES',
      p1: 'En SIALVANTGLOBAL INDUSTRIES, creemos que el cuero auténtico no es simplemente un material, sino una insignia de dignidad, distinción y legado que perdura en el tiempo.',
      p2: 'A diferencia de los materiales plásticos que se cuartean en pocos meses, nuestro cuero flor genuino nunca se desintegra; absorbe el uso para transformarse en una pátina dorada excepcional.',
      p3: 'Con raíces en Sialkot, Pakistán — la capital histórica de la marroquinería y guarnicionería de exportación a más de 60 países.',
      btnCollection: 'Explorar Colección',
      btnInquire: 'Contactar al Maestro Artesano',
      processTag: 'Técnica de Atelier',
      processTitle: 'Cómo se Crea Cada Pieza SIALVANTGLOBAL INDUSTRIES',
      processSubtitle: 'Un método tradicional en cuatro fases perfeccionado a lo largo de décadas de maestría.',
      patinaTag: 'La Evolución de la Pátina',
      patinaTitle: 'Compruebe Cómo Madura el Cuero Flor',
      patinaDesc:
        'El cuero sintético se pela tras un año de uso; el auténtico cuero de curtición vegetal absorbe la luz natural y el tacto para volverse cada día más sedoso y brillante.',
      steps: [
        {
          step: '01',
          title: 'Selección de Pieles Crudas',
          desc: 'Únicamente el 10% superior de pieles vacunas de máxima densidad. Rechazamos capas aglomeradas o sintéticas.',
        },
        {
          step: '02',
          title: 'Curtición Vegetal Orgánica',
          desc: 'Proceso de 45 días con corteza de mimosa y castaño que confiere al cuero su aroma terroso y su resistencia inigualable.',
        },
        {
          step: '03',
          title: 'Corte a Cuchilla & Costura Guarnicionera',
          desc: 'Corte individual panel por panel y costura tradicional a dos agujas que bloquea cada puntada de forma independiente.',
        },
        {
          step: '04',
          title: 'Bruñido de Bordes con Cera de Abeja',
          desc: 'Los cantos se biselan y pulen con cera natural y bruñidores de hueso hasta lograr un pulido liso como el cristal.',
        },
      ],
      stages: [
        {
          title: 'Día 1: Recién Salido del Banco',
          badge: 'Firme y Robusto',
          desc: 'Tono canela uniforme, textura mate natural y fragancia a corteza de árbol.',
          tint: 'bg-[#D2A078] border-[#B6845E]',
          shadowColor: 'rgba(210, 160, 120, 0.4)',
          leatherGloss: 'opacity-40',
          depth: 'Grano natural intacto',
        },
        {
          title: '6 Meses: Moldeado al Uso Diario',
          badge: 'Flexibilidad Creciente',
          desc: 'La luz solar y el contacto manual oscurecen los bordes, creando finas líneas de personalidad.',
          tint: 'bg-[#B47444] border-[#925528]',
          shadowColor: 'rgba(180, 116, 68, 0.4)',
          leatherGloss: 'opacity-60',
          depth: 'Ámbar miel profundo',
        },
        {
          title: '2 Años: Esplendor de la Pátina',
          badge: 'Brillo Sedoso',
          desc: 'Los aceites naturales y la cera afloran creando un brillo satinado imposible de replicar en fábrica.',
          tint: 'bg-[#85451E] border-[#693211]',
          shadowColor: 'rgba(133, 69, 30, 0.45)',
          leatherGloss: 'opacity-85',
          depth: 'Lustre de anticuario',
        },
        {
          title: '5+ Años: Pieza de Herencia Familiar',
          badge: 'Carácter Inmortal',
          desc: 'Color caoba profundo, tacto ultrasuave e indestructible para acompañar a las próximas generaciones.',
          tint: 'bg-[#4A200B] border-[#311406]',
          shadowColor: 'rgba(74, 32, 11, 0.5)',
          leatherGloss: 'opacity-100',
          depth: 'Pátina efecto espejo',
        },
      ],
    },
    ar: {
      originTag: 'تراثنا الحرفي الأصيل',
      title: 'تراث سيلفانت جلوبال الفاخر',
      p1: 'في سيلفانت جلوبال، نؤمن بأن الجلد الطبيعي ليس مجرد منتج، بل هو رمز للهيبة والأصالة والميراث العائلي. يتم تشكيل كل قطعة يدويًا بصبر وإتقان فائقين.',
      p2: 'على عكس الجلود الصناعية الرخيصة التي تتشقق وتتلف سريعاً، فإن جلودنا الطبيعية الكاملة لا تبلى، بل تكتسب بريقاً دافئاً مميزاً (باتينا) مع كل عام من الاستخدام.',
      p3: 'متجذرون في سيالكوت، باكستان — العاصمة العالمية لدباغة وصناعة الجلود اليدوية الراقية لأكثر من أربعة عقود.',
      btnCollection: 'استكشف المجموعة',
      btnInquire: 'تواصل مع كبير الحرفيين',
      processTag: 'خطوات الحرفية اليدوية',
      processTitle: 'كيف تُصنع كل قطعة في سيلفانت',
      processSubtitle: 'عملية تقليدية من أربع مراحل متوارثة عبر أجيال من كبار صناع الجلود.',
      patinaTag: 'رحلة تطور بريق الجلد (الباتينا)',
      patinaTitle: 'شاهد كيف ينضج الجلد الطبيعي مع الزمن',
      patinaDesc:
        'الجلد المقلد يتشقق خلال عام، بينما يمتص الجلد الطبيعي النقي زيوت اليد وأشعة الشمس ليتحول إلى تحفة حريرية لامعة.',
      steps: [
        {
          step: '01',
          title: 'فحص واختيار الجلود الخام',
          desc: 'يتم اختيار أفضل 10% فقط من جلود الأبقار الممتازة، واستبعاد أي جلود معالجة كيميائياً أو طبقية صناعية.',
        },
        {
          step: '02',
          title: 'دباغة نباتية عضوية',
          desc: 'دباغة نقية باستخدام لحاء الميموزا والكستناء لمدة 45 يوماً تمنح الجلد رائحة عطرية طبيعية ومتانة أسطورية.',
        },
        {
          step: '03',
          title: 'قص يدوي وخياطة بسرج الإبرتين',
          desc: 'قص يدوي دقيق بأيدي الحرفيين مع خياطة يدوية مزدوجة متينة تقفل كل غرزة على حدة دون إمكانية الفك.',
        },
        {
          step: '04',
          title: 'صقل الحواف بشمع العسل الطبيعي',
          desc: 'صقل حواف الجلد بعظام ملساء وشمع عسل طبيعي نقي لساعات حتى تصبح ملساء ولامعة كالزجاج.',
        },
      ],
      stages: [
        {
          title: 'اليوم الأول: خروج حديث من الورشة',
          badge: 'متماسك وأصيل',
          desc: 'لون بني فاتح متناسق مع ملمس طبيعي مخملي ورائحة لحاء الأشجار العطرية.',
          tint: 'bg-[#D2A078] border-[#B6845E]',
          shadowColor: 'rgba(210, 160, 120, 0.4)',
          leatherGloss: 'opacity-40',
          depth: 'مسام طبيعية أولية',
        },
        {
          title: '6 أشهر: مع الاستخدام اليومي',
          badge: 'مرونة ونعومة',
          desc: 'تتفاعل أشعة الشمس وزيوت اليد لتبدأ الحواف في اكتساب لون عنبري دافئ وفريد.',
          tint: 'bg-[#B47444] border-[#925528]',
          shadowColor: 'rgba(180, 116, 68, 0.4)',
          leatherGloss: 'opacity-60',
          depth: 'لون عسلي عميق',
        },
        {
          title: 'سنتان: ازدهار بريق الباتينا',
          badge: 'لمعان حريري دائم',
          desc: 'يمتزج الشمع الطبيعي مع الجلد ليمنحه بريقاً عتيقاً لا يمكن تقليده صناعياً.',
          tint: 'bg-[#85451E] border-[#693211]',
          shadowColor: 'rgba(133, 69, 30, 0.45)',
          leatherGloss: 'opacity-85',
          depth: 'بريق أثري فاخر',
        },
        {
          title: '5+ سنوات: تحفة تتوارثها الأجيال',
          badge: 'ميراث عائلي',
          desc: 'لون ماهوجني عميق وملمس ناعم كالزبدة مع متانة لا تتأثر بمرور العقود.',
          tint: 'bg-[#4A200B] border-[#311406]',
          shadowColor: 'rgba(74, 32, 11, 0.5)',
          leatherGloss: 'opacity-100',
          depth: 'بريق زجاجي أسطوري',
        },
      ],
    },
  };
  const content = heritageMap[currentLanguage] || heritageMap.en;

  const currentPatina = content.stages[patinaStage] || content.stages[0];

  return (
    <section className="bg-[#F1ECE3] py-20 sm:py-24 border-t border-[#E5DCCF]" id="story">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Story Section Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-20">
          {/* Workshop Image with Brass Frame */}
          <div className="relative group">
            <div className="relative rounded-lg overflow-hidden shadow-2xl border-4 border-white">
              <img
                src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&w=1200&q=80"
                alt="Leather Workshop Craftsman in Sialkot"
                className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <div className="absolute bottom-5 left-5 right-5 text-white">
                <span className="text-[10px] tracking-widest uppercase bg-[#D4AF37] text-[#1F1511] font-bold px-2.5 py-1 rounded-xs inline-block mb-1.5">
                  Sialkot Atelier
                </span>
                <p className="font-cinzel text-base font-bold drop-shadow-sm">
                  Over 3 Decades of Leather Heritage
                </p>
              </div>
            </div>

            {/* Decorative Gold Accent Badge */}
            <div className="absolute -bottom-6 -right-4 sm:-right-6 bg-[#1F1511] text-[#D4AF37] p-4 sm:p-5 rounded-lg shadow-xl border border-[#D4AF37]/40 hidden sm:flex items-center gap-3">
              <div className="w-10 h-10 rounded-full border border-[#D4AF37] flex items-center justify-center font-cinzel font-bold text-lg">
                100
              </div>
              <div className="text-left">
                <p className="text-xs font-bold uppercase tracking-wider text-white">Hand Stitched</p>
                <p className="text-[11px] text-[#A69788]">Pure Saddlery Technique</p>
              </div>
            </div>
          </div>

          {/* Story Content */}
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#8E5431] uppercase tracking-[0.2em]">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span>{content.originTag}</span>
            </div>

            <h2 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1F1511] leading-[1.2]">
              {content.title}
            </h2>

            <div className="text-sm sm:text-base text-[#444444] leading-relaxed space-y-4">
              <p>{content.p1}</p>
              <p>{content.p2}</p>
              <p className="text-xs text-[#6B6865] italic border-l-2 border-[#8E5431] pl-3 py-1">
                {content.p3}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <a
                href="#products"
                className="inline-flex items-center gap-2 bg-[#D4AF37] hover:bg-white text-[#1F1511] px-6 py-3 rounded-xs font-bold text-xs uppercase tracking-wider shadow-md transition"
              >
                {content.btnCollection}
              </a>
              <a
                href="#contact"
                className="inline-flex items-center gap-2 border border-[#1F1511] hover:bg-[#1F1511] hover:text-white text-[#1F1511] px-6 py-3 rounded-xs font-semibold text-xs uppercase tracking-wider transition"
              >
                {content.btnInquire}
              </a>
            </div>
          </div>
        </div>

        {/* 4-Step Craft Process Cards */}
        <div className="mt-16 pt-12 border-t border-[#E5DCCF]">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs uppercase tracking-widest font-bold text-[#8E5431]">
              {content.processTag}
            </span>
            <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#1F1511] mt-1">
              {content.processTitle}
            </h3>
            <p className="text-xs text-[#6B6865] mt-2">
              {content.processSubtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {content.steps?.map((step: any) => (
              <div
                key={step.step}
                className="bg-white rounded-lg p-6 border border-[#ECE3D7] shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group"
              >
                <div className="text-3xl font-cinzel font-bold text-[#D4AF37]/50 group-hover:text-[#D4AF37] transition-colors mb-2">
                  {step.step}
                </div>
                <h4 className="font-cinzel text-base font-bold text-[#1F1511] mb-2">
                  {step.title}
                </h4>
                <p className="text-xs text-[#555] leading-relaxed">
                  {step.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Interactive Patina Evolution Simulator */}
        {currentPatina && (
          <div className="mt-16 bg-white rounded-lg p-6 sm:p-10 border border-[#ECE3D7] shadow-lg">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-5 space-y-4">
                <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-[#8E5431]">
                  <Clock className="w-4 h-4 text-[#D4AF37]" />
                  <span>{content.patinaTag}</span>
                </div>
                <h3 className="font-cinzel text-2xl font-bold text-[#1F1511]">
                  {content.patinaTitle}
                </h3>
                <p className="text-xs text-[#555555] leading-relaxed">
                  {content.patinaDesc}
                </p>

                {/* Slider Controls */}
                <div className="pt-2 space-y-2">
                  <div className="flex justify-between text-xs font-semibold text-[#1F1511]">
                    <span>Day 1</span>
                    <span>6 Months</span>
                    <span>2 Years</span>
                    <span>5+ Years</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="3"
                    step="1"
                    value={patinaStage}
                    onChange={(e) => setPatinaStage(Number(e.target.value))}
                    className="w-full accent-[#8E5431] cursor-pointer h-2 bg-[#F1ECE3] rounded-lg"
                    aria-label="Patina timeline slider"
                  />
                  <div className="flex justify-between text-[11px] text-[#6B6865]">
                    <span>Raw Hide</span>
                    <span>Softened</span>
                    <span>Rich Amber</span>
                    <span>Heirloom Luster</span>
                  </div>
                </div>
              </div>

              {/* Interactive Preview Swatch Card */}
              <div className="lg:col-span-7 bg-[#F9F6F0] p-6 sm:p-8 rounded-lg border border-[#ECE3D7]">
                <div className="flex items-center justify-between pb-3 border-b border-[#ECE3D7] mb-5">
                  <div>
                    <span className="text-xs font-bold text-[#8E5431] uppercase tracking-wider">
                      {currentPatina.badge}
                    </span>
                    <h4 className="font-cinzel text-lg font-bold text-[#1F1511]">
                      {currentPatina.title}
                    </h4>
                  </div>
                  <span className="text-xs font-mono bg-white px-2.5 py-1 rounded-full border border-[#ECE3D7] text-[#1F1511]">
                    Stage {patinaStage + 1} of 4
                  </span>
                </div>

                {/* Visualized Leather Swatch Simulation */}
                <div className="relative aspect-16/7 w-full rounded-md overflow-hidden shadow-inner flex items-center justify-center p-6 border-2 transition-all duration-500 text-white font-serif text-center">
                  <div
                    className={`absolute inset-0 transition-all duration-500 ${currentPatina.tint}`}
                    style={{
                      boxShadow: `inset 0 0 50px ${currentPatina.shadowColor}`,
                    }}
                  />
                  <div className="absolute inset-0 opacity-20 mix-blend-overlay bg-[radial-gradient(#000_1px,transparent_1px)] bg-[size:16px_16px]" />
                  <div className={`absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-white/20 transition-opacity duration-500 ${currentPatina.leatherGloss}`} />

                  <div className="relative z-10 p-4 bg-black/40 backdrop-blur-xs rounded-md border border-white/20 max-w-md">
                    <p className="font-cinzel font-bold text-sm tracking-widest text-[#FAF4EB]">
                      SIALVANTGLOBAL INDUSTRIES FULL-GRAIN HARNESS
                    </p>
                    <p className="text-xs font-sans text-white/90 mt-1">
                      {currentPatina.depth} &bull; Hand-Burnished Beeswax
                    </p>
                  </div>
                </div>

                <p className="text-xs text-[#555] mt-4 leading-relaxed italic bg-white p-3 rounded-xs border border-[#ECE3D7]">
                  &ldquo;{currentPatina.desc}&rdquo;
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
