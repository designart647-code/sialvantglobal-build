import React, { useState } from 'react';
import { ChevronDown, HelpCircle, MessageCircle } from 'lucide-react';
import { LanguageCode } from '../types';
import { getStoredWhatsAppNumber } from '../utils/whatsapp';

interface FAQItem {
  question: string;
  answer: string;
}

interface Props {
  currentLanguage?: LanguageCode;
}

const FAQS_BY_LANG: Record<string, { tag: string; title: string; subtitle: string; items: FAQItem[]; bannerTitle: string; bannerSub: string; bannerBtn: string }> = {
  en: {
    tag: 'Common Queries',
    title: 'Frequently Asked Questions',
    subtitle: 'Everything you need to know about our leather grades, bespoke tailoring, international delivery, and WhatsApp ordering.',
    bannerTitle: 'Have a specific question not covered here?',
    bannerSub: 'Speak directly with our senior artisan or support team on WhatsApp.',
    bannerBtn: 'Ask On WhatsApp',
    items: [
      {
        question: 'Is your leather 100% pure full-grain, or do you use bonded/split scraps?',
        answer:
          'We use exclusively 100% pure full-grain cowhide and buffalo leather. We strictly never use "genuine leather" splits (which are reconstituted leather powder bonded with polyurethane plastic) or artificial rexine. Our hides retain their complete natural grain, dense fibrous strength, and organic breathability.',
      },
      {
        question: 'How does WhatsApp ordering and checkout work?',
        answer:
          'You can order either directly from any product card by clicking "Order on WhatsApp", or by adding multiple items to your Order Bag and clicking "Place Order via WhatsApp". A structured invoice with your selected items, leather shade, custom initials, and delivery address is instantly prepared and opens in WhatsApp addressed to our master artisan team.',
      },
      {
        question: 'Can I customize sizing for jackets or get custom monogram initials stamped?',
        answer:
          'Yes, absolutely! We offer complimentary gold-foil or blind heat debossing (up to 4 letters) on wallets, bags, and belts. For leather jackets, our master tailors can customize sleeve length, chest circumference, and torso fit to your exact body measurements without additional tailoring charges.',
      },
      {
        question: 'What are your international delivery timelines and shipping carriers?',
        answer:
          'We ship globally via premium express couriers including DHL Express, FedEx, and SkyNet. Typical worldwide delivery takes 3 to 6 business days with real-time end-to-end tracking provided immediately upon dispatch. Orders over $150 USD (or equivalent) qualify for complimentary international express delivery.',
      },
      {
        question: 'What is leather "patina" and how do I care for my product?',
        answer:
          'Patina is the natural, rich golden-amber sheen that develops on pure vegetable-tanned leather over months and years of use as it absorbs sunlight, ambient atmosphere, and natural hand oils. Unlike synthetic faux leather that cracks and peels, full-grain leather grows more beautiful with time. We recommend conditioning with a natural beeswax balm or neatsfoot oil once every 6 months.',
      },
      {
        question: 'Do you accept corporate branding or international wholesale export orders?',
        answer:
          'Yes! Since we own our dedicated production unit in Sialkot, we manufacture bulk corporate executive gift sets (wallets, keychains, compendiums with corporate embossing) and export full consignments globally via SkyNet and DHL air cargo. Click "Bespoke Orders" or message us on WhatsApp for formal quotation sheets.',
      },
    ],
  },
  ar: {
    tag: 'الأسئلة الشائعة',
    title: 'الأسئلة الأكثر تداولاً',
    subtitle: 'كل ما تحتاج لمعرفته حول درجات الجلود الفاخرة، التفصيل المخصص، الشحن الدولي، والطلب عبر واتساب.',
    bannerTitle: 'هل لديك استفسار محدد غير مذكور هنا؟',
    bannerSub: 'تحدث مباشرة مع كبار الحرفيين لدينا عبر واتساب للحصول على استشارة فورية.',
    bannerBtn: 'تواصل عبر واتساب',
    items: [
      {
        question: 'هل الجلود المستخدمة طبيعية وخالصة 100% أم مجرد بقايا مضغوطة؟',
        answer:
          'نحن نستخدم حصرياً جلود البقر والجاموس الطبيعية الكاملة (Full-Grain) بنسبة 100%. نرفض تماماً استخدام الجلود المعاد تدويرها أو البلاستيكية أو الركسين الصناعي. تحتفظ جلودنا بنسيجها الطبيعي الكامل وقوتها ومظهرها الأصيل.',
      },
      {
        question: 'كيف تتم عملية الطلب وإتمام الشراء عبر واتساب؟',
        answer:
          'يمكنك الطلب مباشرة من بطاقة أي منتج بالضغط على "اطلب عبر واتساب"، أو إضافة المنتجات إلى حقيبة التسوق وإرسال الطلب المجمع. يتم إعداد فاتورة منظمة تحوي المنتجات ولون الجلد والمقاس والحروف المحفورة وعنوان التوصيل لتفتح مباشرة في محادثة الحرفيين.',
      },
      {
        question: 'هل يمكنني تفصيل المقاسات للسترات أو حفر الحروف والأسماء بالذهب؟',
        answer:
          'نعم بالتأكيد! نقدم خدمة نقش الحروف والأسماء مجاناً بالذهب أو الحفر الحراري على المحافظ والحقائب والأحزمة. أما بالنسبة للسترات الجلدية، فيمكن لخياطينا تعديل طول الأكمام ومحيط الصدر وفقاً لمقاساتك الدقيقة دون أي رسوم إضافية.',
      },
      {
        question: 'ما هي مواعيد الشحن الدولي وشركات التوصيل المعتمدة؟',
        answer:
          'نشحن إلى جميع دول العالم عبر شركات البريد السريع العالمية دي إتش إل إكسبريس (DHL Express) وسكاي نت مع توفير رقم تتبع فوري. يستغرق التوصيل عادة بين 3 إلى 6 أيام عمل، والشحن مجاني للطلبات التي تتجاوز 150 دولاراً أمريكياً.',
      },
      {
        question: 'ما هو تعتيق الجلد (Patina) وكيف أعتني بمنتجي؟',
        answer:
          'الباتينا هو اللمعان الذهبي الداكن الفريد الذي يكتسبه الجلد المدبوغ نباتياً بمرور الوقت بفضل الاستخدام وأشعة الشمس وزيوت اليدين الطبيعية. كلما زاد استخدامه أصبح أكثر فخامة وجمالاً. ننصح بترطيب الجلد ببلسم شمع العسل الطبيعي كل 6 أشهر.',
      },
      {
        question: 'هل توفرون تصنيع الهدايا المؤسسية والطلبات بالجملة والتصدير التجاري؟',
        answer:
          'نعم! نمتلك ورشة تصنيع متكاملة في سيالكوت، وننتج مجموعات الهدايا التنفيذية بشعارات الشركات المصممة خصيصاً، ونصدر شحنات تجارية لكافة أنحاء العالم. يرجى التواصل معنا عبر واتساب للحصول على عروض الأسعار الرسمية.',
      },
    ],
  },
  de: {
    tag: 'Häufige Fragen',
    title: 'Häufig Gestellte Fragen',
    subtitle: 'Alles, was Sie über unsere Lederqualitäten, Maßanfertigungen, weltweiten Expressversand und die WhatsApp-Bestellung wissen müssen.',
    bannerTitle: 'Haben Sie eine Frage, die hier nicht beantwortet wird?',
    bannerSub: 'Sprechen Sie direkt mit unserem Meisterhandwerker oder Support-Team auf WhatsApp.',
    bannerBtn: 'Auf WhatsApp Fragen',
    items: [
      {
        question: 'Verwenden Sie echtes Vollnarbenleder oder gebundenes Spaltleder?',
        answer:
          'Wir verwenden ausschließlich 100 % reines Vollnarbenleder (Full-Grain) vom Rind und Wasserbüffel. Wir verwenden niemals Kunstleder, PU oder Spaltlederreste. Unsere Häute behalten ihre vollständige natürliche Narbung, dichte Faserstruktur und natürliche Atmungsaktivität.',
      },
      {
        question: 'Wie funktioniert die Bestellung und Abwicklung über WhatsApp?',
        answer:
          'Sie können direkt auf jeder Produktkarte auf "Auf WhatsApp Bestellen" klicken oder mehrere Artikel in Ihre Bestelltasche legen. Eine strukturierte Rechnung mit Ihren ausgewählten Artikeln, Farbvarianten, Monogramm-Wünschen und der Lieferadresse wird sofort zusammengestellt und öffnet sich in WhatsApp direkt mit unserem Meisterteam.',
      },
      {
        question: 'Bieten Sie individuelle Größen für Jacken oder Monogramm-Prägungen an?',
        answer:
          'Ja, absolut! Wir bieten kostenlose Goldfolien- oder Heißblindprägungen (bis zu 4 Buchstaben) auf Geldbörsen, Taschen und Gürteln an. Für Lederjacken passen unsere Schneidermeister Ärmellänge, Brustumfang und Passform exakt an Ihre Maße an – ohne Aufpreis.',
      },
      {
        question: 'Wie sind die internationalen Lieferzeiten und Versandkonditionen?',
        answer:
          'Wir versenden weltweit per DHL Express und SkyNet mit lückenloser Sendungsverfolgung. Die weltweite Zustellung dauert üblicherweise 3 bis 6 Werktage. Ab einem Bestellwert von 150 USD ist der Expressversand komplett kostenfrei.',
      },
      {
        question: 'Was ist Leder-Patina und wie pflege ich mein Produkt richtig?',
        answer:
          'Patina ist der edle, charakteristische bernsteinfarbene Glanz, den pflanzlich gegerbtes Leder im Laufe der Jahre durch Gebrauch, Licht und natürliche Handöle entwickelt. Echtes Vollnarbenleder wird mit jedem Jahr schöner. Wir empfehlen die Pflege mit natürlichem Bienenwachsbalsam alle 6 Monate.',
      },
      {
        question: 'Akzeptieren Sie Firmenbestellungen und internationalen Großhandelsexport?',
        answer:
          'Ja! Da wir über eine eigene Manufaktur in Sialkot verfügen, fertigen wir exklusive Firmengeschenke mit Firmenlogo-Prägung sowie Großhandelssendungen für den weltweiten Export. Kontaktieren Sie uns gerne für ein individuelles Angebot.',
      },
    ],
  },
  fr: {
    tag: 'Questions Fréquentes',
    title: 'Foire Aux Questions',
    subtitle: 'Tout ce que vous devez savoir sur nos cuirs de première qualité, nos confections sur mesure, notre livraison internationale et nos commandes WhatsApp.',
    bannerTitle: 'Vous avez une question spécifique qui ne figure pas ici ?',
    bannerSub: 'Échangez directement avec nos maîtres artisans ou notre équipe d’assistance via WhatsApp.',
    bannerBtn: 'Demander sur WhatsApp',
    items: [
      {
        question: 'Votre cuir est-il 100 % pleine fleur ou utilisez-vous des croûtes reconstituées ?',
        answer:
          'Nous utilisons exclusivement du cuir 100 % pleine fleur (Full-Grain) de vachette et de buffle. Nous n’utilisons jamais de croûte de cuir enduite de plastique ni de simili polyuréthane. Nos peaux conservent leur grain naturel d’origine, leur résistance fibreuse et leur respirabilité organique.',
      },
      {
        question: 'Comment fonctionnent la commande et le paiement via WhatsApp ?',
        answer:
          'Vous pouvez commander directement depuis une fiche produit en cliquant sur "Commander sur WhatsApp", ou ajouter plusieurs créations dans votre panier et valider l’ensemble. Une facture détaillée avec le choix de cuir, les initiales souhaitées et votre adresse s’ouvre directement dans une conversation WhatsApp avec nos artisans.',
      },
      {
        question: 'Est-il possible de personnaliser les mensurations des vestes ou d’ajouter des initiales ?',
        answer:
          'Oui, tout à fait ! Nous offrons gratuitement le marquage à chaud (doré ou naturel en creux, jusqu’à 4 lettres) sur nos portefeuilles, sacs et ceintures. Pour les vestes en cuir, nos maîtres tailleurs ajustent les manches, le tour de poitrine et la coupe selon vos mesures exactes sans frais additionnels.',
      },
      {
        question: 'Quels sont les délais de livraison internationale et les transporteurs ?',
        answer:
          'Nous expédions dans le monde entier avec suivi sécurisé via DHL Express et SkyNet. La livraison internationale s’effectue généralement sous 3 à 6 jours ouvrables. La livraison express est offerte pour toute commande supérieure à 150 USD.',
      },
      {
        question: 'Qu’est-ce que la "patine" du cuir et comment entretenir son article ?',
        answer:
          'La patine est cet éclat doré et ambré unique que le cuir à tannage végétal acquiert au fil des mois et des années au contact de la lumière et des huiles naturelles des mains. Le cuir pleine fleur vieillit magnifiquement. Nous conseillons de nourrir le cuir avec un baume naturel à base de cire d’abeille tous les 6 mois.',
      },
      {
        question: 'Proposez-vous des commandes d’entreprises et de l’export de gros à l’international ?',
        answer:
          'Absolument ! Possédant notre propre atelier de production à Sialkot, nous concevons des coffrets cadeaux d’entreprise avec gaufrage de logos et expédions des volumes d’exportation par fret aérien DHL dans le monde entier.',
      },
    ],
  },
  es: {
    tag: 'Consultas Frecuentes',
    title: 'Preguntas Frecuentes',
    subtitle: 'Todo lo que necesita saber sobre nuestros grados de cuero, confección a medida, envíos internacionales y pedidos por WhatsApp.',
    bannerTitle: '¿Tiene alguna consulta específica que no figure aquí?',
    bannerSub: 'Hable directamente con nuestros maestros artesanos o equipo de atención en WhatsApp.',
    bannerBtn: 'Consultar en WhatsApp',
    items: [
      {
        question: '¿Su cuero es 100% flor entera pura o utilizan restos aglomerados?',
        answer:
          'Utilizamos exclusivamente cuero 100% flor entera (Full-Grain) de vacuno y búfalo. Jamás utilizamos cuero reconstituido, serrajes sintéticos ni imitación de poliuretano. Nuestras pieles conservan su grano natural intacto, su resistencia fibrosa y su transpirabilidad natural.',
      },
      {
        question: '¿Cómo funciona el pedido y compra mediante WhatsApp?',
        answer:
          'Puede solicitar cualquier producto directamente con el botón "Pedir por WhatsApp" o añadir múltiples piezas a su bolsa y confirmar el pedido global. Se genera al instante una factura detallada con tonos de cuero, monogramas personalizados y dirección de entrega, lista para ser atendida por nuestro equipo.',
      },
      {
        question: '¿Se pueden personalizar las tallas de chaquetas o grabar iniciales?',
        answer:
          '¡Sí, por supuesto! Ofrecemos grabado personalizado gratuito (hasta 4 letras, en pan de oro o bajo relieve térmico) en billeteras, bolsos y cinturones. Para las chaquetas de cuero, nuestros sastres confeccionan a medida mangas, pecho y torso según sus especificaciones sin costo adicional.',
      },
      {
        question: '¿Cuáles son los plazos y condiciones de entrega internacional?',
        answer:
          'Enviamos a todo el mundo con seguimiento puerta a puerta a través de DHL Express y SkyNet. El plazo habitual de entrega internacional es de 3 a 6 días laborables. Los pedidos superiores a 150 USD disfrutan de envío express internacional completamente gratuito.',
      },
      {
        question: '¿Qué es la "pátina" del cuero y cómo debo cuidarlo?',
        answer:
          'La pátina es el brillo ámbar y suave que adquiere el cuero de curtición vegetal con el paso del tiempo al contacto con la luz y los aceites naturales de las manos. El cuero de flor entera no se agrieta, sino que embellece. Recomendamos hidratarlo con cera de abejas natural cada 6 meses.',
      },
      {
        question: '¿Aceptan pedidos corporativos para empresas y exportaciones al por mayor?',
        answer:
          '¡Sí! Al contar con nuestra propia unidad de manufactura en Sialkot, elaboramos sets de regalo ejecutivos con logos empresariales y gestionamos envíos de exportación internacional en contenedor y vía aérea.',
      },
    ],
  },
};

export const FAQSection: React.FC<Props> = ({ currentLanguage = 'en' }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const waNumber = getStoredWhatsAppNumber();
  const faqData = FAQS_BY_LANG[currentLanguage] || FAQS_BY_LANG.en;

  return (
    <section className="py-20 sm:py-24 bg-[#FAF7F2] border-t border-[#ECE3D7]" id="faq">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 text-xs font-bold text-[#8E5431] uppercase tracking-[0.25em] mb-2">
            <HelpCircle className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{faqData.tag}</span>
          </div>

          <h2 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold text-[#120B08] tracking-tight">
            {faqData.title}
          </h2>

          <div className="w-16 h-0.5 bg-[#D4AF37] mx-auto mt-3" />
          <p className="text-xs sm:text-sm text-[#6B6865] mt-3">
            {faqData.subtitle}
          </p>
        </div>

        {/* Accordion */}
        <div className="space-y-3.5">
          {faqData.items.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="bg-white rounded-lg border border-[#ECE3D7] shadow-xs overflow-hidden transition-all duration-200"
              >
                <button
                  type="button"
                  onClick={() => setOpenIndex(isOpen ? null : index)}
                  className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-[#F9F6F0] transition"
                  aria-expanded={isOpen}
                >
                  <h3 className="font-cinzel text-sm sm:text-base font-bold text-[#120B08] leading-snug">
                    {faq.question}
                  </h3>

                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 border transition-transform duration-300 ${
                      isOpen
                        ? 'border-[#8E5431] bg-[#8E5431] text-white rotate-180'
                        : 'border-[#ECE3D7] bg-[#F9F6F0] text-gray-500'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-[#555] leading-relaxed border-t border-[#ECE3D7]/60 bg-[#FFFDF9] animate-in fade-in duration-200">
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still have questions banner */}
        <div className="mt-12 p-6 rounded-lg bg-white border border-[#D4AF37]/40 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-0.5">
            <h4 className="font-cinzel text-base font-bold text-[#120B08]">
              {faqData.bannerTitle}
            </h4>
            <p className="text-xs text-[#6B6865]">
              {faqData.bannerSub}
            </p>
          </div>

          <a
            href={`https://wa.me/${waNumber}?text=${encodeURIComponent(
              'Hello SIALVANTGLOBAL INDUSTRIES, I am interested in your leather products. Please share more details.'
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1eb857] text-white px-5 py-2.5 rounded-xs font-bold text-xs uppercase tracking-wider shadow-xs transition shrink-0"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>{faqData.bannerBtn}</span>
          </a>
        </div>
      </div>
    </section>
  );
};
