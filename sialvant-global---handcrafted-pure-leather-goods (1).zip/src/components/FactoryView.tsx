import React, { useState } from 'react';
import {
  Factory,
  Scissors,
  Truck,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Maximize2,
  X,
  Sparkles,
  Plane,
  Clock,
  Compass,
} from 'lucide-react';
import { LanguageCode } from '../types';

interface FactoryStation {
  id: string;
  stepNumber: string;
  stationName: string;
  badge: string;
  image: string;
  shortDesc: string;
  detailedDesc: string;
  toolsUsed: string[];
  output: string;
}

interface Props {
  currentLanguage?: LanguageCode;
  onOpenBespoke: () => void;
}

export const FactoryView: React.FC<Props> = ({ currentLanguage = 'en', onOpenBespoke }) => {
  const stationsMap: Record<string, FactoryStation[]> = {
    en: [
      {
        id: 'pattern-cutting',
        stepNumber: '01',
        stationName: 'Pattern Drafting & Precision Cutting',
        badge: 'Station 1 • Cutting Hall',
        image: '/src/assets/images/leather_pattern_cut_1793899264018.jpg',
        shortDesc:
          'Senior pattern masters cutting thick full-grain cowhide panel by panel on solid oak worktables.',
        detailedDesc:
          'Each raw hide is inspected under raking light to map the strongest grain lines and natural fiber density. Using hand-forged cobbler knives, brass dividers, and calibrated acrylic templates, every panel for our jackets, bags, and wallets is sliced by hand with surgical precision.',
        toolsUsed: ['Japanese Brass Cobbler Knives', 'Steel Calibrated Rulers', 'Acrylic Master Templates', 'Divider Calipers'],
        output: 'Precision-cut panels for Jackets, Messenger Bags, and Wallets',
      },
      {
        id: 'machine-stitching',
        stepNumber: '02',
        stationName: 'Heavy Industrial Machine Stitching',
        badge: 'Station 2 • Assembly & Stitching Bay',
        image: '/src/assets/images/leather_machine_stitch_1793899243698.jpg',
        shortDesc:
          'Master craftsman operating a heavy-duty industrial leather sewing machine with heavy waxed golden thread.',
        detailedDesc:
          'Our atelier utilizes heavy cylinder-bed German Adler and classic Singer industrial leather machines. Operating with heavy-gauge bonded nylon and waxed thread, every seam is lock-stitched to effortlessly bond multi-layer 4mm bridle leather with unbreakable seam strength.',
        toolsUsed: ['German Adler Cylinder-Bed Leather Sewing Machine', 'Bonded Waxed Heavy Gauge Thread', 'Solid Brass Rivets', 'Cobbler Bone Folders'],
        output: 'Reinforced load-bearing seams with 50+ year tensile endurance',
      },
      {
        id: 'export-dispatch',
        stepNumber: '03',
        stationName: 'DHL & SkyNet Export Courier Dispatch',
        badge: 'Station 3 • Loading Dock & Global Shipping',
        image: '/src/assets/images/leather_dhl_dispatch_1793899243517.jpg',
        shortDesc:
          'Insured cartons and parcels handed directly to DHL Express and SkyNet international delivery vans outside our Sialkot factory.',
        detailedDesc:
          'Every finished creation is placed inside an unbleached cotton dust bag and cushioned inside export-grade cartons. Daily pickups by DHL Express and SkyNet Worldwide delivery vans at our facility in Badiana, Pasrur, Sialkot dispatch our parcels directly to international air cargo hubs for fast 3 to 5-day delivery to the USA, UK, UAE, Europe, and over 60 countries worldwide.',
        toolsUsed: ['Barcoded Airway Bill Thermal Printers', 'Cushioned Corrugated Export Cartons', 'Tamper-Proof Security Seals', 'Branded Cotton Dust Bags'],
        output: 'Daily international air-express consignments with live tracking',
      },
    ],
    de: [
      {
        id: 'pattern-cutting',
        stepNumber: '01',
        stationName: 'Schnittmuster & Präzisionszuschnitt',
        badge: 'Station 1 • Zuschnittsaal',
        image: '/src/assets/images/leather_pattern_cut_1793899264018.jpg',
        shortDesc:
          'Zuschnittmeister schneiden Vollnarbenleder Paneel für Paneel auf massiven Eichenholztischen.',
        detailedDesc:
          'Jede Rohhaut wird unter Schräglicht geprüft, um die dichtesten Faserlinien zu identifizieren. Mit japanischen Schustermessern, Messingteilern und Schablonen werden alle Zuschnitte für Jacken, Taschen und Geldbörsen millimetergenau geschnitten.',
        toolsUsed: ['Japanische Schustermesser', 'Kalibrierte Stahllineale', 'Acryl-Musterschablonen', 'Präzisionszirkel'],
        output: 'Präzise geschnittene Lederpaneele für Jacken, Kuriertaschen und Geldbörsen',
      },
      {
        id: 'machine-stitching',
        stepNumber: '02',
        stationName: 'Industrielle Schwermaschinen-Naht',
        badge: 'Station 2 • Montage & Steppbereich',
        image: '/src/assets/images/leather_machine_stitch_1793899243698.jpg',
        shortDesc:
          'Erfahrener Feinsattler an einer schweren Zylinderarm-Ledersteppmaschine mit gewachstem Goldgarn.',
        detailedDesc:
          'Unsere Manufaktur setzt auf deutsche Adler-Zylinderarm-Ledersteppmaschinen. Mit hochfestem, gewachstem Spezialgarn wird jede Naht verriegelt, um 4 mm starkes Rindleder unzerreißbar zu verbinden.',
        toolsUsed: ['Deutsche Adler-Zylinderarmmaschine', 'Gewachstes Schwerstgarn', 'Massive Messingnieten', 'Knochenfalzer'],
        output: 'Hochbelastbare Nähte mit über 50 Jahren Lebensdauer',
      },
      {
        id: 'export-dispatch',
        stepNumber: '03',
        stationName: 'DHL & SkyNet Export-Versand',
        badge: 'Station 3 • Warenausgang & Luftfracht',
        image: '/src/assets/images/leather_dhl_dispatch_1793899243517.jpg',
        shortDesc:
          'Versicherte Exportkartons werden täglich direkt an die DHL Express und SkyNet Fahrzeuge übergeben.',
        detailedDesc:
          'Jedes fertige Lederstück wird in einen atmungsaktiven Baumwoll-Staubbeutel verpackt und in stabile Exportkartons gebettet. Tägliche Abholungen an unserer Manufaktur in Badiana, Pasrur, Sialkot sichern schnellen 3-5 Tage Expressversand weltweit.',
        toolsUsed: ['Thermo-Etikettendrucker für Luftfrachtbriefe', 'Gepolsterte Wellpappekartons', 'Manipulationssichere Siegel', 'Baumwoll-Staubbeutel'],
        output: 'Tägliche internationale Express-Luftfrachtsendungen mit Live-Tracking',
      },
    ],
    fr: [
      {
        id: 'pattern-cutting',
        stepNumber: '01',
        stationName: 'Patronage & Découpe de Précision',
        badge: 'Poste 1 • Salle de Découpe',
        image: '/src/assets/images/leather_pattern_cut_1793899264018.jpg',
        shortDesc:
          'Maîtres coupeurs taillant le cuir pleine fleur panneau par panneau sur de massives tables en chêne.',
        detailedDesc:
          'Chaque peau brute est inspectée sous lumière rasante afin de repérer le sens du prêtant et la densité fibreuse. À l’aide de tranchets japonais et de gabarits calibrés, chaque pièce est coupée à la main.',
        toolsUsed: ['Tranchets de cordonnier en laiton', 'Règles en acier trempé', 'Gabarits en acrylique', 'Compas à pointes sèches'],
        output: 'Panneaux coupés avec exactitude pour blousons, sacoches et maroquinerie',
      },
      {
        id: 'machine-stitching',
        stepNumber: '02',
        stationName: 'Couture Lourde sur Machine Industrielle',
        badge: 'Poste 2 • Assemblage & Piquage',
        image: '/src/assets/images/leather_machine_stitch_1793899243698.jpg',
        shortDesc:
          'Artisan maroquinier opérant sur machine canon industrielle à fil poissé doré.',
        detailedDesc:
          'Notre atelier utilise des machines industrielles allemandes Adler à bras libre. Cousues avec un fil poissé ultra-résistant, les coutures enrobent les cuirs de bride 4 mm pour une résistance garantie plusieurs décennies.',
        toolsUsed: ['Machine à coudre Adler à bras canon', 'Fil poissé haute résistance', 'Rivets en laiton plein', 'Plioirs en os naturel'],
        output: 'Assemblages blindés prévus pour résister plus de 50 ans',
      },
      {
        id: 'export-dispatch',
        stepNumber: '03',
        stationName: 'Expédition Export DHL & SkyNet',
        badge: 'Poste 3 • Quai d’Expédition Mondiale',
        image: '/src/assets/images/leather_dhl_dispatch_1793899243517.jpg',
        shortDesc:
          'Colis sécurisés remis directement aux transporteurs DHL Express et SkyNet devant notre manufacture.',
        detailedDesc:
          'Chaque création est protégée dans son pochon en coton écru et calée dans un carton d’exportation renforcé. Les enlèvements quotidiens à notre atelier de Badiana, Pasrur, Sialkot garantissent un transit aérien rapide de 3 à 5 jours ouvrés.',
        toolsUsed: ['Imprimantes thermiques de bordereaux aériens', 'Cartons d’exportation renforcés', 'Scellés de sécurité', 'Pochons en coton naturel'],
        output: 'Expéditions aériennes internationales quotidiennes avec suivi électronique',
      },
    ],
    es: [
      {
        id: 'pattern-cutting',
        stepNumber: '01',
        stationName: 'Patronaje y Corte Manual de Precisión',
        badge: 'Puesto 1 • Taller de Corte',
        image: '/src/assets/images/leather_pattern_cut_1793899264018.jpg',
        shortDesc:
          'Maestros cortadores trabajando el cuero flor panel a panel sobre mesas de roble macizo.',
        detailedDesc:
          'Cada piel sin curtir se analiza con luz rasante para evaluar la orientación del grano. Con cuchillas de zapatero y reglas milimetradas, se cortan todas las piezas con exactitud milimétrica.',
        toolsUsed: ['Cuchillas japonesas de guarnicionero', 'Reglas de acero calibradas', 'Plantillas acrílicas maestras', 'Calibres de compás'],
        output: 'Paneles cortados con precisión para chaquetas, maletines y carteras',
      },
      {
        id: 'machine-stitching',
        stepNumber: '02',
        stationName: 'Costura Pesada en Máquina Industrial',
        badge: 'Puesto 2 • Ensamblaje y Pespunte',
        image: '/src/assets/images/leather_machine_stitch_1793899243698.jpg',
        shortDesc:
          'Artesano operando una máquina industrial de brazo cilíndrico con hilo encerado dorado.',
        detailedDesc:
          'Nuestro taller dispone de máquinas alemanas Adler especiales para cuero pesado. Empleando hilo encerado de alta tenacidad, cada costura sella piezas de hasta 4 mm de espesor de por vida.',
        toolsUsed: ['Máquina de coser Adler de brazo cilíndrico', 'Hilo encerado de alta resistencia', 'Remaches de latón macizo', 'Plegaderas de hueso'],
        output: 'Costuras reforzadas diseñadas para resistir más de 50 años',
      },
      {
        id: 'export-dispatch',
        stepNumber: '03',
        stationName: 'Despacho de Exportación DHL y SkyNet',
        badge: 'Puesto 3 • Muelle de Carga y Envíos',
        image: '/src/assets/images/leather_dhl_dispatch_1793899243517.jpg',
        shortDesc:
          'Paquetes asegurados entregados directamente a furgonetas de DHL Express y SkyNet.',
        detailedDesc:
          'Cada artículo se envuelve en una bolsa guardapolvo de algodón y se protege en cajas reforzadas de exportación. Las recogidas diarias en nuestras instalaciones de Badiana, Pasrur, Sialkot garantizan entregas en 3 a 5 días a todo el mundo.',
        toolsUsed: ['Impresoras térmicas de guías aéreas', 'Cajas de exportación reforzadas', 'Precintos de seguridad inviolables', 'Bolsas guardapolvo de algodón'],
        output: 'Consignaciones aéreas internacionales diarias con seguimiento en tiempo real',
      },
    ],
    ar: [
      {
        id: 'pattern-cutting',
        stepNumber: '01',
        stationName: 'تصميم الباترون والقص اليدوي الدقيق',
        badge: 'المحطة 1 • قاعة القص',
        image: '/src/assets/images/leather_pattern_cut_1793899264018.jpg',
        shortDesc: 'كبار الحرفيين يقومون بقص الجلود الطبيعية الكاملة يدوياً على طاولات خشب السنديان.',
        detailedDesc: 'يتم فحص كل قطعة جلدية تحت الإضاءة الموجهة لاختيار أكثف مسام الجلد. باستخدام شفرات يابانية ومساطر دقيقة، يتم قص كل لوح للسترات والحقائب بدقة متناهية.',
        toolsUsed: ['شفرات نحاسية يابانية', 'مساطر فولاذية معيرة', 'قوالب أكريليك رئيسية', 'فرجار القياس'],
        output: 'ألواح مقصوصة بدقة للسترات وحقائب السفر والمحافظ',
      },
      {
        id: 'machine-stitching',
        stepNumber: '02',
        stationName: 'الخياطة الصناعية المتينة',
        badge: 'المحطة 2 • قسم التجميع والخياطة',
        image: '/src/assets/images/leather_machine_stitch_1793899243698.jpg',
        shortDesc: 'حرفي متمرس يعمل على ماكينة خياطة جلود ألمانية ثقيلة بخيوط شمعية ذهبية متينة.',
        detailedDesc: 'تستخدم ورشتنا ماكينات أدلر الألمانية المتخصصة في خياطة الجلود السميكة (4 ملم). تعمل بخيوط نايلون شمعية مدمجة تقفل كل غرزة لضمان قوة شد تدوم لعقود.',
        toolsUsed: ['ماكينة أدلر الألمانية لخياطة الجلود', 'خيوط شمعية مقواة', 'مسامير نحاسية أصيلة', 'عظام الصقل'],
        output: 'غرز وخياطة تتحمل الأوزان الثقيلة لأكثر من 50 عاماً',
      },
      {
        id: 'export-dispatch',
        stepNumber: '03',
        stationName: 'شحن الطرود الدولية عبر دي إتش إل وسكاي نت',
        badge: 'المحطة 3 • رصيف التحميل والشحن الدولي',
        image: '/src/assets/images/leather_dhl_dispatch_1793899243517.jpg',
        shortDesc: 'تسليم الطرود وصناديق التصدير مباشرة إلى سيارات دي إتش إل وسكاي نت أمام مصنعنا في سيالكوت.',
        detailedDesc: 'توضع كل قطعة داخل كيس قطني واقٍ وصندوق شحن مقوى. يتم تسليم الشحنات يومياً في رصيف التحميل الخاص بنا في باديانا، سيالكوت لسيارات دي إتش إل إكسبريس لتنطلق عبر الشحن الجوي السريع إلى أمريكا وبريطانيا والإمارات والخليج وأوروبا خلال 3 إلى 5 أيام عمل.',
        toolsUsed: ['طابعات بوالص الشحن الحرارية', 'صناديق تصدير مضلعة ومبطنة', 'أختام أمان محكمة', 'أكياس قطنية واقية'],
        output: 'شحنات جوية يومية سريعة مع رقم تتبع دولي فوري',
      },
    ],
  };

  const stations = stationsMap[currentLanguage] || stationsMap.en;
  const [activeStation, setActiveStation] = useState<FactoryStation>(stations[0]);
  const [lightboxStation, setLightboxStation] = useState<FactoryStation | null>(null);

  // Sync active station when language changes
  React.useEffect(() => {
    setActiveStation(stations[0]);
  }, [currentLanguage]);

  return (
    <section className="bg-[#140D09] text-white py-20 sm:py-24 border-t border-[#2E1D13] relative overflow-hidden" id="factory-view">
      {/* Background decorative watermark */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-[#D4AF37]/5 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 rounded-full bg-[#8E5431]/10 blur-3xl pointer-events-none" />

      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-[#D4AF37] text-xs font-semibold uppercase tracking-widest mb-4">
            <Factory className="w-3.5 h-3.5" />
            <span>Sialkot Production Unit & Worldwide Export Dock</span>
          </div>

          <h2 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#FAF4EB] leading-[1.2]">
            Inside Our Workshop & Global Dispatch
          </h2>

          <p className="text-xs sm:text-sm text-[#DFD5C8] font-light mt-3 leading-relaxed">
            Experience our transparent in-house manufacturing process — from hide grading and pattern cutting to heavy industrial sewing and daily DHL Express parcel handovers.
          </p>

          <div className="w-20 h-0.5 bg-[#D4AF37] mx-auto mt-4" />
        </div>

        {/* 3 Main Interactive View Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8 mb-14">
          {stations.map((station) => {
            const isSelected = activeStation.id === station.id;
            return (
              <div
                key={station.id}
                onClick={() => setActiveStation(station)}
                className={`group rounded-lg overflow-hidden border transition-all duration-300 bg-[#1C1410] flex flex-col justify-between cursor-pointer ${
                  isSelected
                    ? 'border-[#D4AF37] ring-1 ring-[#D4AF37] shadow-2xl scale-[1.01]'
                    : 'border-white/10 hover:border-[#8E5431]/70 shadow-md'
                }`}
              >
                {/* Image Wrapper */}
                <div className="relative aspect-16/10 w-full overflow-hidden bg-black/40">
                  <img
                    src={station.image}
                    alt={station.stationName}
                    className="w-full h-full object-cover object-center group-hover:scale-106 transition-transform duration-700"
                    loading="lazy"
                  />

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                  {/* Station Badge */}
                  <div className="absolute top-3 left-3 bg-[#1F1511]/90 backdrop-blur-xs text-[#D4AF37] border border-[#D4AF37]/40 text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-xs">
                    {station.badge}
                  </div>

                  {/* Expand Lightbox Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLightboxStation(station);
                    }}
                    className="absolute top-3 right-3 p-2 bg-black/60 hover:bg-black text-white rounded-full transition shadow-md cursor-pointer"
                    title="View Full High-Res Photo"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                  </button>

                  {/* Step Number in image bottom */}
                  <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between">
                    <div>
                      <h3 className="font-cinzel text-lg font-bold text-white leading-tight">
                        {station.stationName}
                      </h3>
                    </div>
                    <span className="font-cinzel text-3xl font-bold text-white/30">
                      {station.stepNumber}
                    </span>
                  </div>
                </div>

                {/* Content Body */}
                <div className="p-5 flex flex-col grow justify-between space-y-4">
                  <p className="text-xs text-[#CBC2B7] leading-relaxed">
                    {station.shortDesc}
                  </p>

                  <div className="pt-3 border-t border-white/10 space-y-2 text-[11px]">
                    <div className="flex items-start gap-1.5 text-white/90">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0 mt-0.5" />
                      <span>{station.output}</span>
                    </div>

                    <div className="flex items-center justify-between text-[#A69788] pt-1">
                      <span className="font-medium text-[#D4AF37] flex items-center gap-1">
                        <Sparkles className="w-3 h-3" /> Click to view details
                      </span>
                      <span className="text-[10px] uppercase font-semibold text-white/60">
                        {station.toolsUsed.length} Tools In Station
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Detailed Active Station Spotlight Showcase */}
        <div className="bg-[#1C1410] rounded-lg p-6 sm:p-8 lg:p-10 border border-[#D4AF37]/30 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left Column: Big Visual */}
            <div className="lg:col-span-7 relative group">
              <div className="relative aspect-16/10 w-full rounded-md overflow-hidden border-2 border-white/20 shadow-xl">
                <img
                  src={activeStation.image}
                  alt={activeStation.stationName}
                  className="w-full h-full object-cover"
                />
                <button
                  type="button"
                  onClick={() => setLightboxStation(activeStation)}
                  className="absolute bottom-4 right-4 bg-[#1F1511]/90 hover:bg-black text-[#D4AF37] border border-[#D4AF37]/50 text-xs px-3.5 py-2 rounded-xs font-semibold flex items-center gap-1.5 shadow-lg backdrop-blur-xs transition cursor-pointer"
                >
                  <Maximize2 className="w-4 h-4" />
                  <span>Inspect Full-Screen Photo</span>
                </button>
              </div>
            </div>

            {/* Right Column: Deep Technical & Process Explanation */}
            <div className="lg:col-span-5 space-y-4">
              <div className="inline-flex items-center gap-2 text-xs font-bold text-[#D4AF37] uppercase tracking-widest">
                <span className="w-2 h-2 rounded-full bg-[#D4AF37] animate-ping" />
                <span>Station {activeStation.stepNumber} &bull; Sialkot Factory Floor</span>
              </div>

              <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-white leading-tight">
                {activeStation.stationName}
              </h3>

              <p className="text-xs sm:text-sm text-[#CBC2B7] leading-relaxed">
                {activeStation.detailedDesc}
              </p>

              {/* Tools Checklist */}
              <div className="bg-[#140D09] p-4 rounded-md border border-white/10 space-y-2">
                <p className="text-[11px] font-bold uppercase tracking-wider text-[#D4AF37]">
                  Equipment & Standard Operating Procedure:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#E5DCCF]">
                  {activeStation.toolsUsed.map((tool, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
                      <span>{tool}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  onClick={onOpenBespoke}
                  className="bg-[#D4AF37] hover:bg-white text-[#120B08] px-5 py-2.5 rounded-xs font-bold text-xs uppercase tracking-wider transition duration-300 shadow-md cursor-pointer"
                >
                  Inquire Factory OEM / Bulk Export
                </button>
                <a
                  href="#products"
                  className="border border-white/30 hover:border-white text-white px-5 py-2.5 rounded-xs font-medium text-xs uppercase tracking-wider transition"
                >
                  View Finished Products
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Global Logistics & Courier Partners Strip */}
        <div className="mt-14 pt-10 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="flex items-center gap-3.5 bg-[#1C1410] p-4 rounded-md border border-white/5">
            <div className="w-12 h-12 rounded-full bg-yellow-500/10 text-yellow-400 flex items-center justify-center shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-white uppercase tracking-wider">
                DHL Express Worldwide
              </p>
              <p className="text-[11px] text-[#A69788]">
                Daily door-to-door courier van pickup & air express dispatch.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3.5 bg-[#1C1410] p-4 rounded-md border border-white/5">
            <div className="w-12 h-12 rounded-full bg-sky-500/10 text-sky-400 flex items-center justify-center shrink-0">
              <Plane className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-white uppercase tracking-wider">
                SkyNet Worldwide Cargo
              </p>
              <p className="text-[11px] text-[#A69788]">
                Commercial wholesale containers & insured parcel freight.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3.5 bg-[#1C1410] p-4 rounded-md border border-white/5">
            <div className="w-12 h-12 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-white uppercase tracking-wider">
                TCS & Leopard COD
              </p>
              <p className="text-[11px] text-[#A69788]">
                Cash on delivery across all cities & towns of Pakistan.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3.5 bg-[#1C1410] p-4 rounded-md border border-white/5">
            <div className="w-12 h-12 rounded-full bg-[#D4AF37]/10 text-[#D4AF37] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-white uppercase tracking-wider">
                100% Insured Transit
              </p>
              <p className="text-[11px] text-[#A69788]">
                Every parcel insured against loss or damage with tracking ID.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox Modal for Full Screen Inspection */}
      {lightboxStation && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => setLightboxStation(null)}
        >
          <div
            className="relative max-w-5xl w-full bg-[#1C1410] rounded-lg border border-[#D4AF37]/40 overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setLightboxStation(null)}
              className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-black/70 hover:bg-black text-white flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="relative aspect-16/10 w-full overflow-hidden bg-black">
              <img
                src={lightboxStation.image}
                alt={lightboxStation.stationName}
                className="w-full h-full object-contain"
              />
            </div>

            <div className="p-6 bg-[#140D09] border-t border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold text-[#D4AF37] uppercase tracking-widest">
                  {lightboxStation.badge}
                </span>
                <h4 className="font-cinzel text-xl font-bold text-white">
                  {lightboxStation.stationName}
                </h4>
                <p className="text-xs text-[#CBC2B7] mt-1 max-w-2xl">
                  {lightboxStation.detailedDesc}
                </p>
              </div>

              <button
                onClick={() => setLightboxStation(null)}
                className="bg-[#D4AF37] text-[#1F1511] px-5 py-2 rounded-xs text-xs font-bold uppercase tracking-wider shrink-0 cursor-pointer"
              >
                Close View
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
