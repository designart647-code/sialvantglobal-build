import React from 'react';
import { Mail, Phone, MapPin, MessageCircle, ShieldCheck, Heart } from 'lucide-react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../data/translations';
import {
  BUSINESS_ADDRESS,
  BUSINESS_PHONE_DISPLAY,
  BUSINESS_PHONE_RAW,
  BUSINESS_EMAIL,
} from '../utils/whatsapp';

interface Props {
  currentLanguage: LanguageCode;
  onOpenBespoke: () => void;
  onNavigateContact?: () => void;
}

export const Footer: React.FC<Props> = ({ currentLanguage, onOpenBespoke, onNavigateContact }) => {
  const t = TRANSLATIONS[currentLanguage];

  return (
    <footer className="bg-[#120B08] text-[#CBC2B7] pt-16 pb-8 border-t border-[#2E1D13]" id="contact">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand Col */}
          <div className="space-y-4">
            <div className="flex flex-col">
              <span className="font-cinzel text-xl font-bold tracking-[0.16em] text-white">
                SIALVANTGLOBAL INDUSTRIES
              </span>
              <span className="text-[10px] tracking-[0.38em] text-[#D4AF37] font-semibold uppercase mt-0.5">
                HANDCRAFTED PURE LEATHER
              </span>
            </div>
            <p className="text-xs leading-relaxed text-[#A69788]">
              {t.footerTagline}
            </p>
            <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
              <ShieldCheck className="w-4 h-4" />
              <span>100% Genuine Full-Grain Guarantee</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-cinzel text-sm font-bold text-white uppercase tracking-wider mb-4">
              {t.footerQuickLinks}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#" className="hover:text-[#D4AF37] transition">
                  {t.navHome}
                </a>
              </li>
              <li>
                <a href="#bestsellers" className="hover:text-[#D4AF37] transition">
                  {t.navBestsellers}
                </a>
              </li>
              <li>
                <a href="#products" className="hover:text-[#D4AF37] transition">
                  {t.navCollection}
                </a>
              </li>
              <li>
                <a href="#own-workshop" className="hover:text-[#D4AF37] transition">
                  {t.navWorkshop}
                </a>
              </li>
              <li>
                <a href="#story" className="hover:text-[#D4AF37] transition">
                  {t.navCraft}
                </a>
              </li>
              <li>
                <a href="#factory-view" className="hover:text-[#D4AF37] transition flex items-center gap-1.5">
                  <span>{t.navFactory}</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                </a>
              </li>
              <li>
                <button
                  onClick={onOpenBespoke}
                  className="hover:text-[#D4AF37] transition text-left cursor-pointer"
                >
                  {t.navBespoke}
                </button>
              </li>
              <li>
                <a href="#worldwide-shipping" className="hover:text-[#D4AF37] transition">
                  {t.navShipping}
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-[#D4AF37] transition">
                  {t.navFaq}
                </a>
              </li>
              <li>
                {onNavigateContact ? (
                  <button
                    type="button"
                    onClick={onNavigateContact}
                    className="hover:text-[#D4AF37] transition text-left cursor-pointer font-bold text-[#FAF4EB]"
                  >
                    Contact Us & Workshop Desk &rarr;
                  </button>
                ) : (
                  <a href="#contact" className="hover:text-[#D4AF37] transition font-bold text-[#FAF4EB]">
                    Contact Us
                  </a>
                )}
              </li>
            </ul>
          </div>

          {/* Verified Business Contact & Support */}
          <div>
            <h4 className="font-cinzel text-sm font-bold text-white uppercase tracking-wider mb-4">
              {t.footerSupport}
            </h4>
            <ul className="space-y-3.5 text-xs">
              {/* Direct Clickable Phone Call */}
              <li className="flex items-start gap-2.5">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <p className="text-[10px] text-[#A69788] uppercase tracking-wider">
                    {t.footerPhoneLabel}
                  </p>
                  <a
                    href={`tel:+${BUSINESS_PHONE_RAW}`}
                    className="hover:text-white font-mono font-bold text-white text-sm transition"
                    title="Call directly"
                  >
                    {BUSINESS_PHONE_DISPLAY}
                  </a>
                </div>
              </li>

              {/* Direct Clickable WhatsApp */}
              <li className="flex items-start gap-2.5">
                <MessageCircle className="w-4 h-4 text-[#25D366] shrink-0 mt-0.5" />
                <div>
                  <p className="text-[10px] text-[#A69788] uppercase tracking-wider">
                    WhatsApp Orders & Inquiries:
                  </p>
                  <a
                    href={`https://wa.me/${BUSINESS_PHONE_RAW}?text=${encodeURIComponent(
                      'Hello SIALVANTGLOBAL INDUSTRIES, I am interested in your leather products. Please share more details.'
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-[#25D366] font-semibold text-[#25D366] transition inline-block text-xs"
                    title="WhatsApp Us"
                  >
                    WhatsApp Us (Chat Live)
                  </a>
                </div>
              </li>

              {/* Email */}
              <li className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <p className="text-[10px] text-[#A69788] uppercase tracking-wider">
                    {t.footerEmailLabel}
                  </p>
                  <a
                    href={`mailto:${BUSINESS_EMAIL}`}
                    className="hover:text-white transition font-mono text-white/90"
                  >
                    {BUSINESS_EMAIL}
                  </a>
                </div>
              </li>
            </ul>
          </div>

          {/* Verified Complete Business Address & Export Facility */}
          <div>
            <h4 className="font-cinzel text-sm font-bold text-white uppercase tracking-wider mb-4">
              Factory & Atelier Address
            </h4>
            <div className="space-y-3 text-xs text-[#CBC2B7]">
              <div className="flex items-start gap-2.5 bg-[#1C1410] p-3.5 rounded-md border border-white/10">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <p className="text-[10px] text-[#D4AF37] font-semibold uppercase tracking-wider mb-1">
                    Registered Workshop & Dispatch:
                  </p>
                  <p className="text-white leading-relaxed font-sans">
                    {BUSINESS_ADDRESS}
                  </p>
                </div>
              </div>

              <div className="bg-[#1C1410] p-3 rounded-md border border-white/5 space-y-1 text-[11px]">
                <p className="text-[#D4AF37] font-semibold">Worldwide Delivery Channels:</p>
                <p className="text-[#A69788]">
                  DHL Express &bull; FedEx Priority &bull; SkyNet Worldwide Express
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-8 border-t border-white/10 text-center text-xs text-[#A69788] flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>
            &copy; {new Date().getFullYear()} {t.footerCopyright}
          </p>
          <div className="flex items-center gap-1 text-[11px]">
            <span>Handcrafted in Sialkot, Pakistan • Dispatched Worldwide</span>
            <Heart className="w-3 h-3 text-red-500 fill-red-500 inline ml-1" />
          </div>
        </div>
      </div>
    </footer>
  );
};
