import React, { useState, useRef, useEffect } from 'react';
import {
  ShoppingBag,
  Menu,
  X,
  MessageCircle,
  Globe,
  Phone,
  Languages,
  ChevronDown,
  Sparkles,
  Mail,
  Search,
} from 'lucide-react';
import { CurrencyCode, LanguageCode, ProductCategory, CountryConfig } from '../types';
import { CURRENCY_CONFIGS } from '../data/products';
import { TRANSLATIONS, SUPPORTED_LANGUAGES } from '../data/translations';
import {
  BUSINESS_PHONE_DISPLAY,
  BUSINESS_PHONE_RAW,
  BUSINESS_EMAIL,
  getStoredWhatsAppNumber,
} from '../utils/whatsapp';

interface Props {
  currentLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  currentCurrency: CurrencyCode;
  onCurrencyChange: (code: CurrencyCode) => void;
  selectedCountry?: CountryConfig;
  onOpenCountryModal?: () => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenBespoke: () => void;
  onSelectCategory?: (category: ProductCategory) => void;
  onSearch?: (query: string) => void;
  onNavigateHome?: () => void;
  onNavigateContact?: () => void;
}

interface DropdownItem {
  label: string;
  category?: ProductCategory;
  action?: 'bespoke' | 'workshop' | 'craft' | 'factory' | 'contact' | 'filter';
}

interface NavItem {
  id: string;
  label: string;
  hasDropdown?: boolean;
  dropdownItems?: DropdownItem[];
  href?: string;
  action?: 'home' | 'workshop' | 'contact' | 'bespoke';
}

const ANNOUNCEMENT_MESSAGES = [
  'PREMIUM HANDCRAFTED LEATHER GOODS',
  'WORLDWIDE SHIPPING AVAILABLE',
  'CUSTOM-MADE ORDERS WELCOME',
  'BULK & WHOLESALE ORDERS ACCEPTED',
  'CRAFTED BY SKILLED ARTISANS IN OUR OWN WORKSHOP',
  'SIALVANTGLOBAL INDUSTRIES — QUALITY WITHOUT COMPROMISE',
];

export const Header: React.FC<Props> = ({
  currentLanguage,
  onLanguageChange,
  currentCurrency,
  onCurrencyChange,
  selectedCountry,
  onOpenCountryModal,
  cartCount,
  onOpenCart,
  onOpenBespoke,
  onSelectCategory,
  onSearch,
  onNavigateHome,
  onNavigateContact,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [mobileExpandedItem, setMobileExpandedItem] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const navRef = useRef<HTMLDivElement>(null);
  const waNumber = getStoredWhatsAppNumber();
  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(event.target as Node)) {
        setActiveDropdown(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navMenuItems: NavItem[] = [
    {
      id: 'home',
      label: 'HOME',
      action: 'home',
    },
    {
      id: 'men',
      label: 'MEN',
      hasDropdown: true,
      dropdownItems: [
        { label: "Classic Rider Jackets", category: 'jackets', action: 'filter' },
        { label: "Artisan Heavy Duty Belts (38mm)", category: 'belts', action: 'filter' },
        { label: "The Executive Bifold Wallets", category: 'wallets', action: 'filter' },
        { label: "Vintage Leather Messenger Bags", category: 'bags', action: 'filter' },
        { label: "Minimalist Front-Pocket Cardholders", category: 'wallets', action: 'filter' },
        { label: "View All Men's Leather Goods", category: 'all', action: 'filter' },
      ],
    },
    {
      id: 'women',
      label: 'WOMEN',
      hasDropdown: true,
      dropdownItems: [
        { label: "Heritage Continental Long Wallets", category: 'wallets', action: 'filter' },
        { label: "Vintage Leather Satchel & Bags", category: 'bags', action: 'filter' },
        { label: "Slim Tailored Leather Coats", category: 'jackets', action: 'filter' },
        { label: "Solid Brass Buckle Belts", category: 'belts', action: 'filter' },
        { label: "Leather Watch Rolls & Key Organizers", category: 'accessories', action: 'filter' },
        { label: "View All Women's Collection", category: 'all', action: 'filter' },
      ],
    },
    {
      id: 'wallets',
      label: 'WALLETS',
      hasDropdown: true,
      dropdownItems: [
        { label: "The Executive Bifold Wallet", category: 'wallets', action: 'filter' },
        { label: "The Heritage Long Continental Wallet", category: 'wallets', action: 'filter' },
        { label: "Minimalist Full-Grain Card Sleeve", category: 'wallets', action: 'filter' },
        { label: "RFID-Shielded Full-Grain Wallets", category: 'wallets', action: 'filter' },
        { label: "Explore All Wallets & Cardholders", category: 'wallets', action: 'filter' },
      ],
    },
    {
      id: 'bags',
      label: 'BAGS',
      hasDropdown: true,
      dropdownItems: [
        { label: "Vintage Leather Messenger Bag", category: 'bags', action: 'filter' },
        { label: "Sialkot Heritage Weekender Duffel", category: 'bags', action: 'filter' },
        { label: "Executive Laptop & Document Satchel", category: 'bags', action: 'filter' },
        { label: "Artisan Leather Travel Dopp Kit", category: 'bags', action: 'filter' },
        { label: "Explore All Bags & Briefcases", category: 'bags', action: 'filter' },
      ],
    },
    {
      id: 'belts',
      label: 'BELTS',
      hasDropdown: true,
      dropdownItems: [
        { label: "Artisan Heavy Duty Belt (38mm)", category: 'belts', action: 'filter' },
        { label: "Single-Piece English Bridle Leather Belt", category: 'belts', action: 'filter' },
        { label: "Solid Cast Antique Brass Buckle Belts", category: 'belts', action: 'filter' },
        { label: "Custom Sized Leather Belts (32\" - 44\")", category: 'belts', action: 'filter' },
        { label: "Explore All Handcrafted Belts", category: 'belts', action: 'filter' },
      ],
    },
    {
      id: 'jackets',
      label: 'JACKETS',
      hasDropdown: true,
      dropdownItems: [
        { label: "Classic Rider Full-Grain Cowhide Jacket", category: 'jackets', action: 'filter' },
        { label: "Vintage Aviator Leather Bomber Jacket", category: 'jackets', action: 'filter' },
        { label: "Custom Made-to-Measure Jacket Tailoring", action: 'bespoke' },
        { label: "Explore All Leather Jackets", category: 'jackets', action: 'filter' },
      ],
    },
    {
      id: 'accessories',
      label: 'ACCESSORIES',
      hasDropdown: true,
      dropdownItems: [
        { label: "Hand-Stitched Leather Key Fob", category: 'accessories', action: 'filter' },
        { label: "Artisan 3-Slot Watch Roll", category: 'accessories', action: 'filter' },
        { label: "Desk Pads & Mousepads (Veg-Tan)", category: 'accessories', action: 'filter' },
        { label: "Explore All Leather Accessories", category: 'accessories', action: 'filter' },
      ],
    },
    {
      id: 'bespoke',
      label: 'BESPOKE',
      hasDropdown: true,
      dropdownItems: [
        { label: "Custom Jacket Made-to-Measure", action: 'bespoke' },
        { label: "Complimentary Monogram Heat Debossing", action: 'bespoke' },
        { label: "Corporate Logo & Executive Gift Sets", action: 'bespoke' },
        { label: "International Wholesale & Export Container", action: 'bespoke' },
        { label: "Request Custom Quote via WhatsApp", action: 'bespoke' },
      ],
    },
    {
      id: 'workshop',
      label: 'OUR WORKSHOP',
      action: 'workshop',
    },
    {
      id: 'contact',
      label: 'CONTACT US',
      action: 'contact',
    },
  ];

  const handleItemClick = (item: NavItem) => {
    setActiveDropdown(null);
    if (item.action === 'home') {
      if (onNavigateHome) onNavigateHome();
      else window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (item.action === 'workshop') {
      if (onNavigateHome) onNavigateHome();
      setTimeout(() => {
        document.getElementById('own-workshop')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else if (item.action === 'contact') {
      if (onNavigateContact) {
        onNavigateContact();
      } else {
        document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
      }
    } else if (item.action === 'bespoke') {
      onOpenBespoke();
    }
  };

  const handleSubItemClick = (sub: DropdownItem) => {
    setActiveDropdown(null);
    setMobileMenuOpen(false);

    if (sub.action === 'bespoke') {
      onOpenBespoke();
      return;
    }

    if (onNavigateHome) onNavigateHome();

    if (sub.category && onSelectCategory) {
      onSelectCategory(sub.category);
    }

    setTimeout(() => {
      document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
    }, 120);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onNavigateHome) onNavigateHome();
    if (onSearch) onSearch(searchTerm);
    setTimeout(() => {
      document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <header className="sticky top-0 z-40 w-full shadow-md">
      {/* 1. LUXURY SCROLLING ANNOUNCEMENT TICKER (Deep Black, Gold & White, Slim & Responsive) */}
      <div
        className="bg-[#0B0705] text-[#FAF4EB] border-b border-[#241710] overflow-hidden relative py-2 select-none group"
        role="region"
        aria-label="Announcements"
      >
        {/* Subtle Edge Vignette Fades for Editorial Depth */}
        <div className="pointer-events-none absolute left-0 top-0 bottom-0 w-8 sm:w-20 bg-gradient-to-r from-[#0B0705] to-transparent z-10" />
        <div className="pointer-events-none absolute right-0 top-0 bottom-0 w-8 sm:w-20 bg-gradient-to-l from-[#0B0705] to-transparent z-10" />

        {/* Continuous Smooth Horizontal Marquee (Right to Left) */}
        <div className="animate-luxury-marquee flex items-center whitespace-nowrap">
          {[...ANNOUNCEMENT_MESSAGES, ...ANNOUNCEMENT_MESSAGES].map((msg, idx) => (
            <div key={idx} className="flex items-center shrink-0">
              <span className="text-[10px] sm:text-[11px] font-bold tracking-[0.22em] uppercase">
                {msg.includes('SIALVANTGLOBAL INDUSTRIES') ? (
                  <>
                    <span className="font-cinzel text-[#D4AF37] font-extrabold tracking-[0.24em]">
                      SIALVANTGLOBAL INDUSTRIES
                    </span>
                    <span className="text-white font-medium ml-1.5 tracking-[0.18em]">
                      — QUALITY WITHOUT COMPROMISE
                    </span>
                  </>
                ) : (
                  <span className="text-white hover:text-[#D4AF37] transition-colors">
                    {msg}
                  </span>
                )}
              </span>
              {/* Elegant Small Gold Separator */}
              <span className="inline-flex items-center justify-center mx-5 sm:mx-8 text-[#D4AF37] text-xs select-none">
                ✦
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 2. DIRECT WORKSHOP CONTACT & DISPATCH BAR (Deep Charcoal / Black) */}
      <div className="bg-[#120B08] text-[#D1C5B8] text-xs py-1.5 px-4 border-b border-[#241710]">
        <div className="max-w-[1720px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-1.5 text-center sm:text-left">
          <div className="flex items-center gap-2 justify-center">
            <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-pulse"></span>
            <span className="tracking-widest uppercase font-semibold text-[10px] sm:text-[11px] text-[#E5D7C7]">
              Direct Artisan Workshop & Global Export Facility
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-[#A69788] flex-wrap justify-center">
            {/* Direct Email */}
            <a
              href={`mailto:${BUSINESS_EMAIL}`}
              className="hover:text-[#D4AF37] transition flex items-center gap-1.5 cursor-pointer font-mono"
              title="Official Email Inquiries"
            >
              <Mail className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{BUSINESS_EMAIL}</span>
            </a>

            {/* Direct Calling */}
            <a
              href={`tel:+${BUSINESS_PHONE_RAW}`}
              className="hover:text-[#D4AF37] transition flex items-center gap-1 font-mono cursor-pointer"
              title="Call Master Craftsman Directly"
            >
              <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{BUSINESS_PHONE_DISPLAY}</span>
            </a>

            {/* Direct WhatsApp */}
            <a
              href={`https://wa.me/${BUSINESS_PHONE_RAW}?text=${encodeURIComponent(
                'Hello SIALVANTGLOBAL INDUSTRIES, I am interested in your leather products. Please share more details.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#25D366] transition flex items-center gap-1 cursor-pointer font-semibold"
              title="WhatsApp Us"
            >
              <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
              <span className="text-[#25D366]">WhatsApp Us</span>
            </a>
          </div>
        </div>
      </div>

      {/* 2. MAIN LOGO, SEARCH & ACTIONS ROW (Warm Luxury Ivory / White) */}
      <div className="bg-white/98 backdrop-blur-md border-b border-[#E5DCCF] px-4 sm:px-6 lg:px-8 py-3">
        <div className="max-w-[1720px] mx-auto flex items-center justify-between gap-4">
          {/* Brand Logo & Wordmark */}
          <button
            onClick={() => {
              if (onNavigateHome) onNavigateHome();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex flex-col group shrink-0 text-left cursor-pointer"
            aria-label="SIALVANTGLOBAL INDUSTRIES Home"
          >
            <span className="font-cinzel text-xl sm:text-2xl font-extrabold tracking-[0.16em] text-[#1F1511] leading-none group-hover:text-[#8E5431] transition-colors">
              SIALVANTGLOBAL INDUSTRIES
            </span>
            <span className="text-[9px] sm:text-[10px] tracking-[0.38em] text-[#D4AF37] font-bold uppercase mt-1">
              FINE LEATHERCRAFT &bull; EST. SIALKOT
            </span>
          </button>

          {/* Quick Header Search Bar */}
          <form
            onSubmit={handleSearchSubmit}
            className="hidden md:flex items-center flex-1 max-w-md mx-4 relative"
          >
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                if (onSearch) onSearch(e.target.value);
              }}
              placeholder="Search full-grain wallets, bags, jackets, belts..."
              className="w-full pl-9 pr-4 py-1.5 bg-[#FAF7F2] border border-[#ECE3D7] rounded-full text-xs text-[#1F1511] focus:outline-none focus:ring-1 focus:ring-[#8E5431] focus:bg-white transition"
            />
          </form>

          {/* Header Action Tools */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* 30-Language International Selector */}
            <div className="relative flex items-center bg-[#FAF7F2] hover:bg-[#F5EFE6] rounded-md border border-[#ECE3D7] hover:border-[#8E5431]/40 px-2 py-1 text-xs transition">
              <Languages className="w-3.5 h-3.5 text-[#8E5431] mr-1.5 shrink-0" />
              <select
                value={currentLanguage}
                onChange={(e) => onLanguageChange(e.target.value as LanguageCode)}
                className="bg-transparent text-xs font-semibold text-[#1F1511] focus:outline-none cursor-pointer pr-1 max-w-[110px] sm:max-w-[130px] truncate"
                aria-label="Select Language"
              >
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <option key={lang.code} value={lang.code} className="bg-white text-[#1F1511]">
                    {lang.flag} {lang.name} ({lang.nativeName})
                  </option>
                ))}
              </select>
            </div>

            {/* DECRUM-Style Country & Currency Selector Button */}
            <button
              type="button"
              onClick={() => {
                if (onOpenCountryModal) onOpenCountryModal();
              }}
              className="relative flex items-center gap-1.5 bg-[#FAF7F2] hover:bg-[#F5EFE6] rounded-md border border-[#ECE3D7] hover:border-[#8E5431]/40 px-2.5 py-1 text-xs font-semibold text-[#1F1511] transition cursor-pointer"
              title="Change Country & Currency (DECRUM-style)"
              aria-label="Change Delivery Country and Currency"
            >
              <span className="text-sm select-none shrink-0 leading-none">
                {selectedCountry?.flag || '🇺🇸'}
              </span>
              <span className="font-bold text-[11px] sm:text-xs text-[#1F1511]">
                {currentCurrency} ({CURRENCY_CONFIGS[currentCurrency]?.symbol || '$'})
              </span>
              <ChevronDown className="w-3 h-3 text-[#8E5431] shrink-0" />
            </button>

            {/* WhatsApp Quick Order Button */}
            <a
              href={`https://wa.me/${BUSINESS_PHONE_RAW}?text=${encodeURIComponent(
                'Hello SIALVANTGLOBAL INDUSTRIES, I am interested in your leather products. Please share more details.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden lg:inline-flex items-center gap-1.5 bg-[#25D366] hover:bg-[#1eb857] text-white px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-wide shadow-xs transition transform hover:scale-[1.02]"
              title="WhatsApp Order"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-white shrink-0" />
              <span>WhatsApp Order</span>
            </a>

            {/* Shopping Bag & Inquiry Basket Button */}
            <button
              onClick={onOpenCart}
              className="relative p-2 rounded-md hover:bg-[#FAF7F2] text-[#1F1511] border border-transparent hover:border-[#ECE3D7] transition cursor-pointer"
              aria-label="Open Shopping Bag & Inquiry Basket"
              title="Shopping Bag & Inquiry Basket"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#8E5431] text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white animate-scale-in">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-md text-[#1F1511] hover:bg-[#FAF7F2] transition cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* 3. DEDICATED FULL-WIDTH BLACK HORIZONTAL NAVIGATION BAR (Pak World Industries Style) */}
      <nav
        ref={navRef}
        className="hidden xl:block bg-[#0B0806] text-white border-y border-[#261A13] shadow-inner relative z-30"
      >
        <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
          <ul className="flex items-center justify-between text-[13px] font-bold tracking-wider font-cinzel">
            {navMenuItems.map((item) => {
              const isOpen = activeDropdown === item.id;
              return (
                <li
                  key={item.id}
                  className="relative group"
                  onMouseEnter={() => {
                    if (item.hasDropdown) setActiveDropdown(item.id);
                  }}
                  onMouseLeave={() => {
                    if (item.hasDropdown) setActiveDropdown(null);
                  }}
                >
                  <button
                    type="button"
                    onClick={() => {
                      if (item.hasDropdown) {
                        setActiveDropdown(isOpen ? null : item.id);
                      } else {
                        handleItemClick(item);
                      }
                    }}
                    className={`py-3.5 px-3.5 flex items-center gap-1.5 uppercase transition-colors duration-200 cursor-pointer ${
                      isOpen
                        ? 'text-[#D4AF37] bg-white/5'
                        : 'text-white/95 hover:text-[#D4AF37] hover:bg-white/5'
                    }`}
                  >
                    <span>{item.label}</span>
                    {item.hasDropdown && (
                      <ChevronDown
                        className={`w-3.5 h-3.5 text-[#D4AF37] transition-transform duration-200 ${
                          isOpen ? 'rotate-180' : ''
                        }`}
                      />
                    )}
                  </button>

                  {/* Dropdown Menu */}
                  {item.hasDropdown && item.dropdownItems && isOpen && (
                    <div className="absolute top-full left-0 w-72 bg-[#120B08] text-white border border-[#3A291E] shadow-2xl rounded-b-md py-2.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150 font-sans">
                      <div className="px-3.5 pb-2 mb-2 border-b border-[#2C1D15] flex items-center justify-between text-[10px] text-[#D4AF37] uppercase tracking-widest font-cinzel font-bold">
                        <span>{item.label} Collections</span>
                        <Sparkles className="w-3 h-3" />
                      </div>
                      <ul className="space-y-0.5">
                        {item.dropdownItems.map((sub, idx) => (
                          <li key={idx}>
                            <button
                              type="button"
                              onClick={() => handleSubItemClick(sub)}
                              className="w-full text-left px-4 py-2 text-xs text-[#E6DDD3] hover:text-[#D4AF37] hover:bg-[#1E130E] transition-colors flex items-center justify-between group/sub cursor-pointer"
                            >
                              <span>{sub.label}</span>
                              <span className="text-[#8E5431] group-hover/sub:text-[#D4AF37] transition text-sm">
                                &rsaquo;
                              </span>
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        </div>
      </nav>

      {/* 4. MOBILE DRAWER NAVIGATION */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#120B08] text-white border-t border-[#3A291E] max-h-[80vh] overflow-y-auto px-4 py-5 shadow-2xl animate-in slide-in-from-top-3 duration-200 font-sans">
          {/* Mobile Search */}
          <form onSubmit={handleSearchSubmit} className="mb-4 relative">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                if (onSearch) onSearch(e.target.value);
              }}
              placeholder="Search leather catalog..."
              className="w-full pl-9 pr-3 py-2 bg-[#1C1410] border border-[#3A291E] rounded-md text-xs text-white placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
            />
          </form>

          {/* Mobile Country & Currency + Language Picker (DECRUM-Style) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-4 pb-4 border-b border-[#3A291E]">
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onOpenCountryModal) onOpenCountryModal();
              }}
              className="flex items-center justify-between bg-[#1C1410] border border-[#3A291E] hover:border-[#D4AF37] rounded-md px-3 py-2 text-xs text-white transition cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <span className="text-base select-none">{selectedCountry?.flag || '🇺🇸'}</span>
                <span className="text-xs font-semibold text-[#DFD5C8]">
                  {selectedCountry?.name || 'United States'} ({currentCurrency})
                </span>
              </div>
              <span className="text-[10px] text-[#D4AF37] font-bold uppercase tracking-wider">Change &rsaquo;</span>
            </button>

            <div className="flex items-center bg-[#1C1410] border border-[#3A291E] rounded-md px-3 py-1.5 text-xs text-white">
              <Languages className="w-3.5 h-3.5 text-[#D4AF37] mr-2 shrink-0" />
              <select
                value={currentLanguage}
                onChange={(e) => {
                  onLanguageChange(e.target.value as LanguageCode);
                }}
                className="bg-transparent w-full text-xs text-[#DFD5C8] font-medium focus:outline-none cursor-pointer"
                aria-label="Select Language"
              >
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <option key={lang.code} value={lang.code} className="bg-[#1C1410] text-white">
                    {lang.flag} {lang.name} ({lang.nativeName})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Menu Items with Accordions */}
          <div className="space-y-1 font-cinzel text-sm">
            {navMenuItems.map((item) => {
              const isExpanded = mobileExpandedItem === item.id;
              return (
                <div key={item.id} className="border-b border-white/5 pb-1">
                  <div className="flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => {
                        if (item.hasDropdown) {
                          setMobileExpandedItem(isExpanded ? null : item.id);
                        } else {
                          handleItemClick(item);
                          setMobileMenuOpen(false);
                        }
                      }}
                      className="w-full text-left py-2.5 px-2 text-white hover:text-[#D4AF37] transition font-bold flex items-center justify-between cursor-pointer"
                    >
                      <span>{item.label}</span>
                      {item.hasDropdown && (
                        <ChevronDown
                          className={`w-4 h-4 text-[#D4AF37] transition-transform ${
                            isExpanded ? 'rotate-180' : ''
                          }`}
                        />
                      )}
                    </button>
                  </div>

                  {/* Mobile Submenu Accordion */}
                  {item.hasDropdown && item.dropdownItems && isExpanded && (
                    <div className="pl-4 pr-2 py-2 space-y-1 bg-[#1A110D] rounded-md font-sans text-xs">
                      {item.dropdownItems.map((sub, sIdx) => (
                        <button
                          key={sIdx}
                          type="button"
                          onClick={() => handleSubItemClick(sub)}
                          className="w-full text-left py-1.5 px-2 text-[#DFD5C8] hover:text-[#D4AF37] hover:bg-white/5 rounded-xs transition cursor-pointer flex items-center justify-between"
                        >
                          <span>{sub.label}</span>
                          <span className="text-[#8E5431]">&rsaquo;</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Mobile Direct Action Buttons */}
          <div className="pt-5 mt-4 border-t border-[#3A291E] space-y-2.5">
            <a
              href={`https://wa.me/${BUSINESS_PHONE_RAW}?text=${encodeURIComponent(
                'Hello SIALVANTGLOBAL INDUSTRIES, I am interested in your leather products. Please share more details.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 flex items-center justify-center gap-2 bg-[#25D366] text-white rounded-md font-bold text-xs uppercase tracking-wider shadow-md"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>WhatsApp Us</span>
            </a>

            <a
              href={`tel:+${BUSINESS_PHONE_RAW}`}
              className="w-full py-2 flex items-center justify-center gap-2 border border-white/20 text-white rounded-md font-bold text-xs tracking-wider hover:bg-white/5"
            >
              <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Call: {BUSINESS_PHONE_DISPLAY}</span>
            </a>

            <a
              href={`mailto:${BUSINESS_EMAIL}`}
              className="w-full py-2 flex items-center justify-center gap-2 border border-white/20 text-white rounded-md font-bold text-xs tracking-wider hover:bg-white/5 font-mono"
            >
              <Mail className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{BUSINESS_EMAIL}</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
