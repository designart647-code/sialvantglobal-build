import React, { useState } from 'react';
import { Droplets, Sparkles, AlertTriangle, ShieldCheck, Flame, Compass } from 'lucide-react';

export const LeatherGuide: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'tiers' | 'tests' | 'care'>('tiers');

  return (
    <section className="py-20 bg-white border-t border-[#ECE3D7]" id="leather-guide">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs uppercase tracking-widest font-bold text-[#8E5431]">
            Artisan Transparency
          </span>
          <h2 className="font-cinzel text-3xl sm:text-4xl font-bold text-[#1F1511] mt-1">
            The Truth About Leather Grades
          </h2>
          <p className="text-xs sm:text-sm text-[#6B6865] mt-2">
            Why market &quot;Genuine Leather&quot; labels can be misleading, and how SIALVANTGLOBAL INDUSTRIES crafts only unadulterated Full-Grain hides.
          </p>

          {/* Navigation Tabs */}
          <div className="inline-flex p-1 bg-[#F1ECE3] rounded-md mt-6 border border-[#ECE3D7]">
            <button
              onClick={() => setActiveTab('tiers')}
              className={`px-4 py-2 text-xs font-semibold rounded-xs transition cursor-pointer ${
                activeTab === 'tiers'
                  ? 'bg-[#1F1511] text-white shadow-xs'
                  : 'text-[#6B6865] hover:text-[#1F1511]'
              }`}
            >
              Leather Grades Hierarchy
            </button>
            <button
              onClick={() => setActiveTab('tests')}
              className={`px-4 py-2 text-xs font-semibold rounded-xs transition cursor-pointer ${
                activeTab === 'tests'
                  ? 'bg-[#1F1511] text-white shadow-xs'
                  : 'text-[#6B6865] hover:text-[#1F1511]'
              }`}
            >
              4 Home Authenticity Tests
            </button>
            <button
              onClick={() => setActiveTab('care')}
              className={`px-4 py-2 text-xs font-semibold rounded-xs transition cursor-pointer ${
                activeTab === 'care'
                  ? 'bg-[#1F1511] text-white shadow-xs'
                  : 'text-[#6B6865] hover:text-[#1F1511]'
              }`}
            >
              Artisan Care & Patina Guide
            </button>
          </div>
        </div>

        {/* Tab 1: Grades Hierarchy */}
        {activeTab === 'tiers' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-in fade-in duration-300">
            {/* Card 1: Full-Grain (SIALVANTGLOBAL INDUSTRIES Standard) */}
            <div className="bg-[#FFFDF9] rounded-lg p-6 sm:p-7 border-2 border-[#8E5431] shadow-lg relative">
              <span className="absolute -top-3 left-6 bg-[#8E5431] text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full shadow-xs">
                SIALVANTGLOBAL INDUSTRIES Standard
              </span>
              <div className="text-2xl font-cinzel font-bold text-[#1F1511] mb-1 mt-2">
                Full-Grain Leather
              </div>
              <p className="text-xs font-bold text-[#8E5431] uppercase tracking-wider mb-4">
                Grade A+ (Top 10% of Hides)
              </p>
              <p className="text-xs text-[#555] leading-relaxed mb-4">
                The entire natural grain remains intact. Never sanded, buffed, or stamped with artificial print. Retains natural cowhide pores, micro-creases, and dense tensile fibers.
              </p>
              <ul className="text-xs space-y-2 text-[#222]">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                  <span><strong>Lifespan:</strong> 20 to 50+ Years (Heirloom)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                  <span><strong>Patina:</strong> Matures and darkens luxuriously</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                  <span><strong>Breathability:</strong> Completely organic & skin-safe</span>
                </li>
              </ul>
            </div>

            {/* Card 2: Top-Grain */}
            <div className="bg-[#F9F6F0] rounded-lg p-6 sm:p-7 border border-[#ECE3D7]">
              <div className="text-2xl font-cinzel font-bold text-[#1F1511] mb-1">
                Top-Grain Leather
              </div>
              <p className="text-xs font-semibold text-[#6B6865] uppercase tracking-wider mb-4">
                Grade B (Standard Commercial)
              </p>
              <p className="text-xs text-[#555] leading-relaxed mb-4">
                Top few millimeters are lightly sanded to remove scars, followed by an acrylic protective topcoat. Thinner and more uniform, but loses breathability and natural aging ability.
              </p>
              <ul className="text-xs space-y-2 text-[#555]">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-600" />
                  <span><strong>Lifespan:</strong> 4 to 8 Years</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-600" />
                  <span><strong>Patina:</strong> Minimal to None</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-600" />
                  <span><strong>Feel:</strong> Plasticky topcoat layer</span>
                </li>
              </ul>
            </div>

            {/* Card 3: "Genuine Leather" Scraps */}
            <div className="bg-red-50/40 rounded-lg p-6 sm:p-7 border border-red-200">
              <div className="text-2xl font-cinzel font-bold text-[#1F1511] mb-1">
                &ldquo;Genuine Leather&rdquo;
              </div>
              <p className="text-xs font-semibold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" /> Buyer Beware (Scrap / Bonded)
              </p>
              <p className="text-xs text-[#555] leading-relaxed mb-4">
                An industry marketing term for the lowest layer split from the meat side, often reconstituted with shredded leather powder and glued onto polyurethane film.
              </p>
              <ul className="text-xs space-y-2 text-[#777]">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                  <span><strong>Lifespan:</strong> 6 to 18 Months</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                  <span><strong>Failure:</strong> Flakes, peels, and tears easily</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                  <span><strong>Smell:</strong> Chemical petroleum solvent odor</span>
                </li>
              </ul>
            </div>
          </div>
        )}

        {/* Tab 2: 4 Home Authenticity Tests */}
        {activeTab === 'tests' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 animate-in fade-in duration-300">
            <div className="bg-[#F9F6F0] p-6 rounded-lg border border-[#ECE3D7]">
              <div className="w-12 h-12 rounded-full bg-[#8E5431]/10 text-[#8E5431] flex items-center justify-center mb-4">
                <Droplets className="w-6 h-6" />
              </div>
              <h4 className="font-cinzel text-base font-bold text-[#1F1511] mb-1.5">
                1. Water Drop Absorption
              </h4>
              <p className="text-xs text-[#555] leading-relaxed">
                Place a single droplet of water on unsealed leather. Real full-grain leather absorbs it within 20 seconds, leaving a temporary darker spot that dries naturally. Synthetic plastic lets it sit forever.
              </p>
            </div>

            <div className="bg-[#F9F6F0] p-6 rounded-lg border border-[#ECE3D7]">
              <div className="w-12 h-12 rounded-full bg-[#8E5431]/10 text-[#8E5431] flex items-center justify-center mb-4">
                <Sparkles className="w-6 h-6" />
              </div>
              <h4 className="font-cinzel text-base font-bold text-[#1F1511] mb-1.5">
                2. Natural Tannic Aroma
              </h4>
              <p className="text-xs text-[#555] leading-relaxed">
                Authentic vegetable-tanned leather has a rich, earthy, oaky aroma derived from natural tree barks. Counterfeit or PU leather gives off a harsh synthetic solvent odor.
              </p>
            </div>

            <div className="bg-[#F9F6F0] p-6 rounded-lg border border-[#ECE3D7]">
              <div className="w-12 h-12 rounded-full bg-[#8E5431]/10 text-[#8E5431] flex items-center justify-center mb-4">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h4 className="font-cinzel text-base font-bold text-[#1F1511] mb-1.5">
                3. Edge Fiber Inspection
              </h4>
              <p className="text-xs text-[#555] leading-relaxed">
                Look at the raw cut edges. Pure full-grain leather reveals dense, intertwined protein fibers. Bonded or fake leather reveals neat multi-layer sandwich glue lines.
              </p>
            </div>

            <div className="bg-[#F9F6F0] p-6 rounded-lg border border-[#ECE3D7]">
              <div className="w-12 h-12 rounded-full bg-[#8E5431]/10 text-[#8E5431] flex items-center justify-center mb-4">
                <Compass className="w-6 h-6" />
              </div>
              <h4 className="font-cinzel text-base font-bold text-[#1F1511] mb-1.5">
                4. Thumb Scratch & Buff
              </h4>
              <p className="text-xs text-[#555] leading-relaxed">
                Scratch lightly with your fingernail. Pull-up full-grain leather changes shade as oils displace. Simply rub the mark firmly with your warm thumb — and the scratch disappears!
              </p>
            </div>
          </div>
        )}

        {/* Tab 3: Care Guide */}
        {activeTab === 'care' && (
          <div className="bg-[#F9F6F0] p-8 rounded-lg border border-[#ECE3D7] grid grid-cols-1 md:grid-cols-3 gap-6 animate-in fade-in duration-300">
            <div>
              <h4 className="font-cinzel text-lg font-bold text-[#1F1511] mb-2">
                1. Conditioning (Every 6 Months)
              </h4>
              <p className="text-xs text-[#555] leading-relaxed">
                Apply a dime-sized amount of organic beeswax balm or natural neatsfoot oil using a microfiber cloth in gentle circular strokes. This replenishes moisture and maintains suppleness.
              </p>
            </div>
            <div>
              <h4 className="font-cinzel text-lg font-bold text-[#1F1511] mb-2">
                2. If Caught In Heavy Rain
              </h4>
              <p className="text-xs text-[#555] leading-relaxed">
                Do NOT use a hairdryer or place on radiators, as extreme heat hardens leather protein fibers. Gently pat dry with a cotton towel and let it dry naturally in room temperature shade.
              </p>
            </div>
            <div>
              <h4 className="font-cinzel text-lg font-bold text-[#1F1511] mb-2">
                3. Storage & Breathing
              </h4>
              <p className="text-xs text-[#555] leading-relaxed">
                Never seal full-grain leather in airtight plastic bags which trap humidity. Always store in breathable cotton dust bags (provided complimentary with all SIALVANTGLOBAL INDUSTRIES bags and jackets).
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
