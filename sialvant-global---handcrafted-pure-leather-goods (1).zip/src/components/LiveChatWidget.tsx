import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquare,
  Send,
  MessageCircle,
  Minimize2,
  ShieldCheck,
} from 'lucide-react';
import { LanguageCode } from '../types';
import {
  BUSINESS_PHONE_DISPLAY,
  getStoredWhatsAppNumber,
} from '../utils/whatsapp';

interface ChatMessage {
  id: string;
  sender: 'artisan' | 'user';
  text: string;
  time: string;
}

interface Props {
  currentLanguage?: LanguageCode;
  onOpenBespoke?: () => void;
  onOpenWhatsAppConfig?: () => void;
}

const CHAT_I18N: Record<
  string,
  {
    welcome: string;
    deskTitle: string;
    onlineStatus: string;
    waBannerText: string;
    waOpenBtn: string;
    placeholder: string;
    quickFaqLabel: string;
    quickQuestions: string[];
    replies: {
      shipping: string;
      sizing: string;
      quality: string;
      monogram: string;
      pricing: string;
      fallback: string;
    };
  }
> = {
  en: {
    welcome:
      'Welcome to SIALVANTGLOBAL INDUSTRIES! I am live from our workshop in Sialkot. May I assist you with custom leather tailoring, full-grain leather grades, or international dispatch?',
    deskTitle: 'SIALVANTGLOBAL INDUSTRIES Artisan Desk',
    onlineStatus: 'Online • Sialkot Workshop',
    waBannerText: 'WhatsApp Direct Hotline:',
    waOpenBtn: 'Open WA →',
    placeholder: 'Ask anything about our leather craftsmanship...',
    quickFaqLabel: 'Quick FAQ:',
    quickQuestions: [
      'International shipping & courier delivery?',
      'Custom jacket sizing & measurements',
      'Is your leather 100% full-grain?',
      'Can I add custom monogram initials?',
    ],
    replies: {
      shipping:
        '📦 Worldwide Shipping: We dispatch all international orders via DHL Express and SkyNet with door-to-door tracking in 3 to 6 business days. Express shipping is complimentary worldwide on orders over $150 USD!',
      sizing:
        '🧥 Custom Sizing: Our jackets and coats are tailored from pure drum-dyed full-grain hides. Simply share your chest, shoulder, and sleeve measurements and our master tailors will craft your piece made-to-measure without extra tailoring fees.',
      quality:
        '🛡️ Pure Leather Guarantee: We use exclusively 100% pure full-grain vegetable-tanned hides. Zero synthetic plastics or bonded scraps. Every piece develops a richer patina the longer you wear it.',
      monogram:
        '✨ Monogramming: Yes! We offer complimentary custom gold-foil or blind heat debossing (up to 4 initials) on our wallets, bags, and belts. Simply mention your initials during checkout.',
      pricing:
        '🏷️ Pricing & Currency: All prices are live in USD, GBP, EUR, CAD, or AUD using our top currency selector. Bulk corporate gift orders and wholesale inquiries receive special artisan rates.',
      fallback:
        'Thank you for your message! Our senior artisan is reviewing your request. For immediate direct consultation and photo references, please click the "Open WA" button to chat with us on WhatsApp.',
    },
  },
  ar: {
    welcome:
      'أهلاً وسهلاً بكم في سيلفانت جلوبال! نتواصل معكم مباشرة من ورشتنا الحرفية في سيالكوت. كيف يمكننا مساعدتكم اليوم بخصوص الجلود الطبيعية أو التفصيل المخصص أو الشحن الدولي؟',
    deskTitle: 'مكتب حرفيي سيلفانت',
    onlineStatus: 'متصل الآن • ورشة سيالكوت',
    waBannerText: 'خط واتساب المباشر:',
    waOpenBtn: 'فتح واتساب ←',
    placeholder: 'اكتب استفسارك حول المصنوعات الجلدية...',
    quickFaqLabel: 'أسئلة سريعة:',
    quickQuestions: [
      'الشحن الدولي ومواعيد التوصيل؟',
      'تفصيل السترات والمقاسات الخاصة',
      'هل الجلد طبيعي 100%؟',
      'هل يمكن حفر الحروف والأسماء بالذهب؟',
    ],
    replies: {
      shipping:
        '📦 الشحن الدولي: نشحن إلى كافة دول الخليج والعالم عبر دي إتش إل إكسبريس (DHL Express) وسكاي نت خلال 3 إلى 6 أيام عمل مع تتبع مباشر. الشحن مجاني للطلبات فوق 150 دولاراً!',
      sizing:
        '🧥 تفصيل السترات: تصنع ستراتنا من أفخر جلود البقر الطبيعية الكاملة. يمكنكم تزويدنا بمقاسات الصدر والكتف وطول الأكمام ليقوم خياطونا بتفصيلها خصيصاً لكم دون رسوم إضافية.',
      quality:
        '🛡️ ضمان الجلد الأصلي: نستخدم جلوداً طبيعية 100% مدبوغة نباتياً وخالية تماماً من البلاستيك الصناعي أو الجلود المضغوطة، وتكتسب لممعاناً فاخراً مع مرور الوقت.',
      monogram:
        '✨ نقش الحروف: نعم! نقدم خدمة نقش الحروف والأسماء بماء الذهب أو الحفر الحراري مجاناً على المحافظ والحقائب والأحزمة.',
      pricing:
        '🏷️ العملات والأسعار: يمكنكم استعراض الأسعار بالدولار واليورو والجنيه الإسترليني وغيرها عبر محول العملات أعلى الموقع.',
      fallback:
        'شكراً لرسالتكم الكريمة! يمكنكم النقر على زر واتساب للتحدث مباشرة مع كبير الحرفيين وإرسال صور المقاسات والتفاصيل.',
    },
  },
  de: {
    welcome:
      'Willkommen bei SIALVANTGLOBAL INDUSTRIES! Wir sind live aus unserer Manufaktur in Sialkot für Sie da. Wie können wir Ihnen bei Lederqualitäten, Maßanfertigungen oder dem Expressversand helfen?',
    deskTitle: 'SIALVANTGLOBAL INDUSTRIES Manufaktur-Desk',
    onlineStatus: 'Online • Manufaktur Sialkot',
    waBannerText: 'Direkte WhatsApp-Hotline:',
    waOpenBtn: 'Zu WhatsApp →',
    placeholder: 'Stellen Sie Ihre Frage zur Lederverarbeitung...',
    quickFaqLabel: 'Schnell-FAQ:',
    quickQuestions: [
      'Internationaler Expressversand & Laufzeiten?',
      'Maßanfertigung für Lederjacken',
      'Ist das Leder 100 % Vollnarbenleder?',
      'Individuelle Monogramm-Prägung möglich?',
    ],
    replies: {
      shipping:
        '📦 Weltweiter Versand: Wir versenden per DHL Express und SkyNet mit lückenloser Sendungsverfolgung innerhalb von 3 bis 6 Werktagen. Ab 150 USD Bestellwert ist der Expressversand komplett kostenfrei!',
      sizing:
        '🧥 Maßanfertigung: Unsere Jacken werden aus feinstem Vollnarbenleder gefertigt. Nennen Sie uns Ihre Maße für Brust, Schulter und Ärmellänge – unsere Schneidermeister fertigen Ihre Jacke passgenau ohne Aufpreis.',
      quality:
        '🛡️ 100 % Vollnarben-Garantie: Wir verarbeiten ausschließlich pflanzlich gegerbtes Vollnarbenleder. Frei von Kunstleder oder Spaltledern. Das Leder entwickelt über Jahre eine edle Bernsteinglanz-Patina.',
      monogram:
        '✨ Monogramm: Sehr gerne! Wir bieten kostenlose Goldfolien- oder Blindprägungen (bis zu 4 Initialen) auf Geldbörsen, Taschen und Gürteln.',
      pricing:
        '🏷️ Währungen & Preise: Sie können die Preise oben flexibel in USD, EUR, GBP, CAD oder AUD anzeigen lassen. Für Firmenaufträge bieten wir spezielle Manufaktur-Konditionen.',
      fallback:
        'Vielen Dank für Ihre Nachricht! Unser Meisterhandwerker meldet sich umgehend. Für direkte Beratung oder Maßübermittlung klicken Sie einfach auf "Zu WhatsApp".',
    },
  },
  fr: {
    welcome:
      'Bienvenue chez SIALVANTGLOBAL INDUSTRIES ! Nous sommes en direct de notre atelier de Sialkot. Comment pouvons-nous vous conseiller sur nos cuirs pleine fleur, confections sur mesure ou livraisons internationales ?',
    deskTitle: 'Atelier SIALVANTGLOBAL INDUSTRIES Direct',
    onlineStatus: 'En ligne • Atelier de Sialkot',
    waBannerText: 'Ligne WhatsApp Directe :',
    waOpenBtn: 'Ouvrir WhatsApp →',
    placeholder: 'Posez votre question sur notre maroquinerie...',
    quickFaqLabel: 'FAQ Rapide :',
    quickQuestions: [
      'Délais de livraison express internationale ?',
      'Tailles et confection sur mesure de vestes',
      'Le cuir est-il 100 % pleine fleur ?',
      'Personnalisation par monogramme doré ?',
    ],
    replies: {
      shipping:
        '📦 Livraison Internationale : Nous expédions dans le monde entier avec suivi sécurisé via DHL Express et SkyNet en 3 à 6 jours ouvrés. La livraison express est offerte dès 150 USD d’achats !',
      sizing:
        '🧥 Veste sur Mesure : Nos vestes sont taillées dans un cuir pleine fleur d’exception. Transmettez-nous vos mensurations et nos maîtres tailleurs ajustent la coupe sans frais supplémentaires.',
      quality:
        '🛡️ Garantie Cuir Véritable : Nous utilisons exclusivement du cuir pleine fleur à tannage végétal. Zéro matière synthétique ni croûte de cuir. Le cuir développe une splendide patine avec le temps.',
      monogram:
        '✨ Gravure Monogramme : Oui ! Nous proposons gratuitement le marquage à l’or fin ou à chaud (jusqu’à 4 lettres) sur tous nos portefeuilles, sacs et ceintures.',
      pricing:
        '🏷️ Devises & Tarifs : Consultez nos prix en USD, EUR, GBP, CAD ou AUD grâce au sélecteur en haut. Tarifs dégressifs pour les commandes d’entreprises.',
      fallback:
        'Merci pour votre message ! Notre maître maroquinier étudie votre demande. Pour un échange direct ou l’envoi de photos de référence, cliquez sur "Ouvrir WhatsApp".',
    },
  },
  es: {
    welcome:
      '¡Bienvenido a SIALVANTGLOBAL INDUSTRIES! Estamos en directo desde nuestro taller en Sialkot. ¿En qué podemos ayudarle hoy sobre calidades de cuero, confección a medida o envíos internacionales?',
    deskTitle: 'Atención Artesanal SIALVANTGLOBAL INDUSTRIES',
    onlineStatus: 'En línea • Taller Sialkot',
    waBannerText: 'Línea Directa WhatsApp:',
    waOpenBtn: 'Abrir WhatsApp →',
    placeholder: 'Pregunte lo que desee sobre nuestra marroquinería...',
    quickFaqLabel: 'Preguntas Rápidas:',
    quickQuestions: [
      '¿Plazos y opciones de envío internacional?',
      'Confección y medidas a medida para chaquetas',
      '¿Es cuero 100% flor entera legítimo?',
      '¿Puedo personalizar con iniciales grabadas?',
    ],
    replies: {
      shipping:
        '📦 Envío Internacional: Enviamos a todo el mundo con seguimiento puerta a puerta a través de DHL Express y SkyNet en 3 a 6 días laborables. ¡Envío express gratuito en pedidos superiores a 150 USD!',
      sizing:
        '🧥 Chaquetas a Medida: Nuestras chaquetas se confeccionan con cuero de flor entera teñido al tambor. Facilítenos sus medidas y nuestros maestros sastres elaborarán su prenda a medida sin coste adicional.',
      quality:
        '🛡️ Garantía de Cuir Puro: Usamos exclusivamente piel de vacuno de flor entera 100% pura con curtición vegetal. Cero plásticos sintéticos. Desarrolla una pátina cada vez más hermosa.',
      monogram:
        '✨ Grabado Personalizado: ¡Sí! Ofrecemos grabado en pan de oro o bajo relieve térmico de cortesía (hasta 4 iniciales) en billeteras, bolsos y cinturones.',
      pricing:
        '🏷️ Precios y Monedas: Puede alternar precios en USD, EUR, GBP, CAD o AUD en la barra superior. Disponemos de tarifas especiales para pedidos corporativos y compras mayoristas.',
      fallback:
        '¡Muchas gracias por su mensaje! Nuestro maestro artesano está revisando su consulta. Para dialogar al instante y compartir detalles de medidas, pulse "Abrir WhatsApp".',
    },
  },
};

export const LiveChatWidget: React.FC<Props> = ({ currentLanguage = 'en' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(1);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const waNumber = getStoredWhatsAppNumber();

  const strings = CHAT_I18N[currentLanguage] || CHAT_I18N.en!;

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    return [
      {
        id: 'welcome-1',
        sender: 'artisan',
        text: strings.welcome,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  });

  // Update initial welcome if language switches and user hasn't sent anything
  useEffect(() => {
    setMessages((prev) => {
      if (prev.length === 1 && prev[0].sender === 'artisan') {
        return [
          {
            id: 'welcome-1',
            sender: 'artisan',
            text: strings.welcome,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ];
      }
      return prev;
    });
  }, [currentLanguage, strings.welcome]);

  // Scroll to bottom on new message
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isTyping]);

  const handleOpenChat = () => {
    setIsOpen(true);
    setUnreadCount(0);
  };

  const handleSend = (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputText('');

    // Simulate artisan reply based on keywords
    setIsTyping(true);
    setTimeout(() => {
      let reply = strings.replies.fallback;
      const lower = text.toLowerCase();

      if (
        lower.includes('delivery') ||
        lower.includes('ship') ||
        lower.includes('express') ||
        lower.includes('dhl') ||
        lower.includes('versand') ||
        lower.includes('livraison') ||
        lower.includes('envío') ||
        lower.includes('شحن')
      ) {
        reply = strings.replies.shipping;
      } else if (
        lower.includes('jacket') ||
        lower.includes('size') ||
        lower.includes('measure') ||
        lower.includes('fit') ||
        lower.includes('jacke') ||
        lower.includes('veste') ||
        lower.includes('chaqueta') ||
        lower.includes('مقاس') ||
        lower.includes('سترة')
      ) {
        reply = strings.replies.sizing;
      } else if (
        lower.includes('leather') ||
        lower.includes('pure') ||
        lower.includes('grain') ||
        lower.includes('quality') ||
        lower.includes('leder') ||
        lower.includes('cuir') ||
        lower.includes('cuero') ||
        lower.includes('جلد')
      ) {
        reply = strings.replies.quality;
      } else if (
        lower.includes('monogram') ||
        lower.includes('initial') ||
        lower.includes('emboss') ||
        lower.includes('name') ||
        lower.includes('prägung') ||
        lower.includes('gravure') ||
        lower.includes('grabado') ||
        lower.includes('نقش') ||
        lower.includes('حفر')
      ) {
        reply = strings.replies.monogram;
      } else if (
        lower.includes('price') ||
        lower.includes('rate') ||
        lower.includes('cost') ||
        lower.includes('preis') ||
        lower.includes('prix') ||
        lower.includes('precio') ||
        lower.includes('سعر')
      ) {
        reply = strings.replies.pricing;
      }

      const artisanMsg: ChatMessage = {
        id: `artisan-${Date.now()}`,
        sender: 'artisan',
        text: reply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, artisanMsg]);
      setIsTyping(false);
    }, 900);
  };

  const handleTransferToWhatsApp = () => {
    const chatSummary = messages
      .slice(-4)
      .map((m) => `${m.sender === 'user' ? 'Client' : 'Artisan'}: ${m.text}`)
      .join('\n');

    const text = `Hello SIALVANTGLOBAL INDUSTRIES! I am connecting from the website live chat desk:\n\nRecent conversation:\n${chatSummary}\n\nPlease assist me directly on WhatsApp.`;
    const url = `https://wa.me/${waNumber}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <>
      {/* Floating Launcher Pill / Button */}
      {!isOpen && (
        <div className="fixed bottom-6 right-6 z-40 flex items-center gap-2.5">
          {/* Direct WhatsApp Quick Launch */}
          <a
            href={`https://wa.me/${waNumber}?text=${encodeURIComponent(
              'Hello SIALVANTGLOBAL INDUSTRIES, I am interested in your leather products. Please share more details.'
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1eb857] text-white px-4 py-3 rounded-full shadow-2xl font-semibold text-xs tracking-wide transition duration-300 transform hover:scale-105"
            title="WhatsApp Us"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>WhatsApp Us</span>
          </a>

          {/* Website Live Chat Launcher */}
          <button
            onClick={handleOpenChat}
            className="relative bg-[#1F1511] hover:bg-[#8E5431] text-white px-4 py-3 rounded-full shadow-2xl flex items-center gap-2.5 font-semibold text-xs tracking-wide border border-[#D4AF37]/50 transition duration-300 transform hover:scale-105 cursor-pointer group"
            aria-label="Open Live Chat Box"
          >
            <div className="relative">
              <MessageSquare className="w-4 h-4 text-[#D4AF37]" />
              {unreadCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-600 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center border-2 border-[#1F1511] animate-pulse">
                  {unreadCount}
                </span>
              )}
            </div>
            <span>Live Chat</span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          </button>
        </div>
      )}

      {/* Floating Chat Box Window */}
      {isOpen && (
        <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 w-[calc(100vw-2rem)] sm:w-[390px] h-[540px] max-h-[85vh] bg-white rounded-lg shadow-2xl border border-[#ECE3D7] flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 duration-200">
          {/* Header */}
          <div className="bg-[#1F1511] text-white p-3.5 sm:p-4 flex items-center justify-between border-b border-[#D4AF37]/30">
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <div className="w-9 h-9 rounded-full bg-[#8E5431] flex items-center justify-center text-[#D4AF37] font-cinzel font-bold text-sm border border-[#D4AF37]/40 shadow-xs">
                  SG
                </div>
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#25D366] rounded-full border-2 border-[#1F1511]" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="font-cinzel text-sm font-bold tracking-wide">
                    {strings.deskTitle}
                  </h3>
                  <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                </div>
                <p className="text-[11px] text-[#A69788] flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  <span>{strings.onlineStatus}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1 text-gray-300">
              <button
                onClick={handleTransferToWhatsApp}
                className="p-1.5 hover:text-[#25D366] hover:bg-white/10 rounded-full transition cursor-pointer"
                title="Switch this chat to WhatsApp"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 hover:text-white hover:bg-white/10 rounded-full transition cursor-pointer"
                aria-label="Minimize Chat"
              >
                <Minimize2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* WhatsApp Bridge Banner */}
          <div className="bg-[#25D366]/10 px-3 py-1.5 border-b border-[#25D366]/20 flex items-center justify-between text-[11px] text-emerald-950">
            <span className="flex items-center gap-1">
              <MessageCircle className="w-3.5 h-3.5 text-[#25D366] fill-[#25D366]" />
              <span>{strings.waBannerText} {BUSINESS_PHONE_DISPLAY}</span>
            </span>
            <button
              onClick={handleTransferToWhatsApp}
              className="text-[#1F1511] font-bold hover:underline cursor-pointer text-[10px] uppercase"
            >
              {strings.waOpenBtn}
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#F9F6F0]/60">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.sender === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-[85%] rounded-lg px-3.5 py-2.5 text-xs shadow-xs leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-[#1F1511] text-white rounded-br-xs'
                      : 'bg-white text-[#222222] border border-[#ECE3D7] rounded-bl-xs'
                  }`}
                >
                  <p>{msg.text}</p>
                  <span
                    className={`block text-[9px] mt-1 text-right ${
                      msg.sender === 'user' ? 'text-gray-400' : 'text-gray-400'
                    }`}
                  >
                    {msg.time}
                  </span>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center gap-1.5 text-xs text-gray-500 bg-white p-2.5 rounded-lg border border-[#ECE3D7] w-fit shadow-xs">
                <span className="w-1.5 h-1.5 bg-[#8E5431] rounded-full animate-bounce"></span>
                <span className="w-1.5 h-1.5 bg-[#8E5431] rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1.5 h-1.5 bg-[#8E5431] rounded-full animate-bounce [animation-delay:0.4s]"></span>
                <span className="text-[11px] ml-1 text-[#6B6865]">Artisan responding...</span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Questions Suggestions */}
          <div className="px-3 py-2 bg-white border-t border-[#ECE3D7] overflow-x-auto scrollbar-none flex items-center gap-1.5">
            <span className="text-[10px] font-semibold text-[#8E5431] uppercase shrink-0">
              {strings.quickFaqLabel}
            </span>
            {strings.quickQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(q)}
                className="text-[11px] whitespace-nowrap bg-[#F9F6F0] hover:bg-[#ECE3D7] text-[#1F1511] border border-[#ECE3D7] px-2.5 py-1 rounded-full transition cursor-pointer shrink-0"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input Footer */}
          <div className="p-2.5 bg-white border-t border-[#ECE3D7] flex items-center gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder={strings.placeholder}
              className="flex-1 text-xs px-3 py-2 bg-[#F9F6F0] border border-[#ECE3D7] rounded-md focus:outline-none focus:ring-1 focus:ring-[#8E5431] text-[#1F1511]"
            />

            <button
              onClick={() => handleSend()}
              disabled={!inputText.trim()}
              className="p-2 bg-[#1F1511] hover:bg-[#8E5431] disabled:opacity-40 text-white rounded-md transition cursor-pointer shrink-0"
              title="Send message"
              aria-label="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </>
  );
};
