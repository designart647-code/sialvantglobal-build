import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';
import { CurrencyCode, LanguageCode, Product } from '../types';
import { ProductCard } from './ProductCard';

interface Props {
  products: Product[];
  currentCurrency: CurrencyCode;
  currentLanguage?: LanguageCode;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, selectedColor: string) => void;
  onBuyItNow?: (product: Product, selectedColor: string) => void;
  onViewAll: () => void;
}

export const NewArrivalsSection: React.FC<Props> = ({
  products,
  currentCurrency,
  currentLanguage = 'en',
  onQuickView,
  onAddToCart,
  onBuyItNow,
  onViewAll,
}) => {
  // Select standout new arrivals (e.g. jacket, watch roll, briefcase, duffle, or apron)
  const preferredIds = [
    'classic-rider-jacket',
    'handcrafted-watch-roll',
    'executive-leather-briefcase',
    'diplomat-weekender-duffle',
  ];

  let newArrivals = preferredIds
    .map((id) => products.find((p) => p.id === id))
    .filter((p): p is Product => Boolean(p));

  // Fallback if not found
  if (newArrivals.length < 4) {
    newArrivals = products.slice(4, 8);
  }

  return (
    <section className="py-16 sm:py-20 bg-[#FAF7F2] border-t border-[#ECE3D7] relative" id="new-arrivals">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-6 border-b border-[#ECE3D7]">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#8E5431] uppercase tracking-[0.25em] mb-2">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>FRESH FROM OUR WORKSHOP</span>
            </div>
            <h2 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold text-[#120B08] tracking-tight">
              NEW ARRIVALS
            </h2>
            <p className="text-xs sm:text-sm text-[#6B6865] mt-2 max-w-xl">
              Explore the latest master-tailored jackets, handcrafted travel luggage, and collector accessories fresh off the artisan benches.
            </p>
          </div>

          <button
            onClick={onViewAll}
            className="mt-4 md:mt-0 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.15em] text-[#8E5431] hover:text-[#120B08] group transition cursor-pointer"
          >
            <span>View Complete Catalog</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* 4 Products per row on desktop, 2 on mobile */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-6 lg:gap-8">
          {newArrivals.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              currentCurrency={currentCurrency}
              currentLanguage={currentLanguage}
              onQuickView={onQuickView}
              onAddToCart={onAddToCart}
              onBuyItNow={onBuyItNow}
              isCompact={false}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
