import React from 'react';
import { Hammer, Sparkles, ShieldCheck, Users, CheckCircle, ArrowRight } from 'lucide-react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface Props {
  currentLanguage?: LanguageCode;
  onExploreFactory: () => void;
  onOpenBespoke: () => void;
}

export const OwnWorkshopSection: React.FC<Props> = ({
  currentLanguage = 'en',
  onExploreFactory,
  onOpenBespoke,
}) => {
  const t = TRANSLATIONS[currentLanguage];

  return (
    <section className="py-24 bg-[#FAF7F2] border-t border-[#ECE3D7] relative overflow-hidden" id="own-workshop">
      {/* Subtle background ambient texture */}
      <div className="absolute inset-0 leather-subtle-pattern opacity-40 pointer-events-none" />

      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Workshop Imagery Composition */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-lg overflow-hidden shadow-2xl border-4 border-white bg-black">
              <img
                src="/src/assets/images/leather_machine_stitch_1793899641382.jpg"
                onError={(e) => {
                  // Fallback to pattern cut or machine stitch
                  (e.target as HTMLImageElement).src =
                    '/src/assets/images/leather_machine_stitch_1793899243698.jpg';
                }}
                alt="Master Craftsman in Sialkot Workshop"
                className="w-full aspect-4/3 object-cover hover:scale-103 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

              <div className="absolute bottom-6 left-6 right-6 text-white">
                <span className="text-[10px] tracking-[0.25em] uppercase bg-[#D4AF37] text-[#120B08] font-bold px-3 py-1 rounded-xs inline-block mb-2 shadow-xs">
                  Sialkot Production Unit
                </span>
                <h4 className="font-cinzel text-xl sm:text-2xl font-bold leading-snug drop-shadow-sm">
                  100% In-House Master Craftsmanship
                </h4>
                <p className="text-xs text-[#E5DCCF] mt-1 font-light">
                  No middlemen. No third-party outsourcing. From raw hide grading to final stitching.
                </p>
              </div>
            </div>

            {/* Floating Trust Crest Badge */}
            <div className="absolute -bottom-6 -right-3 sm:-right-6 bg-[#120B08] text-[#D4AF37] p-5 rounded-lg shadow-2xl border border-[#D4AF37]/40 max-w-xs hidden sm:flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center font-cinzel font-bold text-lg shrink-0">
                SG
              </div>
              <div>
                <p className="text-xs font-bold text-white tracking-wider uppercase">
                  Generational Guild
                </p>
                <p className="text-[11px] text-[#A69788]">
                  Over 30 years of leather heritage in Sialkot, Pakistan.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Narrative */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#8E5431] uppercase tracking-[0.25em]">
              <Hammer className="w-4 h-4 text-[#D4AF37]" />
              <span>ABOUT OUR CRAFT &bull; OUR SIALKOT WORKSHOP</span>
            </div>

            <h2 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold text-[#120B08] leading-[1.2] tracking-tight">
              Artisanal Leather, <br />
              <span className="italic font-normal text-[#8E5431]">Crafted For Generations</span>
            </h2>

            <div className="text-sm sm:text-base text-[#4A4540] leading-relaxed space-y-4">
              <p className="font-medium text-[#1F1511] text-base sm:text-lg leading-relaxed border-l-2 border-[#D4AF37] pl-4 italic">
                100% genuine full-grain handmade leather goods. Each piece is meticulously shaped by master craftsmen in our dedicated workshop to stand the test of time and develop a legendary natural patina.
              </p>
              <p>
                Unlike commercial fashion brands that outsource production to third-party assembly lines, SIALVANTGLOBAL INDUSTRIES operates its own dedicated artisan workshop in Sialkot, Punjab, Pakistan — the historic global heart of master leathercraft.
              </p>
              <p>
                Every hide is hand-selected from top-grade raw cattle and buff skins, tanned through natural vegetable barks, and cut panel by panel. Our generational cobblers and saddle stitchers assemble each piece in-house under strict quality controls.
              </p>
            </div>

            {/* 4 Pillars of Own Production */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="bg-white p-4 rounded-md border border-[#ECE3D7] shadow-xs space-y-1">
                <div className="flex items-center gap-2 font-bold text-xs text-[#120B08] uppercase tracking-wide">
                  <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                  <span>{t.workshopPillar1Title}</span>
                </div>
                <p className="text-xs text-[#6B6865] leading-relaxed">
                  {t.workshopPillar1Desc}
                </p>
              </div>

              <div className="bg-white p-4 rounded-md border border-[#ECE3D7] shadow-xs space-y-1">
                <div className="flex items-center gap-2 font-bold text-xs text-[#120B08] uppercase tracking-wide">
                  <Users className="w-4 h-4 text-[#D4AF37]" />
                  <span>{t.workshopPillar2Title}</span>
                </div>
                <p className="text-xs text-[#6B6865] leading-relaxed">
                  {t.workshopPillar2Desc}
                </p>
              </div>

              <div className="bg-white p-4 rounded-md border border-[#ECE3D7] shadow-xs space-y-1">
                <div className="flex items-center gap-2 font-bold text-xs text-[#120B08] uppercase tracking-wide">
                  <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                  <span>{t.workshopPillar3Title}</span>
                </div>
                <p className="text-xs text-[#6B6865] leading-relaxed">
                  {t.workshopPillar3Desc}
                </p>
              </div>

              <div className="bg-white p-4 rounded-md border border-[#ECE3D7] shadow-xs space-y-1">
                <div className="flex items-center gap-2 font-bold text-xs text-[#120B08] uppercase tracking-wide">
                  <CheckCircle className="w-4 h-4 text-[#D4AF37]" />
                  <span>{t.workshopPillar4Title}</span>
                </div>
                <p className="text-xs text-[#6B6865] leading-relaxed">
                  {t.workshopPillar4Desc}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <button
                onClick={onExploreFactory}
                className="inline-flex items-center gap-2 bg-[#120B08] hover:bg-[#8E5431] text-white px-7 py-3.5 rounded-xs font-semibold text-xs uppercase tracking-[0.15em] transition duration-300 shadow-md cursor-pointer"
              >
                <span>{t.btnViewFactoryTour}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenBespoke}
                className="inline-flex items-center gap-2 border border-[#120B08] hover:bg-[#120B08] hover:text-white text-[#120B08] px-7 py-3.5 rounded-xs font-semibold text-xs uppercase tracking-[0.15em] transition duration-300 cursor-pointer"
              >
                <span>{t.btnCustomWorkshopOrder}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
