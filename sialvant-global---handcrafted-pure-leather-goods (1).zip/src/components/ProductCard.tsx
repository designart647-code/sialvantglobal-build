import React, { useState } from 'react';
import { ShoppingBag, Eye, Star, MessageCircle, Check, Zap } from 'lucide-react';
import { CurrencyCode, LanguageCode, Product } from '../types';
import { CURRENCY_CONFIGS } from '../data/products';
import { TRANSLATIONS } from '../data/translations';
import { createProductWhatsAppUrl } from '../utils/whatsapp';

interface Props {
  product: Product;
  currentCurrency: CurrencyCode;
  currentLanguage?: LanguageCode;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, selectedColor: string) => void;
  onBuyItNow?: (product: Product, selectedColor: string) => void;
  isCompact?: boolean;
  gridCols?: 4 | 6 | 8;
}

export const ProductCard: React.FC<Props> = ({
  product,
  currentCurrency,
  currentLanguage = 'en',
  onQuickView,
  onAddToCart,
  onBuyItNow,
  isCompact = true,
  gridCols = 4,
}) => {
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [addedToast, setAddedToast] = useState(false);
  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  const activeColor = product.colors[selectedColorIndex] || product.colors[0];
  const currencyConfig = CURRENCY_CONFIGS[currentCurrency] || CURRENCY_CONFIGS.USD;
  const formattedPrice = currencyConfig.format(product.priceUSD);
  const formattedOriginal = product.originalPriceUSD
    ? currencyConfig.format(product.originalPriceUSD)
    : null;

  const activeImage = activeColor.image || product.image;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, activeColor.name);
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 1600);
  };

  const handleBuyItNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onBuyItNow) {
      onBuyItNow(product, activeColor.name);
    } else {
      onAddToCart(product, activeColor.name);
    }
  };

  const whatsappUrl = createProductWhatsAppUrl(
    product,
    activeColor.name,
    undefined,
    currentCurrency,
    formattedPrice
  );

  const isEight = gridCols === 8;
  const isSix = gridCols === 6;

  return (
    <div
      onClick={() => onQuickView(product)}
      className="group bg-white rounded-lg overflow-hidden border border-[#ECE3D7] hover:border-[#8E5431]/60 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between h-full cursor-pointer"
    >
      {/* Product Image Wrapper */}
      <div className="relative aspect-square w-full bg-[#F3EFEA] overflow-hidden">
        {product.tag && (
          <span
            className={`absolute top-2 left-2 z-10 bg-[#1F1511] text-[#D4AF37] border border-[#D4AF37]/30 font-bold tracking-wider rounded-xs uppercase shadow-xs ${
              isEight ? 'text-[8px] px-1 py-0.5' : 'text-[9px] sm:text-[10px] px-2 py-0.5'
            }`}
          >
            {product.tag}
          </span>
        )}

        <img
          src={activeImage}
          alt={`${product.name} - ${activeColor.name}`}
          className="w-full h-full object-cover object-center group-hover:scale-106 transition-transform duration-500 ease-out"
          loading="lazy"
        />

        {/* Hover Quick View Overlay */}
        <div className="absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center p-2">
          <span
            className={`bg-white/95 text-[#1F1511] rounded-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 shadow-md transform translate-y-2 group-hover:translate-y-0 transition duration-200 ${
              isEight ? 'px-2 py-1 text-[9px]' : 'px-3 py-1.5 text-[11px]'
            }`}
          >
            <Eye className="w-3.5 h-3.5 text-[#8E5431]" />
            <span>{isEight ? 'View' : 'View Full Details'}</span>
          </span>
        </div>
      </div>

      {/* Product Content */}
      <div
        className={`flex flex-col grow justify-between text-center ${
          isEight ? 'p-2 sm:p-2.5' : isSix ? 'p-2.5 sm:p-3' : 'p-3.5 sm:p-4'
        }`}
      >
        <div>
          {/* Rating */}
          {product.reviewsCount && product.reviewsCount > 0 && product.rating ? (
            <div className={`flex items-center justify-center gap-0.5 ${isEight ? 'mb-0.5' : 'mb-1.5'}`}>
              <div className="flex text-[#D4AF37]">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-2.5 h-2.5 sm:w-3 sm:h-3 ${
                      i < Math.floor(product.rating || 0)
                        ? 'fill-[#D4AF37] text-[#D4AF37]'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-[9px] sm:text-[10px] text-[#6B6865] font-medium ml-0.5">
                ({product.reviewsCount})
              </span>
            </div>
          ) : (
            <div className={isEight ? 'h-2 mb-0.5' : 'h-4 mb-1.5'} />
          )}

          {/* Product Name */}
          <h3
            className={`font-cinzel font-bold text-[#1F1511] group-hover:text-[#8E5431] transition-colors mb-1 line-clamp-1 ${
              isEight ? 'text-xs sm:text-[13px]' : isSix ? 'text-[13px] sm:text-sm' : 'text-sm sm:text-[15px]'
            }`}
            title={product.name}
          >
            {product.name}
          </h3>

          {/* Leather Specification Tag */}
          <p
            className={`text-[#8E5431] font-medium italic line-clamp-1 ${
              isEight ? 'text-[9px] mb-1.5' : 'text-[10px] mb-2'
            }`}
          >
            {product.leatherType}
          </p>

          {/* Color Display Name & Round Color Selectors */}
          <div
            className={`space-y-1 ${isEight ? 'mb-2' : 'mb-2.5'}`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className={`text-[#555] font-medium truncate ${isEight ? 'text-[10px]' : 'text-[11px]'}`}>
              Color: <span className="font-bold text-[#1F1511]">{activeColor.name}</span>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-1 max-w-[260px] mx-auto">
              {product.colors.map((color, idx) => (
                <button
                  key={color.name}
                  type="button"
                  onClick={() => setSelectedColorIndex(idx)}
                  className={`rounded-full border transition-all cursor-pointer ${
                    isEight ? 'w-3 h-3 sm:w-3.5 sm:h-3.5' : isSix ? 'w-3.5 h-3.5' : 'w-3.5 h-3.5 sm:w-4 sm:h-4'
                  } ${
                    selectedColorIndex === idx
                      ? 'border-[#991B1B] scale-125 ring-2 ring-[#991B1B] z-10'
                      : 'border-black/25 hover:scale-110 opacity-85 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: color.hex }}
                  title={color.name}
                  aria-label={`Select ${color.name}`}
                />
              ))}
            </div>
          </div>

          {/* Price */}
          <div className={`flex items-baseline justify-center gap-1.5 ${isEight ? 'mb-2' : 'mb-2.5'}`}>
            <span
              className={`font-bold text-[#8E5431] ${
                isEight ? 'text-sm sm:text-base' : isSix ? 'text-base' : 'text-base sm:text-lg'
              }`}
            >
              {formattedPrice}
            </span>
            {formattedOriginal && (
              <span className="text-[10px] sm:text-[11px] text-gray-400 line-through">
                {formattedOriginal}
              </span>
            )}
          </div>
        </div>

        {/* 3 CLEAR PURCHASE OPTIONS (PREMIUM RED & BLACK THEME) */}
        <div
          className={`space-y-1.5 border-t border-[#ECE3D7]/70 ${isEight ? 'pt-2' : 'pt-2.5'}`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* 1. WHATSAPP ORDER: Rich Premium RED Background, White Icon & Text */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className={`w-full inline-flex items-center justify-center gap-1.5 bg-[#991B1B] hover:bg-[#7F1D1D] active:bg-[#601212] text-white font-bold uppercase tracking-wider rounded-xs transition-colors duration-200 shadow-xs cursor-pointer border border-[#991B1B] hover:border-[#7F1D1D] ${
              isEight ? 'py-1.5 px-1 text-[9px] sm:text-[10px]' : isSix ? 'py-1.5 px-1.5 text-[10px]' : 'py-2 px-2 text-[10px] sm:text-[11px]'
            }`}
            title="WhatsApp Order"
          >
            <MessageCircle className="w-3.5 h-3.5 text-white fill-white shrink-0" />
            <span className="text-white">WhatsApp Order</span>
          </a>

          {/* 2. ADD TO CART & 3. BUY IT NOW IN A CRISP 2-COLUMN SPLIT */}
          <div className="grid grid-cols-2 gap-1.5">
            {/* 2. ADD TO CART: White Background, Black Text & Border, Subtle Black Hover */}
            <button
              type="button"
              onClick={handleAddToCart}
              className={`font-bold uppercase tracking-wider rounded-xs transition-all duration-200 flex items-center justify-center gap-1 cursor-pointer border ${
                isEight ? 'py-1 px-1 text-[8.5px] sm:text-[9.5px]' : 'py-1.5 px-1.5 text-[10px]'
              } ${
                addedToast
                  ? 'bg-[#1F1511] text-white border-[#1F1511]'
                  : 'bg-white hover:bg-[#1F1511] text-[#1F1511] hover:text-white border-[#1F1511]'
              }`}
              title="Add product to order bag"
            >
              {addedToast ? (
                <>
                  <Check className="w-3 h-3 text-white" />
                  <span>Added</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-3 h-3 text-current" />
                  <span>Add to Cart</span>
                </>
              )}
            </button>

            {/* 3. BUY IT NOW: Black Background, White Text & Icon, Dark Red Hover Accent */}
            <button
              type="button"
              onClick={handleBuyItNow}
              className={`font-bold uppercase tracking-wider rounded-xs transition-colors duration-200 flex items-center justify-center gap-1 bg-[#120B08] hover:bg-[#991B1B] active:bg-[#7F1D1D] text-white cursor-pointer shadow-xs border border-[#120B08] hover:border-[#991B1B] ${
                isEight ? 'py-1 px-1 text-[8.5px] sm:text-[9.5px]' : 'py-1.5 px-1.5 text-[10px]'
              }`}
              title="Instant checkout"
            >
              <Zap className="w-3 h-3 text-white fill-white" />
              <span>Buy It Now</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
