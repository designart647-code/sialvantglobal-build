import React, { useState, useEffect } from 'react';
import {
  Star,
  ShieldCheck,
  Truck,
  RotateCcw,
  Sparkles,
  MessageCircle,
  ShoppingBag,
  Zap,
  ArrowLeft,
  ChevronRight,
  Maximize2,
  X,
  Check,
  CheckCircle2,
  Share2,
  Clock,
  Ruler,
  Info,
} from 'lucide-react';
import { Product, CurrencyCode, LanguageCode } from '../types';
import { CURRENCY_CONFIGS, TESTIMONIALS } from '../data/products';
import { TRANSLATIONS } from '../data/translations';
import { createProductWhatsAppUrl, BUSINESS_PHONE_DISPLAY, BUSINESS_PHONE_RAW } from '../utils/whatsapp';

interface Props {
  product: Product;
  allProducts: Product[];
  currentCurrency: CurrencyCode;
  currentLanguage?: LanguageCode;
  onBack: () => void;
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product, color: string, monogram?: string, size?: string) => void;
  onBuyItNow: (p: Product, color: string, monogram?: string, size?: string, quantity?: number) => void;
}

export const ProductDetailPage: React.FC<Props> = ({
  product,
  allProducts,
  currentCurrency,
  currentLanguage = 'en',
  onBack,
  onSelectProduct,
  onAddToCart,
  onBuyItNow,
}) => {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>(() => {
    if (product.sizes && product.sizes.length > 0) return product.sizes[0];
    if (product.category === 'jackets') return 'L';
    if (product.category === 'belts') return '36';
    return 'Standard';
  });
  const [quantity, setQuantity] = useState(1);
  const [monogram, setMonogram] = useState('');
  const [activeTab, setActiveTab] = useState<'details' | 'specs' | 'sizing' | 'shipping' | 'reviews'>('details');
  const [isZoomOpen, setIsZoomOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [addedToast, setAddedToast] = useState(false);

  // Recently viewed products tracking
  const [recentlyViewed, setRecentlyViewed] = useState<Product[]>([]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setSelectedImageIndex(0);
    setSelectedColorIndex(0);
    if (product.sizes && product.sizes.length > 0) {
      setSelectedSize(product.sizes[0]);
    } else if (product.category === 'jackets') {
      setSelectedSize('L');
    } else if (product.category === 'belts') {
      setSelectedSize('36');
    } else {
      setSelectedSize('Standard');
    }

    // Save to recently viewed
    try {
      const stored = localStorage.getItem('sialvant_recent_ids');
      const ids: string[] = stored ? JSON.parse(stored) : [];
      const updated = [product.id, ...ids.filter((id) => id !== product.id)].slice(0, 6);
      localStorage.setItem('sialvant_recent_ids', JSON.stringify(updated));

      const recentItems = updated
        .filter((id) => id !== product.id)
        .map((id) => allProducts.find((p) => p.id === id))
        .filter((p): p is Product => Boolean(p));
      setRecentlyViewed(recentItems);
    } catch {
      // ignore
    }
  }, [product.id, allProducts]);

  const currencyConfig = CURRENCY_CONFIGS[currentCurrency] || CURRENCY_CONFIGS.USD;
  const formattedPrice = currencyConfig.format(product.priceUSD * quantity);
  const singleUnitPriceFormatted = currencyConfig.format(product.priceUSD);
  const formattedOriginal = product.originalPriceUSD
    ? currencyConfig.format(product.originalPriceUSD * quantity)
    : null;

  const activeColor = product.colors[selectedColorIndex] || product.colors[0];
  const colorImage = activeColor.image;
  const baseImages = product.galleryImages && product.galleryImages.length > 0
    ? product.galleryImages
    : [product.image];
  const images = colorImage && !baseImages.includes(colorImage)
    ? [colorImage, ...baseImages]
    : colorImage
    ? [colorImage, ...baseImages.filter((img) => img !== colorImage)]
    : baseImages;
  const currentImage = images[selectedImageIndex] || colorImage || product.image;

  const defaultSizes = product.sizes || (
    product.category === 'jackets'
      ? ['S', 'M', 'L', 'XL', '2XL', 'Custom Tailored']
      : product.category === 'belts'
      ? ['32', '34', '36', '38', '40', '42']
      : ['Standard']
  );

  const whatsappUrl = createProductWhatsAppUrl(
    product,
    activeColor.name,
    monogram.trim() || undefined,
    currentCurrency,
    formattedPrice,
    defaultSizes.length > 1 ? selectedSize : undefined
  );

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      onAddToCart(product, activeColor.name, monogram.trim() || undefined, selectedSize);
    }
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2000);
  };

  const handleBuyItNow = () => {
    onBuyItNow(product, activeColor.name, monogram.trim() || undefined, selectedSize, quantity);
  };

  const handleShareLink = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const relatedProducts = allProducts
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  return (
    <div className="bg-[#FAF7F2] min-h-screen pt-4 pb-20">
      {/* Zoom / Lightbox Modal */}
      {isZoomOpen && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <button
            onClick={() => setIsZoomOpen(false)}
            className="absolute top-6 right-6 text-white/80 hover:text-white p-2 rounded-full bg-white/10 transition cursor-pointer"
            aria-label="Close zoom preview"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={currentImage}
            alt={product.name}
            className="max-h-[90vh] max-w-[90vw] object-contain rounded-md shadow-2xl"
          />
        </div>
      )}

      {/* Main Container */}
      <div className="max-w-[1580px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb & Navigation Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 py-3 border-b border-[#ECE3D7] mb-6 text-xs text-[#6B6865]">
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={onBack}
              className="inline-flex items-center gap-1 text-[#8E5431] font-semibold hover:underline cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Collection</span>
            </button>
            <ChevronRight className="w-3 h-3 text-gray-400" />
            <span className="capitalize">{product.category}</span>
            <ChevronRight className="w-3 h-3 text-gray-400" />
            <span className="text-[#1F1511] font-medium truncate max-w-xs">{product.name}</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleShareLink}
              className="inline-flex items-center gap-1.5 text-[#1F1511] hover:text-[#8E5431] transition font-medium cursor-pointer"
              title="Copy product link"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{copiedLink ? 'Link Copied!' : 'Share'}</span>
            </button>
            <span className="text-gray-300">|</span>
            <span className="text-emerald-700 font-semibold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>In Stock & Ready for Dispatch</span>
            </span>
          </div>
        </div>

        {/* 2-Column Product Detail Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 bg-white rounded-xl border border-[#ECE3D7] p-4 sm:p-7 lg:p-9 shadow-sm mb-12">
          {/* LEFT SIDE: Product Gallery (7 cols on lg) */}
          <div className="lg:col-span-7 flex flex-col-reverse md:flex-row gap-4">
            {/* Thumbnail Column */}
            <div className="flex md:flex-col gap-2.5 overflow-x-auto md:overflow-y-auto max-h-[580px] scrollbar-none shrink-0">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`relative w-16 h-16 sm:w-20 sm:h-20 rounded-md overflow-hidden border-2 transition cursor-pointer shrink-0 ${
                    selectedImageIndex === idx
                      ? 'border-[#8E5431] ring-2 ring-[#8E5431]/20 scale-[1.02]'
                      : 'border-[#ECE3D7] hover:border-gray-400 opacity-80 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt={`${product.name} thumbnail ${idx + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>

            {/* Main Stage Image */}
            <div className="relative flex-1 bg-[#F9F6F0] rounded-lg overflow-hidden border border-[#ECE3D7] flex items-center justify-center min-h-[380px] sm:min-h-[520px] max-h-[640px] group">
              {product.tag && (
                <span className="absolute top-4 left-4 z-10 bg-[#1F1511] text-[#D4AF37] border border-[#D4AF37]/30 text-[10px] font-bold tracking-widest px-3 py-1 rounded-xs uppercase shadow-sm">
                  {product.tag}
                </span>
              )}

              <button
                onClick={() => setIsZoomOpen(true)}
                className="absolute top-4 right-4 z-10 bg-white/90 hover:bg-white text-[#1F1511] p-2 rounded-full shadow-md transition cursor-pointer opacity-90 group-hover:opacity-100"
                title="Zoom image"
                aria-label="Zoom image"
              >
                <Maximize2 className="w-4 h-4 text-[#8E5431]" />
              </button>

              <img
                src={currentImage}
                alt={product.name}
                className="w-full h-full object-cover max-h-[620px] transition-transform duration-500 ease-out group-hover:scale-105 cursor-zoom-in"
                onClick={() => setIsZoomOpen(true)}
              />

              <div className="absolute bottom-3 right-3 bg-black/60 text-white text-[10px] px-2.5 py-1 rounded-full backdrop-blur-xs flex items-center gap-1.5 pointer-events-none">
                <span>Click image to zoom</span>
              </div>
            </div>
          </div>

          {/* RIGHT SIDE: Product Information & 3 Action Buttons (5 cols on lg) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div>
              {/* Badge & Category */}
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[11px] font-bold text-[#8E5431] uppercase tracking-[0.2em]">
                  Handcrafted • Sialkot Atelier
                </span>
                {product.reviewsCount && product.reviewsCount > 0 && product.rating ? (
                  <div className="flex items-center gap-1 text-xs">
                    <div className="flex text-[#D4AF37]">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
                      ))}
                    </div>
                    <span className="font-bold text-[#1F1511] ml-1">{product.rating}</span>
                    <span className="text-[#6B6865]">
                      ({product.reviewsCount} verified review{product.reviewsCount > 1 ? 's' : ''})
                    </span>
                  </div>
                ) : (
                  <span className="text-[11px] text-[#8E5431] font-semibold bg-[#FAF7F2] px-2.5 py-0.5 rounded-full border border-[#ECE3D7]">
                    Artisan Workshop Release
                  </span>
                )}
              </div>

              {/* Product Title */}
              <h1 className="font-cinzel text-2xl sm:text-3xl lg:text-3xl font-bold text-[#1F1511] tracking-tight leading-snug">
                {product.name}
              </h1>

              {/* Price & Currency */}
              <div className="mt-3 flex items-baseline gap-3 pb-4 border-b border-[#ECE3D7]">
                <span className="text-2xl sm:text-3xl font-extrabold text-[#8E5431]">
                  {formattedPrice}
                </span>
                {formattedOriginal && (
                  <span className="text-sm sm:text-base text-gray-400 line-through">
                    {formattedOriginal}
                  </span>
                )}
                <span className="text-xs text-[#6B6865] uppercase font-semibold ml-1">
                  ({currentCurrency})
                </span>
                {product.originalPriceUSD && (
                  <span className="ml-auto bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase">
                    Artisan Direct Value
                  </span>
                )}
              </div>

              {/* Short Description */}
              <p className="mt-4 text-xs sm:text-sm text-[#4A4540] leading-relaxed">
                {product.description}
              </p>

              {/* Leather Grade Highlight Pill */}
              <div className="mt-4 p-3 bg-[#FAF7F2] rounded-md border border-[#ECE3D7] flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-[#8E5431] shrink-0" />
                <div className="text-xs">
                  <p className="font-bold text-[#1F1511]">Guaranteed Leather Grade:</p>
                  <p className="text-[#8E5431] font-semibold">{product.leatherType}</p>
                </div>
              </div>

              {/* Leather Color Selection with 14 Round Selectors */}
              <div className="mt-5 space-y-2.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-[#1F1511] uppercase tracking-wider">
                    Leather Color: <span className="text-[#991B1B] font-extrabold">{activeColor.name}</span>
                  </span>
                  <span className="text-[11px] text-[#6B6865]">{product.colors.length} shades available</span>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {product.colors.map((color, idx) => (
                    <button
                      key={color.name}
                      type="button"
                      onClick={() => {
                        setSelectedColorIndex(idx);
                        setSelectedImageIndex(0);
                      }}
                      className={`relative w-8 h-8 rounded-full border-2 transition-all cursor-pointer flex items-center justify-center ${
                        selectedColorIndex === idx
                          ? 'border-[#991B1B] ring-2 ring-[#991B1B] scale-110 shadow-md z-10'
                          : 'border-black/20 hover:scale-105 opacity-85 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: color.hex }}
                      title={color.name}
                      aria-label={`Select ${color.name}`}
                    >
                      {selectedColorIndex === idx && (
                        <span className={`w-2 h-2 rounded-full ${color.hex === '#F8FAFC' || color.hex === '#FFFFFF' ? 'bg-black' : 'bg-white'}`} />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selector (If applicable) */}
              {defaultSizes.length > 1 && (
                <div className="mt-5 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-[#1F1511] uppercase tracking-wider">
                      Select Size: <span className="text-[#8E5431] font-semibold">{selectedSize}</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setActiveTab('sizing')}
                      className="text-[11px] text-[#8E5431] font-medium hover:underline cursor-pointer flex items-center gap-1"
                    >
                      <Ruler className="w-3 h-3" />
                      <span>Size Guide</span>
                    </button>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {defaultSizes.map((size) => (
                      <button
                        key={size}
                        type="button"
                        onClick={() => setSelectedSize(size)}
                        className={`px-3 py-1.5 rounded-xs text-xs font-semibold border transition cursor-pointer ${
                          selectedSize === size
                            ? 'border-[#8E5431] bg-[#8E5431] text-white shadow-xs'
                            : 'border-[#ECE3D7] bg-white text-[#1F1511] hover:border-gray-400'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Custom Monogram Option */}
              <div className="mt-5 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <label htmlFor="monogram-input" className="font-bold text-[#1F1511] uppercase tracking-wider flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Complimentary Monogram Initials (Optional):</span>
                  </label>
                  <span className="text-[11px] text-emerald-700 font-semibold">Free Gift Personalization</span>
                </div>
                <input
                  id="monogram-input"
                  type="text"
                  maxLength={4}
                  value={monogram}
                  onChange={(e) => setMonogram(e.target.value.toUpperCase())}
                  placeholder="e.g. 'M.V' (Up to 4 Letters)"
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#ECE3D7] rounded-xs text-xs font-mono tracking-widest text-[#1F1511] focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                />
              </div>

              {/* Quantity Counter */}
              <div className="mt-5 flex items-center gap-4 text-xs">
                <span className="font-bold text-[#1F1511] uppercase tracking-wider">Quantity:</span>
                <div className="flex items-center border border-[#ECE3D7] rounded-xs bg-[#FAF7F2] overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1}
                    className="px-3 py-1.5 text-gray-700 hover:bg-[#ECE3D7] disabled:opacity-40 transition cursor-pointer font-bold text-sm"
                    aria-label="Decrease quantity"
                  >
                    -
                  </button>
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={quantity}
                    onChange={(e) => {
                      const digits = e.target.value.replace(/\D/g, '');
                      if (digits === '') {
                        setQuantity(1);
                      } else {
                        const parsed = parseInt(digits, 10);
                        if (parsed > 0) setQuantity(parsed);
                      }
                    }}
                    onKeyDown={(e) => {
                      if (['e', 'E', '+', '-', '.', ','].includes(e.key)) {
                        e.preventDefault();
                      }
                    }}
                    className="w-14 text-center text-xs font-bold text-[#1F1511] bg-white border-x border-[#ECE3D7] py-1.5 focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                    aria-label="Quantity"
                  />
                  <button
                    type="button"
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1.5 text-gray-700 hover:bg-[#ECE3D7] transition cursor-pointer font-bold text-sm"
                    aria-label="Increase quantity"
                  >
                    +
                  </button>
                </div>
                <span className="text-[11px] text-[#6B6865]">
                  ({singleUnitPriceFormatted} each)
                </span>
              </div>
            </div>

            {/* THREE MANDATORY PURCHASE BUTTONS (RED & BLACK LUXURY THEME) */}
            <div className="space-y-2.5 pt-4 border-t border-[#ECE3D7]">
              {/* Option 1: WhatsApp Order (Green, No Visible Phone Number) */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 bg-[#15803D] hover:bg-[#166534] active:bg-[#14532D] text-white rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all duration-200 transform hover:scale-[1.01] cursor-pointer border border-[#166534]"
                title="WhatsApp Order"
              >
                <MessageCircle className="w-4 h-4 text-white fill-white shrink-0" />
                <span className="text-white">WhatsApp Order</span>
              </a>

              {/* Option 2: Add to Cart */}
              <button
                type="button"
                onClick={handleAddToCart}
                className={`w-full py-3.5 px-4 rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all duration-200 cursor-pointer border-2 ${
                  addedToast
                    ? 'bg-[#1F1511] text-white border-[#1F1511]'
                    : 'bg-white hover:bg-[#1F1511] text-[#1F1511] hover:text-white border-[#1F1511]'
                }`}
              >
                {addedToast ? (
                  <>
                    <Check className="w-4 h-4 text-white" />
                    <span>Added to Order Bag!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4 text-current" />
                    <span>2. Add to Cart</span>
                  </>
                )}
              </button>

              {/* Option 3: Buy It Now */}
              <button
                type="button"
                onClick={handleBuyItNow}
                className="w-full py-3.5 px-4 bg-[#120B08] hover:bg-[#991B1B] active:bg-[#7F1D1D] text-white rounded-xs font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all duration-200 transform hover:scale-[1.01] cursor-pointer border border-[#120B08] hover:border-[#991B1B]"
              >
                <Zap className="w-4 h-4 text-white fill-white" />
                <span>3. Buy It Now (Direct Checkout)</span>
              </button>
            </div>

            {/* Micro Guarantees */}
            <div className="grid grid-cols-2 gap-2 text-[11px] text-[#6B6865] pt-2 border-t border-gray-100">
              <div className="flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-[#8E5431] shrink-0" />
                <span>DHL Express (3-5 Days)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <RotateCcw className="w-3.5 h-3.5 text-[#8E5431] shrink-0" />
                <span>30-Day Pure Leather Guarantee</span>
              </div>
            </div>
          </div>
        </div>

        {/* BELOW MAIN SECTION: Detailed Tabs (Description, Specs, Size Chart, Shipping, Reviews) */}
        <div className="bg-white rounded-xl border border-[#ECE3D7] shadow-sm overflow-hidden mb-16">
          {/* Tabs Navigation */}
          <div className="flex border-b border-[#ECE3D7] bg-[#FAF7F2] overflow-x-auto scrollbar-none">
            {[
              { id: 'details', label: 'Craft & Description' },
              { id: 'specs', label: 'Technical Specifications' },
              { id: 'sizing', label: 'Size Guide & Measurement' },
              { id: 'shipping', label: 'Worldwide Shipping & Returns' },
              { id: 'reviews', label: product.reviewsCount ? `Verified Reviews (${product.reviewsCount})` : 'Reviews' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3.5 px-5 sm:px-6 text-xs font-bold uppercase tracking-wider whitespace-nowrap transition border-b-2 cursor-pointer ${
                  activeTab === tab.id
                    ? 'border-[#8E5431] text-[#8E5431] bg-white'
                    : 'border-transparent text-[#6B6865] hover:text-[#1F1511]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="p-6 sm:p-8 text-xs sm:text-sm leading-relaxed text-[#4A4540]">
            {/* Tab 1: Detailed Description */}
            {activeTab === 'details' && (
              <div className="space-y-4 max-w-4xl">
                <h3 className="font-cinzel text-lg font-bold text-[#1F1511]">
                  Artisanal Heritage & Workshop Craft
                </h3>
                <p>
                  Every {product.name} is meticulously cut, stitched, and finished in our own registered workshop in Sialkot, Pakistan. Sialkot has been world-renowned for centuries as the epicenter of high-tensile leather tanning, precision equestrian saddlery, and master hand-craftsmanship.
                </p>
                <p>
                  We strictly never compromise on raw materials: only unadulterated Full-Grain vegetable-tanned hides are utilized. Unlike commercial fast-fashion leather that is ground into powder and bonded with polyurethane film, our full-grain leather retains the intact dermal fiber structure, which means it will never peel, crack, or flake.
                </p>

                <h4 className="font-cinzel text-sm font-bold text-[#1F1511] pt-2">
                  Key Design Features:
                </h4>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-1">
                  {product.features.map((feat, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Tab 2: Technical Specifications Table */}
            {activeTab === 'specs' && (
              <div className="max-w-3xl">
                <h3 className="font-cinzel text-lg font-bold text-[#1F1511] mb-4">
                  Material & Technical Specifications
                </h3>
                <div className="border border-[#ECE3D7] rounded-md overflow-hidden text-xs">
                  <table className="w-full text-left">
                    <tbody className="divide-y divide-[#ECE3D7]">
                      <tr className="bg-[#FAF7F2]">
                        <th className="py-2.5 px-4 font-bold text-[#1F1511] w-1/3">Leather Grade</th>
                        <td className="py-2.5 px-4">{product.leatherType}</td>
                      </tr>
                      <tr>
                        <th className="py-2.5 px-4 font-bold text-[#1F1511]">Tanning Process</th>
                        <td className="py-2.5 px-4">{product.tanning}</td>
                      </tr>
                      <tr className="bg-[#FAF7F2]">
                        <th className="py-2.5 px-4 font-bold text-[#1F1511]">Stitching Method</th>
                        <td className="py-2.5 px-4">{product.stitching}</td>
                      </tr>
                      {product.hardware && (
                        <tr>
                          <th className="py-2.5 px-4 font-bold text-[#1F1511]">Hardware & Zippers</th>
                          <td className="py-2.5 px-4">{product.hardware}</td>
                        </tr>
                      )}
                      {product.dimensions && (
                        <tr className="bg-[#FAF7F2]">
                          <th className="py-2.5 px-4 font-bold text-[#1F1511]">Dimensions</th>
                          <td className="py-2.5 px-4">{product.dimensions}</td>
                        </tr>
                      )}
                      <tr>
                        <th className="py-2.5 px-4 font-bold text-[#1F1511]">Origin & Production</th>
                        <td className="py-2.5 px-4">Handcrafted in Sialkot, Punjab, Pakistan</td>
                      </tr>
                      <tr className="bg-[#FAF7F2]">
                        <th className="py-2.5 px-4 font-bold text-[#1F1511]">Lead Time</th>
                        <td className="py-2.5 px-4">{product.leadTime}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Tab 3: Size Guide */}
            {activeTab === 'sizing' && (
              <div className="max-w-3xl space-y-4">
                <h3 className="font-cinzel text-lg font-bold text-[#1F1511]">
                  Size Guide & Measurement Chart
                </h3>
                {product.category === 'jackets' ? (
                  <div>
                    <p className="text-xs text-[#6B6865] mb-3">
                      All jackets are crafted according to international standard tailoring measurements. For custom made-to-measure sizing, simply provide your measurements during checkout or over WhatsApp.
                    </p>
                    <div className="border border-[#ECE3D7] rounded-md overflow-x-auto text-xs">
                      <table className="w-full text-left">
                        <thead className="bg-[#1F1511] text-white">
                          <tr>
                            <th className="py-2 px-3">Size</th>
                            <th className="py-2 px-3">Chest (Inches)</th>
                            <th className="py-2 px-3">Shoulder (Inches)</th>
                            <th className="py-2 px-3">Sleeve (Inches)</th>
                            <th className="py-2 px-3">Length (Inches)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#ECE3D7]">
                          <tr><td className="py-2 px-3 font-bold">Small (S)</td><td>38 - 40&quot;</td><td>17.5&quot;</td><td>25.5&quot;</td><td>25.0&quot;</td></tr>
                          <tr className="bg-[#FAF7F2]"><td className="py-2 px-3 font-bold">Medium (M)</td><td>40 - 42&quot;</td><td>18.0&quot;</td><td>26.0&quot;</td><td>25.5&quot;</td></tr>
                          <tr><td className="py-2 px-3 font-bold">Large (L)</td><td>42 - 44&quot;</td><td>18.5&quot;</td><td>26.5&quot;</td><td>26.0&quot;</td></tr>
                          <tr className="bg-[#FAF7F2]"><td className="py-2 px-3 font-bold">Extra Large (XL)</td><td>44 - 46&quot;</td><td>19.0&quot;</td><td>27.0&quot;</td><td>26.5&quot;</td></tr>
                          <tr><td className="py-2 px-3 font-bold">2XL</td><td>46 - 48&quot;</td><td>19.5&quot;</td><td>27.5&quot;</td><td>27.0&quot;</td></tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : product.category === 'belts' ? (
                  <div>
                    <p className="text-xs text-[#6B6865] mb-3">
                      Order one size larger than your denim trouser waist size (e.g. if you wear size 34 pants, select a 36 belt).
                    </p>
                    <div className="border border-[#ECE3D7] rounded-md overflow-x-auto text-xs">
                      <table className="w-full text-left">
                        <thead className="bg-[#1F1511] text-white">
                          <tr>
                            <th className="py-2 px-3">Belt Size</th>
                            <th className="py-2 px-3">Pant Waist</th>
                            <th className="py-2 px-3">Center Hole Length</th>
                            <th className="py-2 px-3">Total Strap Length</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#ECE3D7]">
                          <tr><td className="py-2 px-3 font-bold">32</td><td>30 - 31&quot;</td><td>32&quot; (81 cm)</td><td>38&quot;</td></tr>
                          <tr className="bg-[#FAF7F2]"><td className="py-2 px-3 font-bold">34</td><td>32 - 33&quot;</td><td>34&quot; (86 cm)</td><td>40&quot;</td></tr>
                          <tr><td className="py-2 px-3 font-bold">36</td><td>34 - 35&quot;</td><td>36&quot; (91 cm)</td><td>42&quot;</td></tr>
                          <tr className="bg-[#FAF7F2]"><td className="py-2 px-3 font-bold">38</td><td>36 - 37&quot;</td><td>38&quot; (96 cm)</td><td>44&quot;</td></tr>
                          <tr><td className="py-2 px-3 font-bold">40</td><td>38 - 39&quot;</td><td>40&quot; (101 cm)</td><td>46&quot;</td></tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-[#6B6865]">
                    This product is built to standardized dimensions ({product.dimensions || 'Universal Compact Profile'}).
                  </p>
                )}
              </div>
            )}

            {/* Tab 4: Shipping & Returns */}
            {activeTab === 'shipping' && (
              <div className="max-w-3xl space-y-3">
                <h3 className="font-cinzel text-lg font-bold text-[#1F1511]">
                  Global Express Shipping & Guarantee
                </h3>
                <p>
                  <strong>Worldwide Courier Partners:</strong> We ship all global packages via DHL Express, FedEx, and SkyNet Worldwide. Every parcel comes with complete door-to-door tracking numbers sent via WhatsApp and email.
                </p>
                <p>
                  <strong>Delivery Timelines:</strong>
                  <br />• United States & Canada: 3 to 5 business days
                  <br />• United Kingdom & Europe: 3 to 5 business days
                  <br />• United Arab Emirates & Gulf: 2 to 4 business days
                  <br />• Australia & Rest of World: 4 to 6 business days
                </p>
                <p>
                  <strong>Return & Exchange Policy:</strong> If you are not 100% satisfied with the grain, fit, or craftsmanship of your item, contact our artisan support within 30 days of delivery for a replacement or return.
                </p>
              </div>
            )}

            {/* Tab 5: Customer Reviews */}
            {activeTab === 'reviews' && (
              <div className="max-w-4xl space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#ECE3D7]">
                  <h3 className="font-cinzel text-lg font-bold text-[#1F1511]">
                    Patron Reviews & Feedback
                  </h3>
                  {product.reviewsCount && product.reviewsCount > 0 && product.rating ? (
                    <div className="text-xs text-[#8E5431] font-semibold">
                      Verified Rating: {product.rating} / 5.0
                    </div>
                  ) : null}
                </div>

                {product.reviews && product.reviews.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {product.reviews.map((rev) => (
                      <div key={rev.id} className="p-4 rounded-md border border-[#ECE3D7] bg-[#FAF7F2] space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs text-[#1F1511]">{rev.author}</span>
                          <div className="flex text-[#D4AF37]">
                            {[...Array(rev.rating)].map((_, idx) => (
                              <Star key={idx} className="w-3 h-3 fill-[#D4AF37] text-[#D4AF37]" />
                            ))}
                          </div>
                        </div>
                        <p className="text-[11px] text-[#6B6865]">
                          {rev.location ? `${rev.location} • ` : ''}{rev.date}
                        </p>
                        <p className="text-xs text-[#333] italic">&ldquo;{rev.comment}&rdquo;</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 px-6 bg-[#FAF7F2] rounded-lg border border-[#ECE3D7]">
                    <Star className="w-8 h-8 text-[#D4AF37]/50 mx-auto mb-3" />
                    <h4 className="font-cinzel text-lg font-bold text-[#1F1511] mb-2">
                      Be the first to review this product
                    </h4>
                    <p className="text-xs text-[#6B6865] max-w-md mx-auto mb-6">
                      Have you acquired this handcrafted leather piece from our workshop? Share your genuine craftsmanship experience with fellow patrons.
                    </p>
                    <a
                      href={`https://wa.me/${BUSINESS_PHONE_RAW}?text=${encodeURIComponent(
                        `Hello SIALVANTGLOBAL INDUSTRIES, I would like to submit my patron review for ${product.name}.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 bg-[#1F1511] hover:bg-[#8E5431] text-white px-5 py-2.5 rounded-xs text-xs font-semibold uppercase tracking-wider transition"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>Submit Patron Review</span>
                    </a>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* RELATED CREATIONS SECTION */}
        {relatedProducts.length > 0 && (
          <div className="mb-14">
            <div className="text-center mb-8">
              <span className="text-[11px] font-bold text-[#8E5431] uppercase tracking-[0.25em]">
                From The Same Leather Atelier
              </span>
              <h2 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#1F1511] mt-1">
                Related Creations
              </h2>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
              {relatedProducts.map((rel) => (
                <div
                  key={rel.id}
                  onClick={() => onSelectProduct(rel)}
                  className="bg-white rounded-lg border border-[#ECE3D7] overflow-hidden hover:shadow-lg transition cursor-pointer group flex flex-col justify-between"
                >
                  <div className="aspect-square overflow-hidden bg-[#F9F6F0]">
                    <img
                      src={rel.image}
                      alt={rel.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                  </div>
                  <div className="p-3 text-center">
                    <h4 className="font-cinzel text-xs sm:text-sm font-bold text-[#1F1511] group-hover:text-[#8E5431] transition truncate">
                      {rel.name}
                    </h4>
                    <p className="text-[10px] text-[#8E5431] italic truncate">{rel.leatherType}</p>
                    <p className="text-xs sm:text-sm font-bold text-[#1F1511] mt-1">
                      {currencyConfig.format(rel.priceUSD)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* RECENTLY VIEWED PRODUCTS */}
        {recentlyViewed.length > 0 && (
          <div className="border-t border-[#ECE3D7] pt-10">
            <div className="text-center mb-6">
              <span className="text-[11px] font-bold text-[#6B6865] uppercase tracking-[0.2em]">
                Your Browsing History
              </span>
              <h3 className="font-cinzel text-xl font-bold text-[#1F1511] mt-1">
                Recently Viewed Items
              </h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-4">
              {recentlyViewed.map((rec) => (
                <div
                  key={rec.id}
                  onClick={() => onSelectProduct(rec)}
                  className="bg-white rounded-md border border-[#ECE3D7] p-2.5 hover:shadow-md transition cursor-pointer text-center group"
                >
                  <div className="aspect-square overflow-hidden rounded-xs bg-[#F9F6F0] mb-2">
                    <img src={rec.image} alt={rec.name} className="w-full h-full object-cover group-hover:scale-105 transition" />
                  </div>
                  <h5 className="font-cinzel text-xs font-bold text-[#1F1511] truncate group-hover:text-[#8E5431]">
                    {rec.name}
                  </h5>
                  <p className="text-xs text-[#8E5431] font-semibold mt-0.5">
                    {currencyConfig.format(rec.priceUSD)}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
