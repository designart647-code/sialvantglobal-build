import React, { useState } from 'react';
import { X, Star, ShieldCheck, Check, MessageCircle, ShoppingBag, Truck, Sparkles, Zap, ExternalLink } from 'lucide-react';
import { CurrencyCode, LanguageCode, Product } from '../types';
import { CURRENCY_CONFIGS } from '../data/products';
import { TRANSLATIONS } from '../data/translations';
import { createProductWhatsAppUrl, BUSINESS_PHONE_DISPLAY } from '../utils/whatsapp';

interface Props {
  product: Product | null;
  currentCurrency: CurrencyCode;
  currentLanguage?: LanguageCode;
  onClose: () => void;
  onAddToCart: (product: Product, selectedColor: string, monogram?: string, size?: string) => void;
  onBuyItNow?: (product: Product, selectedColor: string, monogram?: string, size?: string) => void;
  onOpenDetailPage?: (product: Product) => void;
}

export const ProductModal: React.FC<Props> = ({
  product,
  currentCurrency,
  currentLanguage = 'en',
  onClose,
  onAddToCart,
  onBuyItNow,
  onOpenDetailPage,
}) => {
  if (!product) return null;

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>(() => {
    if (product.sizes && product.sizes.length > 0) return product.sizes[0];
    if (product.category === 'jackets') return 'L';
    if (product.category === 'belts') return '36';
    return 'Standard';
  });
  const [monogram, setMonogram] = useState('');
  const [added, setAdded] = useState(false);

  const activeColor = product.colors[selectedColorIndex] || product.colors[0];
  const colorImage = activeColor?.image;
  const baseImages = product.galleryImages && product.galleryImages.length > 0
    ? product.galleryImages
    : [product.image];
  const images = colorImage && !baseImages.includes(colorImage)
    ? [colorImage, ...baseImages]
    : colorImage
    ? [colorImage, ...baseImages.filter((img) => img !== colorImage)]
    : baseImages;
  const activeImage = images[activeImageIndex] || colorImage || product.image;

  const defaultSizes = product.sizes || (
    product.category === 'jackets'
      ? ['S', 'M', 'L', 'XL', '2XL', 'Custom Tailored']
      : product.category === 'belts'
      ? ['32', '34', '36', '38', '40', '42']
      : ['Standard']
  );

  const currencyConfig = CURRENCY_CONFIGS[currentCurrency] || CURRENCY_CONFIGS.USD;
  const formattedPrice = currencyConfig.format(product.priceUSD);
  const formattedOriginal = product.originalPriceUSD
    ? currencyConfig.format(product.originalPriceUSD)
    : null;

  const handleAdd = () => {
    onAddToCart(product, activeColor.name, monogram.trim() || undefined, selectedSize);
    setAdded(true);
    setTimeout(() => {
      setAdded(false);
      onClose();
    }, 1000);
  };

  const handleBuy = () => {
    if (onBuyItNow) {
      onBuyItNow(product, activeColor.name, monogram.trim() || undefined, selectedSize);
    } else {
      handleAdd();
    }
    onClose();
  };

  const handleViewFull = () => {
    if (onOpenDetailPage) {
      onOpenDetailPage(product);
      onClose();
    }
  };

  const whatsappUrl = createProductWhatsAppUrl(
    product,
    activeColor.name,
    monogram.trim() || undefined,
    currentCurrency,
    formattedPrice,
    defaultSizes.length > 1 ? selectedSize : undefined
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-4xl bg-white rounded-lg shadow-2xl border border-[#ECE3D7] overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-gray-700 hover:text-black flex items-center justify-center shadow-md border border-[#ECE3D7] transition cursor-pointer"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Left Column: Image Gallery */}
          <div className="bg-[#170F0A] p-4 sm:p-6 flex flex-col justify-between">
            <div className="relative aspect-square w-full rounded-md overflow-hidden bg-black/40 flex items-center justify-center">
              <img
                src={activeImage}
                alt={product.name}
                className="w-full h-full object-cover transition-all duration-300"
              />
              {product.tag && (
                <span className="absolute top-3 left-3 bg-[#D4AF37] text-[#1F1511] text-[10px] font-bold tracking-widest px-2.5 py-1 rounded-xs uppercase shadow-xs">
                  {product.tag}
                </span>
              )}
            </div>

            {/* Gallery Thumbnails */}
            {images.length > 1 && (
              <div className="flex gap-2.5 mt-4 overflow-x-auto pb-1 scrollbar-none">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-16 h-16 rounded-xs overflow-hidden shrink-0 border-2 transition cursor-pointer ${
                      activeImageIndex === idx
                        ? 'border-[#D4AF37] scale-105'
                        : 'border-white/20 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Authenticity Guarantee Note & Link to Full Page */}
            <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-white/80 text-xs">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Pure Full-Grain Sialkot Atelier</span>
              </div>
              {onOpenDetailPage && (
                <button
                  onClick={handleViewFull}
                  className="text-[#D4AF37] hover:underline flex items-center gap-1 cursor-pointer font-semibold text-[11px]"
                >
                  <span>Full Page</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>

          {/* Right Column: Details & Customization */}
          <div className="p-6 sm:p-8 flex flex-col justify-between max-h-[85vh] overflow-y-auto">
            <div>
              {/* Category & Rating */}
              <div className="flex items-center justify-between text-xs text-[#6B6865] mb-1.5">
                <span className="uppercase tracking-widest font-semibold text-[#8E5431]">
                  {product.category}
                </span>
                {product.reviewsCount && product.reviewsCount > 0 && product.rating ? (
                  <div className="flex items-center gap-1 text-[#D4AF37]">
                    <Star className="w-4 h-4 fill-[#D4AF37]" />
                    <span className="font-bold text-[#1F1511]">{product.rating}</span>
                    <span className="text-gray-400">({product.reviewsCount} review{product.reviewsCount > 1 ? 's' : ''})</span>
                  </div>
                ) : (
                  <span className="text-[11px] text-[#8E5431] font-semibold bg-[#FAF7F2] px-2.5 py-0.5 rounded-full border border-[#ECE3D7]">
                    Artisan Workshop Release
                  </span>
                )}
              </div>

              {/* Title */}
              <h2 className="font-cinzel text-2xl font-bold text-[#1F1511] mb-2 leading-tight">
                {product.name}
              </h2>

              {/* Pricing */}
              <div className="flex items-baseline gap-3 mb-4">
                <span className="text-2xl font-bold text-[#8E5431]">
                  {formattedPrice}
                </span>
                {formattedOriginal && (
                  <span className="text-sm text-gray-400 line-through">
                    {formattedOriginal}
                  </span>
                )}
                <span className="text-[11px] bg-[#FAF7F2] text-[#8E5431] border border-[#ECE3D7] font-semibold px-2.5 py-0.5 rounded-full">
                  In Stock & Ready
                </span>
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-[#555555] leading-relaxed mb-5">
                {product.description}
              </p>

              {/* Specifications Box */}
              <div className="bg-[#F9F6F0] rounded-md p-3.5 border border-[#ECE3D7] mb-5 text-xs space-y-1.5">
                <div className="flex justify-between py-0.5 border-b border-[#ECE3D7]/60">
                  <span className="text-[#6B6865]">Leather Type:</span>
                  <span className="font-semibold text-[#1F1511]">{product.leatherType}</span>
                </div>
                <div className="flex justify-between py-0.5 border-b border-[#ECE3D7]/60">
                  <span className="text-[#6B6865]">Tanning:</span>
                  <span className="font-semibold text-[#1F1511]">{product.tanning}</span>
                </div>
                <div className="flex justify-between py-0.5 border-b border-[#ECE3D7]/60">
                  <span className="text-[#6B6865]">Stitching:</span>
                  <span className="font-semibold text-[#1F1511]">{product.stitching}</span>
                </div>
                {product.dimensions && (
                  <div className="flex justify-between py-0.5">
                    <span className="text-[#6B6865]">Dimensions:</span>
                    <span className="font-semibold text-[#1F1511]">{product.dimensions}</span>
                  </div>
                )}
              </div>

              {/* Color Selection with 14 Round Selectors */}
              <div className="mb-5 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-[#1F1511] uppercase tracking-wider">
                    Leather Color: <span className="text-[#991B1B] font-extrabold">{activeColor.name}</span>
                  </span>
                  <span className="text-[11px] text-[#6B6865]">{product.colors.length} shades available</span>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {product.colors.map((color, idx) => (
                    <button
                      key={color.name}
                      type="button"
                      onClick={() => {
                        setSelectedColorIndex(idx);
                        setActiveImageIndex(0);
                      }}
                      className={`relative w-7 h-7 sm:w-8 sm:h-8 rounded-full border-2 transition-all cursor-pointer flex items-center justify-center ${
                        selectedColorIndex === idx
                          ? 'border-[#991B1B] ring-2 ring-[#991B1B] scale-110 shadow-md z-10'
                          : 'border-black/20 hover:scale-105 opacity-85 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: color.hex }}
                      title={color.name}
                      aria-label={`Select ${color.name}`}
                    >
                      {selectedColorIndex === idx && (
                        <span
                          className={`w-2 h-2 rounded-full ${
                            color.hex === '#F8FAFC' || color.hex === '#FFFFFF'
                              ? 'bg-black'
                              : 'bg-white'
                          }`}
                        />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selector (If applicable) */}
              {defaultSizes.length > 1 && (
                <div className="mb-5 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-[#1F1511] uppercase tracking-wider">
                      Select Size: <span className="text-[#8E5431] font-semibold">{selectedSize}</span>
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {defaultSizes.map((size) => (
                      <button
                        key={size}
                        type="button"
                        onClick={() => setSelectedSize(size)}
                        className={`px-3 py-1.5 rounded-xs text-xs font-semibold border transition cursor-pointer ${
                          selectedSize === size
                            ? 'border-[#8E5431] bg-[#8E5431] text-white shadow-xs'
                            : 'border-[#ECE3D7] bg-white text-[#1F1511] hover:border-gray-400'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Bespoke Personalization / Monogram Box */}
              <div className="mb-6 p-3 rounded-md border border-[#D4AF37]/40 bg-[#FFFDF9]">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#1F1511] uppercase tracking-wide">
                    <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Free Foil/Blind Monogram (Optional)</span>
                  </div>
                  <span className="text-[10px] text-[#8E5431] font-medium">Up to 4 Letters</span>
                </div>
                <input
                  type="text"
                  maxLength={4}
                  value={monogram}
                  onChange={(e) => setMonogram(e.target.value.toUpperCase())}
                  placeholder="e.g. SBS or MHA"
                  className="w-full px-3 py-2 text-xs font-mono tracking-widest uppercase border border-[#ECE3D7] rounded-sm bg-white focus:outline-none focus:ring-1 focus:ring-[#8E5431]"
                />
              </div>
            </div>

            {/* THREE MANDATORY PURCHASE BUTTONS (RED & BLACK LUXURY THEME) */}
            <div className="space-y-2 pt-4 border-t border-[#ECE3D7]">
              {/* Option 1: WhatsApp Order (Green, No Visible Phone Number) */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 bg-[#15803D] hover:bg-[#166534] active:bg-[#14532D] text-white py-3 rounded-xs font-bold text-xs uppercase tracking-wider shadow-md transition-all duration-200 transform hover:scale-[1.01] border border-[#166534]"
                title="WhatsApp Order"
              >
                <MessageCircle className="w-4 h-4 text-white fill-white shrink-0" />
                <span className="text-white">WhatsApp Order</span>
              </a>

              {/* 2 & 3: Add to Cart and Buy It Now side-by-side */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleAdd}
                  className={`py-2.5 rounded-xs font-semibold text-xs uppercase tracking-wider border transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer border-2 ${
                    added
                      ? 'bg-[#1F1511] text-white border-[#1F1511]'
                      : 'bg-white hover:bg-[#1F1511] text-[#1F1511] hover:text-white border-[#1F1511]'
                  }`}
                >
                  {added ? (
                    <>
                      <Check className="w-4 h-4 text-white" /> Added!
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4 text-current" /> 2. Add to Cart
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleBuy}
                  className="py-2.5 bg-[#120B08] hover:bg-[#991B1B] active:bg-[#7F1D1D] text-white rounded-xs font-semibold text-xs uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-1.5 shadow-md cursor-pointer border border-[#120B08] hover:border-[#991B1B]"
                >
                  <Zap className="w-4 h-4 text-white fill-white" />
                  <span>3. Buy It Now</span>
                </button>
              </div>

              <div className="flex items-center justify-center gap-4 text-[11px] text-[#6B6865] pt-1">
                <span className="flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-[#8E5431]" />
                  DHL Express Worldwide
                </span>
                <span>&bull;</span>
                <span>Door-to-Door Tracking</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
