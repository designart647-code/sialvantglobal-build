import React from 'react';
import { Star, ShieldCheck, CheckCircle2, MessageSquareQuote } from 'lucide-react';
import { TESTIMONIALS } from '../data/products';

export const ReviewsSection: React.FC = () => {
  return (
    <section className="py-20 bg-[#F9F6F0] border-t border-[#ECE3D7]" id="reviews">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-widest font-bold text-[#8E5431]">
            Artisan Reputation
          </span>
          <h2 className="font-cinzel text-3xl sm:text-4xl font-bold text-[#1F1511] mt-1">
            Voices of Our Patrons
          </h2>
          <p className="text-xs sm:text-sm text-[#6B6865] mt-2">
            Read authentic experiences from leather connoisseurs across Pakistan and worldwide export destinations.
          </p>

          {/* Aggregate Rating Pill */}
          <div className="inline-flex items-center gap-2 mt-4 px-4 py-1.5 rounded-full bg-white border border-[#ECE3D7] shadow-xs text-xs">
            <div className="flex text-[#D4AF37]">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
              ))}
            </div>
            <span className="font-bold text-[#1F1511]">4.95 / 5.0</span>
            <span className="text-[#6B6865]">&bull; Genuine Workshop Patron Feedback</span>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {TESTIMONIALS.map((review, idx) => (
            <div
              key={idx}
              className="bg-white rounded-lg p-6 border border-[#ECE3D7] shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div>
                {/* Rating & Quote Icon */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex text-[#D4AF37]">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
                    ))}
                  </div>
                  <MessageSquareQuote className="w-5 h-5 text-[#8E5431]/20" />
                </div>

                {/* Review Text */}
                <p className="text-xs text-[#444] leading-relaxed mb-4 italic">
                  &ldquo;{review.comment}&rdquo;
                </p>
              </div>

              {/* Author & Item */}
              <div className="pt-3 border-t border-[#ECE3D7]">
                <div className="flex items-center gap-1 text-xs font-bold text-[#1F1511]">
                  <span>{review.name}</span>
                  {review.verified && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 fill-emerald-100" />
                  )}
                </div>
                <p className="text-[11px] text-[#6B6865]">{review.location}</p>
                <p className="text-[10px] text-[#8E5431] font-semibold mt-1 uppercase tracking-wide">
                  Purchased: {review.item}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
