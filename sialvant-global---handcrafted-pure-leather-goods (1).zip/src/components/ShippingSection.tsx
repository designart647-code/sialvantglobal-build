import React from 'react';
import { Plane, Truck, ShieldCheck, Package } from 'lucide-react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../data/translations';
import { getStoredWhatsAppNumber } from '../utils/whatsapp';

interface Props {
  currentLanguage?: LanguageCode;
}

export const ShippingSection: React.FC<Props> = ({ currentLanguage = 'en' }) => {
  const waNumber = getStoredWhatsAppNumber();
  const t = TRANSLATIONS[currentLanguage];

  return (
    <section className="py-20 sm:py-24 bg-[#120B08] text-white border-t border-[#2C1D15] relative overflow-hidden" id="worldwide-shipping">
      {/* Decorative ambient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[300px] bg-[#D4AF37]/5 blur-3xl pointer-events-none" />

      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-semibold uppercase tracking-widest mb-3">
            <Plane className="w-3.5 h-3.5" />
            <span>{t.shippingTag}</span>
          </div>

          <h2 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#FAF4EB]">
            {t.shippingTitle}
          </h2>

          <p className="text-xs sm:text-sm text-[#CBC2B7] mt-3 font-light leading-relaxed">
            {t.shippingSubtitle}
          </p>
          <div className="w-16 h-0.5 bg-[#D4AF37] mx-auto mt-4" />
        </div>

        {/* 3 Core Shipping Channels */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 mb-14">
          {/* Channel 1: DHL Express */}
          <div className="bg-[#1C1410] rounded-lg p-6 sm:p-8 border border-white/10 hover:border-[#D4AF37]/50 shadow-xl transition-all duration-300">
            <div className="w-12 h-12 rounded-full bg-yellow-500/10 text-yellow-400 flex items-center justify-center mb-5 border border-yellow-500/20">
              <Plane className="w-6 h-6" />
            </div>
            <span className="text-[10px] font-bold text-[#D4AF37] uppercase tracking-widest">
              Air Express &bull; 60+ Countries
            </span>
            <h3 className="font-cinzel text-xl font-bold text-white mt-1 mb-2">
              {t.shippingDhlTitle}
            </h3>
            <p className="text-xs text-[#A69788] leading-relaxed mb-4">
              {t.shippingDhlDesc}
            </p>
            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-[#CBC2B7]">
              <span>Transit Time: <strong>3-5 Days</strong></span>
              <span className="text-emerald-400 font-semibold">Live Tracking ID</span>
            </div>
          </div>

          {/* Channel 2: SkyNet Worldwide */}
          <div className="bg-[#1C1410] rounded-lg p-6 sm:p-8 border border-white/10 hover:border-[#D4AF37]/50 shadow-xl transition-all duration-300">
            <div className="w-12 h-12 rounded-full bg-sky-500/10 text-sky-400 flex items-center justify-center mb-5 border border-sky-500/20">
              <Truck className="w-6 h-6" />
            </div>
            <span className="text-[10px] font-bold text-[#D4AF37] uppercase tracking-widest">
              Wholesale & Cargo
            </span>
            <h3 className="font-cinzel text-xl font-bold text-white mt-1 mb-2">
              {t.shippingSkyNetTitle}
            </h3>
            <p className="text-xs text-[#A69788] leading-relaxed mb-4">
              {t.shippingSkyNetDesc}
            </p>
            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-[#CBC2B7]">
              <span>Transit Time: <strong>5-7 Days</strong></span>
              <span className="text-sky-400 font-semibold">Bulk Air Cargo</span>
            </div>
          </div>

          {/* Channel 3: Insured Priority Courier */}
          <div className="bg-[#1C1410] rounded-lg p-6 sm:p-8 border border-white/10 hover:border-[#D4AF37]/50 shadow-xl transition-all duration-300">
            <div className="w-12 h-12 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-5 border border-emerald-500/20">
              <Package className="w-6 h-6" />
            </div>
            <span className="text-[10px] font-bold text-[#D4AF37] uppercase tracking-widest">
              Insured & Tracked
            </span>
            <h3 className="font-cinzel text-xl font-bold text-white mt-1 mb-2">
              {t.shippingPriorityTitle}
            </h3>
            <p className="text-xs text-[#A69788] leading-relaxed mb-4">
              {t.shippingPriorityDesc}
            </p>
            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-[#CBC2B7]">
              <span>Transit Time: <strong>3-5 Days</strong></span>
              <span className="text-emerald-400 font-semibold">Signature On Delivery</span>
            </div>
          </div>
        </div>

        {/* Heirloom Gift Packaging Included Box */}
        <div className="bg-[#1C1410] rounded-lg p-5 sm:p-7 lg:p-8 border border-[#D4AF37]/35 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-5 sm:gap-6">
          <div className="flex items-start sm:items-center gap-4 text-left max-w-2xl">
            <div className="w-12 h-12 rounded-full bg-[#D4AF37]/15 text-[#D4AF37] flex items-center justify-center shrink-0 border border-[#D4AF37]/30 mt-0.5 sm:mt-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-cinzel text-base sm:text-lg font-bold text-white tracking-wide">
                {t.shippingPackagingTitle}
              </h4>
              <p className="text-xs sm:text-[13px] text-[#CBC2B7] mt-1 leading-relaxed">
                {t.shippingPackagingDesc}
              </p>
            </div>
          </div>

          <div className="w-full md:w-auto shrink-0 flex justify-start md:justify-end">
            <a
              href={`https://wa.me/${waNumber}?text=${encodeURIComponent(
                'Hello SIALVANTGLOBAL INDUSTRIES, I would like to track my order / inquire about shipping details.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full md:w-auto inline-flex items-center justify-center gap-2 bg-[#D4AF37] hover:bg-white text-[#120B08] px-5 sm:px-6 py-3 rounded-xs font-bold text-xs uppercase tracking-wider transition-all duration-300 shadow-md hover:shadow-lg cursor-pointer text-center whitespace-nowrap"
              title="Track or Inquire Shipping via WhatsApp"
            >
              <span>Track / Inquire Shipping on WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

