import React, { useState } from 'react';
import { Phone, Check, X, ShieldAlert, Sparkles } from 'lucide-react';
import { getStoredWhatsAppNumber, saveWhatsAppNumber } from '../utils/whatsapp';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onNumberChanged: (newNumber: string) => void;
}

export const WhatsAppConfigModal: React.FC<Props> = ({ isOpen, onClose, onNumberChanged }) => {
  const [number, setNumber] = useState<string>(() => getStoredWhatsAppNumber());
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = number.replace(/[^0-9]/g, '');
    if (!clean) return;
    saveWhatsAppNumber(clean);
    onNumberChanged(clean);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-lg shadow-2xl border border-[#ECE3D7] p-6 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#ECE3D7]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#25D366]/10 text-[#25D366] flex items-center justify-center">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-cinzel text-lg font-bold text-[#1F1511]">Store WhatsApp Setup</h3>
              <p className="text-xs text-[#6B6865]">Configure direct order dispatch number</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-100 transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="mt-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#1F1511] uppercase tracking-wider mb-1.5">
              WhatsApp Business Phone (with Country Code)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-gray-500">
                +
              </span>
              <input
                type="text"
                value={number}
                onChange={(e) => setNumber(e.target.value)}
                placeholder="e.g. 923297134614"
                className="w-full pl-8 pr-4 py-2.5 rounded-md border border-[#ECE3D7] focus:outline-none focus:ring-2 focus:ring-[#8E5431] text-sm text-[#1F1511] font-mono"
                required
              />
            </div>
            <p className="text-xs text-[#6B6865] mt-1.5 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              Enter country code without (+) or spaces. Example: <code>923297134614</code> for Pakistan.
            </p>
          </div>

          <div className="bg-[#F9F6F0] p-3.5 rounded-md border border-[#ECE3D7] text-xs text-[#6B6865] space-y-1">
            <div className="flex items-center gap-1.5 font-medium text-[#1F1511]">
              <ShieldAlert className="w-3.5 h-3.5 text-[#8E5431]" />
              Direct Customer Ordering:
            </div>
            <p>
              When clients click &quot;Order on WhatsApp&quot; or checkout their cart, their prepared order bill will immediately open in WhatsApp addressed to this number.
            </p>
          </div>

          {savedSuccess && (
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs font-medium flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              WhatsApp number updated successfully!
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-gray-600 hover:text-gray-900 border border-gray-200 rounded-md hover:bg-gray-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#1F1511] hover:bg-[#8E5431] rounded-md transition shadow-xs"
            >
              Save Number
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
