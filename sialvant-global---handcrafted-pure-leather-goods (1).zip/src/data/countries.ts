import { CountryConfig } from '../types';

export const WORLD_COUNTRIES: CountryConfig[] = [
  // NORTH AMERICA
  { code: 'US', name: 'United States', currency: 'USD', flag: '🇺🇸', region: 'North America' },
  { code: 'CA', name: 'Canada', currency: 'CAD', flag: '🇨🇦', region: 'North America' },
  { code: 'MX', name: 'Mexico', currency: 'MXN', flag: '🇲🇽', region: 'North America' },

  // EUROPE
  { code: 'GB', name: 'United Kingdom', currency: 'GBP', flag: '🇬🇧', region: 'Europe' },
  { code: 'DE', name: 'Germany', currency: 'EUR', flag: '🇩🇪', region: 'Europe' },
  { code: 'FR', name: 'France', currency: 'EUR', flag: '🇫🇷', region: 'Europe' },
  { code: 'IT', name: 'Italy', currency: 'EUR', flag: '🇮🇹', region: 'Europe' },
  { code: 'ES', name: 'Spain', currency: 'EUR', flag: '🇪🇸', region: 'Europe' },
  { code: 'NL', name: 'Netherlands', currency: 'EUR', flag: '🇳🇱', region: 'Europe' },
  { code: 'CH', name: 'Switzerland', currency: 'CHF', flag: '🇨🇭', region: 'Europe' },
  { code: 'SE', name: 'Sweden', currency: 'SEK', flag: '🇸🇪', region: 'Europe' },
  { code: 'NO', name: 'Norway', currency: 'NOK', flag: '🇳🇴', region: 'Europe' },
  { code: 'DK', name: 'Denmark', currency: 'DKK', flag: '🇩🇰', region: 'Europe' },
  { code: 'FI', name: 'Finland', currency: 'EUR', flag: '🇫🇮', region: 'Europe' },
  { code: 'BE', name: 'Belgium', currency: 'EUR', flag: '🇧🇪', region: 'Europe' },
  { code: 'AT', name: 'Austria', currency: 'EUR', flag: '🇦🇹', region: 'Europe' },
  { code: 'IE', name: 'Ireland', currency: 'EUR', flag: '🇮🇪', region: 'Europe' },
  { code: 'PT', name: 'Portugal', currency: 'EUR', flag: '🇵🇹', region: 'Europe' },
  { code: 'PL', name: 'Poland', currency: 'PLN', flag: '🇵🇱', region: 'Europe' },
  { code: 'TR', name: 'Turkey', currency: 'TRY', flag: '🇹🇷', region: 'Europe' },
  { code: 'GR', name: 'Greece', currency: 'EUR', flag: '🇬🇷', region: 'Europe' },
  { code: 'CZ', name: 'Czech Republic', currency: 'CZK', flag: '🇨🇿', region: 'Europe' },
  { code: 'RO', name: 'Romania', currency: 'RON', flag: '🇷🇴', region: 'Europe' },
  { code: 'HU', name: 'Hungary', currency: 'HUF', flag: '🇭🇺', region: 'Europe' },

  // MIDDLE EAST
  { code: 'AE', name: 'United Arab Emirates', currency: 'AED', flag: '🇦🇪', region: 'Middle East' },
  { code: 'SA', name: 'Saudi Arabia', currency: 'SAR', flag: '🇸🇦', region: 'Middle East' },
  { code: 'QA', name: 'Qatar', currency: 'QAR', flag: '🇶🇦', region: 'Middle East' },
  { code: 'KW', name: 'Kuwait', currency: 'KWD', flag: '🇰🇼', region: 'Middle East' },
  { code: 'OM', name: 'Oman', currency: 'OMR', flag: '🇴🇲', region: 'Middle East' },
  { code: 'BH', name: 'Bahrain', currency: 'BHD', flag: '🇧🇭', region: 'Middle East' },
  { code: 'IL', name: 'Israel', currency: 'ILS', flag: '🇮🇱', region: 'Middle East' },
  { code: 'EG', name: 'Egypt', currency: 'EGP', flag: '🇪🇬', region: 'Middle East' },

  // ASIA PACIFIC
  { code: 'PK', name: 'Pakistan', currency: 'USD', flag: '🇵🇰', region: 'Asia Pacific' },
  { code: 'JP', name: 'Japan', currency: 'JPY', flag: '🇯🇵', region: 'Asia Pacific' },
  { code: 'CN', name: 'China', currency: 'CNY', flag: '🇨🇳', region: 'Asia Pacific' },
  { code: 'SG', name: 'Singapore', currency: 'SGD', flag: '🇸🇬', region: 'Asia Pacific' },
  { code: 'HK', name: 'Hong Kong', currency: 'HKD', flag: '🇭🇰', region: 'Asia Pacific' },
  { code: 'IN', name: 'India', currency: 'INR', flag: '🇮🇳', region: 'Asia Pacific' },
  { code: 'KR', name: 'South Korea', currency: 'KRW', flag: '🇰🇷', region: 'Asia Pacific' },
  { code: 'MY', name: 'Malaysia', currency: 'MYR', flag: '🇲🇾', region: 'Asia Pacific' },
  { code: 'ID', name: 'Indonesia', currency: 'IDR', flag: '🇮🇩', region: 'Asia Pacific' },
  { code: 'TH', name: 'Thailand', currency: 'THB', flag: '🇹🇭', region: 'Asia Pacific' },
  { code: 'PH', name: 'Philippines', currency: 'PHP', flag: '🇵🇭', region: 'Asia Pacific' },
  { code: 'VN', name: 'Vietnam', currency: 'VND', flag: '🇻🇳', region: 'Asia Pacific' },

  // OCEANIA
  { code: 'AU', name: 'Australia', currency: 'AUD', flag: '🇦🇺', region: 'Oceania' },
  { code: 'NZ', name: 'New Zealand', currency: 'NZD', flag: '🇳🇿', region: 'Oceania' },

  // LATIN AMERICA
  { code: 'BR', name: 'Brazil', currency: 'BRL', flag: '🇧🇷', region: 'Latin America' },
  { code: 'CL', name: 'Chile', currency: 'CLP', flag: '🇨🇱', region: 'Latin America' },
  { code: 'CO', name: 'Colombia', currency: 'COP', flag: '🇨🇴', region: 'Latin America' },
  { code: 'AR', name: 'Argentina', currency: 'ARS', flag: '🇦🇷', region: 'Latin America' },

  // AFRICA
  { code: 'ZA', name: 'South Africa', currency: 'ZAR', flag: '🇿🇦', region: 'Africa' },
  { code: 'NG', name: 'Nigeria', currency: 'NGN', flag: '🇳🇬', region: 'Africa' },
  { code: 'KE', name: 'Kenya', currency: 'KES', flag: '🇰🇪', region: 'Africa' },
];

/**
 * Automatically detects the visitor's country based on system timezone or browser locale.
 * Defaults to United States (USD) if no match is found.
 */
export function detectVisitorCountry(): CountryConfig {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    const tzMap: Record<string, string> = {
      'America/New_York': 'US',
      'America/Chicago': 'US',
      'America/Denver': 'US',
      'America/Los_Angeles': 'US',
      'America/Toronto': 'CA',
      'America/Vancouver': 'CA',
      'Europe/London': 'GB',
      'Europe/Berlin': 'DE',
      'Europe/Paris': 'FR',
      'Europe/Rome': 'IT',
      'Europe/Madrid': 'ES',
      'Europe/Amsterdam': 'NL',
      'Europe/Zurich': 'CH',
      'Europe/Stockholm': 'SE',
      'Europe/Oslo': 'NO',
      'Europe/Copenhagen': 'DK',
      'Europe/Helsinki': 'FI',
      'Europe/Brussels': 'BE',
      'Europe/Vienna': 'AT',
      'Europe/Dublin': 'IE',
      'Europe/Lisbon': 'PT',
      'Europe/Warsaw': 'PL',
      'Europe/Istanbul': 'TR',
      'Asia/Dubai': 'AE',
      'Asia/Riyadh': 'SA',
      'Asia/Qatar': 'QA',
      'Asia/Kuwait': 'KW',
      'Asia/Karachi': 'PK',
      'Asia/Tokyo': 'JP',
      'Asia/Shanghai': 'CN',
      'Asia/Singapore': 'SG',
      'Asia/Hong_Kong': 'HK',
      'Asia/Kolkata': 'IN',
      'Asia/Seoul': 'KR',
      'Asia/Kuala_Lumpur': 'MY',
      'Asia/Jakarta': 'ID',
      'Asia/Bangkok': 'TH',
      'Asia/Manila': 'PH',
      'Australia/Sydney': 'AU',
      'Australia/Melbourne': 'AU',
      'Pacific/Auckland': 'NZ',
    };

    for (const [key, code] of Object.entries(tzMap)) {
      if (tz.includes(key)) {
        const found = WORLD_COUNTRIES.find((c) => c.code === code);
        if (found) return found;
      }
    }
  } catch {
    // ignore
  }

  // Default to United States
  return WORLD_COUNTRIES[0];
}
