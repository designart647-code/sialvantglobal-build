export type LanguageCode =
  | 'en' // English
  | 'ar' // Arabic (العربية)
  | 'de' // German (Deutsch)
  | 'fr' // French (Français)
  | 'es' // Spanish (Español)
  | 'it' // Italian (Italiano)
  | 'pt' // Portuguese (Português)
  | 'nl' // Dutch (Nederlands)
  | 'pl' // Polish (Polski)
  | 'tr' // Turkish (Türkçe)
  | 'ru' // Russian (Русский)
  | 'zh' // Chinese (中文)
  | 'ja' // Japanese (日本語)
  | 'ko' // Korean (한국어)
  | 'hi' // Hindi (हिन्दी)
  | 'bn' // Bengali (বাংলা)
  | 'sv' // Swedish (Svenska)
  | 'da' // Danish (Dansk)
  | 'no' // Norwegian (Norsk)
  | 'fi' // Finnish (Suomi)
  | 'el' // Greek (Ελληνικά)
  | 'cs' // Czech (Čeština)
  | 'ro' // Romanian (Română)
  | 'hu' // Hungarian (Magyar)
  | 'th' // Thai (ไทย)
  | 'vi' // Vietnamese (Tiếng Việt)
  | 'id' // Indonesian (Bahasa Indonesia)
  | 'ms' // Malay (Bahasa Melayu)
  | 'he'; // Hebrew (עבריت)

export type CurrencyCode =
  | 'USD' // US Dollar ($)
  | 'GBP' // British Pound (£)
  | 'EUR' // Euro (€)
  | 'CAD' // Canadian Dollar (CA$)
  | 'AUD' // Australian Dollar (A$)
  | 'AED' // UAE Dirham (AED)
  | 'SAR' // Saudi Riyal (SAR)
  | 'QAR' // Qatari Riyal (QAR)
  | 'KWD' // Kuwaiti Dinar (KWD)
  | 'OMR' // Omani Rial (OMR)
  | 'BHD' // Bahraini Dinar (BHD)
  | 'JPY' // Japanese Yen (¥)
  | 'CNY' // Chinese Yuan (¥)
  | 'SGD' // Singapore Dollar (S$)
  | 'HKD' // Hong Kong Dollar (HK$)
  | 'NZD' // New Zealand Dollar (NZ$)
  | 'INR' // Indian Rupee (₹)
  | 'MYR' // Malaysian Ringgit (RM)
  | 'IDR' // Indonesian Rupiah (Rp)
  | 'PHP' // Philippine Peso (₱)
  | 'THB' // Thai Baht (฿)
  | 'VND' // Vietnamese Dong (₫)
  | 'KRW' // South Korean Won (₩)
  | 'BRL' // Brazilian Real (R$)
  | 'MXN' // Mexican Peso (Mex$)
  | 'ZAR' // South African Rand (R)
  | 'NOK' // Norwegian Krone (kr)
  | 'SEK' // Swedish Krona (kr)
  | 'DKK' // Danish Krone (kr)
  | 'PLN' // Polish Zloty (zł)
  | 'TRY' // Turkish Lira (₺)
  | 'CHF' // Swiss Franc (CHF)
  | 'CZK' // Czech Koruna (Kč)
  | 'RON' // Romanian Leu (lei)
  | 'HUF' // Hungarian Forint (Ft)
  | 'ILS' // Israeli Shekel (₪)
  | 'EGP' // Egyptian Pound (E£)
  | 'NGN' // Nigerian Naira (₦)
  | 'KES' // Kenyan Shilling (KSh)
  | 'CLP' // Chilean Peso (CLP$)
  | 'COP' // Colombian Peso (COL$)
  | 'ARS'; // Argentine Peso (ARS$)

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  name: string;
  rateAgainstUSD: number; // multiplier from USD
  format: (amountInUSD: number) => string;
}

export interface CountryConfig {
  code: string; // ISO 2-letter
  name: string;
  currency: CurrencyCode;
  flag: string; // Unicode flag emoji
  region: 'North America' | 'Europe' | 'Middle East' | 'Asia Pacific' | 'Latin America' | 'Africa' | 'Oceania';
}

export type ProductCategory = 'all' | 'wallets' | 'bags' | 'belts' | 'jackets' | 'accessories';

export interface ProductColor {
  name: string;
  hex: string;
  image?: string;
}

export interface ProductReview {
  id: string;
  author: string;
  location?: string;
  rating: number;
  date: string;
  comment: string;
}

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  priceUSD: number;
  originalPriceUSD?: number;
  tag?: string;
  image: string;
  galleryImages: string[];
  description: string;
  leatherType: string;
  tanning: string;
  stitching: string;
  hardware?: string;
  dimensions?: string;
  sizes?: string[];
  colors: ProductColor[];
  rating?: number;
  reviewsCount?: number;
  reviews?: ProductReview[];
  inStock: boolean;
  leadTime: string;
  features: string[];
  specifications?: Record<string, string>;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor: string;
  selectedSize?: string;
  monogramInitials?: string;
}

export interface CustomerOrderDetails {
  name: string;
  phone: string;
  city: string;
  address: string;
  country: string;
  notes: string;
  paymentPreference: 'card' | 'bank_transfer' | 'international' | 'whatsapp';
}
