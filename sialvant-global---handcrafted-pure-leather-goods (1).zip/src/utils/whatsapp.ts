import { CartItem, CustomerOrderDetails, Product, CurrencyCode } from '../types';
import { CURRENCY_CONFIGS } from '../data/products';

export const BUSINESS_PHONE_RAW = '923297134614';
export const BUSINESS_PHONE_DISPLAY = '+92 329 7134614';
export const BUSINESS_ADDRESS =
  'Dak Khana Khas Badiana, Tehsil Pasrur, District Sialkot 51410, Punjab, Pakistan.';
export const BUSINESS_EMAIL = 'info@sialvantglobalindustries.com';

export function getStoredWhatsAppNumber(): string {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('sialvant_whatsapp_number');
    if (saved && saved.trim() && saved.trim() !== '923000000000') {
      return saved.trim().replace(/[^0-9]/g, '');
    }
  }
  return BUSINESS_PHONE_RAW;
}

export function saveWhatsAppNumber(num: string): void {
  if (typeof window !== 'undefined') {
    const clean = num.replace(/[^0-9]/g, '');
    localStorage.setItem('sialvant_whatsapp_number', clean || BUSINESS_PHONE_RAW);
  }
}

export const GENERAL_WHATSAPP_MESSAGE =
  'Hello SIALVANTGLOBAL INDUSTRIES, I am interested in your leather products. Please share more details.';

export function getGeneralWhatsAppUrl(): string {
  const phone = getStoredWhatsAppNumber();
  return `https://wa.me/${phone}?text=${encodeURIComponent(GENERAL_WHATSAPP_MESSAGE)}`;
}

export function createProductWhatsAppUrl(
  product: Product,
  selectedColor?: string,
  monogram?: string,
  currencyCode: CurrencyCode = 'USD',
  formattedPrice = '',
  selectedSize?: string
): string {
  const phone = getStoredWhatsAppNumber();
  const colorText = selectedColor ? `\n• Selected Color: ${selectedColor}` : '';
  const sizeText = selectedSize ? `\n• Selected Size: ${selectedSize}` : '';
  const monogramText = monogram ? `\n• Custom Monogram Initials: [ ${monogram.toUpperCase()} ]` : '';
  const config = CURRENCY_CONFIGS[currencyCode] || CURRENCY_CONFIGS.USD;
  const priceDisplay = formattedPrice || config.format(product.priceUSD);
  const priceText = `\n• Listed Price: ${priceDisplay} (${currencyCode})`;
  
  // Direct product reference link
  const productLink = typeof window !== 'undefined'
    ? `${window.location.origin}/#product-${product.id}`
    : `https://sialvantglobalindustries.com/#product-${product.id}`;

  const message = `Hello SIALVANTGLOBAL INDUSTRIES, I am interested in your leather products. Please share more details.\n\n📦 *Product Inquiry:* ${product.name}${colorText}${sizeText}${monogramText}${priceText}\n• Category: ${product.category.toUpperCase()}\n• Leather Grade: ${product.leatherType}\n• Reference Link: ${productLink}`;

  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

export function createCartWhatsAppUrl(
  items: CartItem[],
  orderDetails: CustomerOrderDetails,
  totalAmountFormatted: string,
  shippingFormatted: string,
  currencyCode: CurrencyCode = 'USD'
): string {
  const phone = getStoredWhatsAppNumber();
  const config = CURRENCY_CONFIGS[currencyCode] || CURRENCY_CONFIGS.USD;

  let itemsBreakdown = '';
  items.forEach((item, index) => {
    const mono = item.monogramInitials ? ` [Monogram: ${item.monogramInitials.toUpperCase()}]` : '';
    const size = item.selectedSize ? ` [Size: ${item.selectedSize}]` : '';
    const itemSubtotal = config.format(item.product.priceUSD * item.quantity);
    itemsBreakdown += `${index + 1}. *${item.product.name}* (Qty: ${item.quantity})\n   - Color: ${item.selectedColor}${size}${mono}\n   - Subtotal: ${itemSubtotal}\n`;
  });

  const paymentLabel =
    orderDetails.paymentPreference === 'card'
      ? 'Credit / Debit Card'
      : orderDetails.paymentPreference === 'bank_transfer'
      ? 'Direct Bank Wire (SWIFT)'
      : orderDetails.paymentPreference === 'whatsapp'
      ? 'WhatsApp Direct Confirmation'
      : 'International Payment';

  const message = `✨ *NEW ORDER - SIALVANTGLOBAL INDUSTRIES* ✨\n\nHello SIALVANTGLOBAL INDUSTRIES! I would like to confirm my order for the following handcrafted leather goods:\n\n📋 *ITEMS ORDERED:*\n${itemsBreakdown}\n💰 *TOTAL ORDER VALUE:* ${totalAmountFormatted} (${shippingFormatted})\n\n👤 *CUSTOMER DETAILS:*\n• Name: ${orderDetails.name || 'Valued Client'}\n• Contact Phone: ${orderDetails.phone || 'Provided via WhatsApp'}\n• City / Country: ${orderDetails.city || 'N/A'}, ${orderDetails.country || 'International'}\n• Delivery Address: ${orderDetails.address || 'Standard Delivery'}\n• Preferred Payment: ${paymentLabel}\n${orderDetails.notes ? `• Special Instructions: ${orderDetails.notes}\n` : ''}\nPlease review and send invoice confirmation along with dispatch tracking details. Thank you!`;

  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

export function createBespokeWhatsAppUrl(data: {
  productType: string;
  leatherPreference: string;
  color: string;
  quantity: string;
  monogramText: string;
  notes: string;
}): string {
  const phone = getStoredWhatsAppNumber();

  const message = `Hello SIALVANTGLOBAL INDUSTRIES Master Craftsman! 🛠️\n\nI would like to inquire about a *Bespoke / Custom Leather Order*:\n\n• Item / Silhouette: ${data.productType}\n• Preferred Leather Hide: ${data.leatherPreference}\n• Desired Color Shade: ${data.color}\n• Order Quantity: ${data.quantity}\n• Custom Embossing / Monogram: ${data.monogramText || 'None'}\n• Sizing / Dimensions / Reference: ${data.notes || 'Standard bespoke tailoring'}\n\nPlease share feasibility, quotation, and crafting timeline. Thank you!`;

  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}
